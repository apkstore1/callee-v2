<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];

// Fetch campaigns for filter dropdown
$campaigns = [];
$camp_stmt = $conn->prepare("SELECT id, name FROM campaigns WHERE admin_id = ? ORDER BY created_at DESC");
$camp_stmt->bind_param("i", $admin_id);
$camp_stmt->execute();
$camp_result = $camp_stmt->get_result();
if ($camp_result) {
    $campaigns = $camp_result->fetch_all(MYSQLI_ASSOC);
}

// Fetch leads based on filter
$leads = [];
$selected_campaign_id = $_GET['campaign_id'] ?? '';
$search = $_GET['search'] ?? '';
$limit = 100; // Limit to prevent overload

$query = "SELECT l.id, l.phone_number, l.status, l.created_at, c.name as campaign_name 
          FROM leads l 
          JOIN campaigns c ON l.campaign_id = c.id 
          WHERE c.admin_id = ?";
$params = [$admin_id];
$types = "i";

if (!empty($selected_campaign_id)) {
    $query .= " AND l.campaign_id = ?";
    $params[] = $selected_campaign_id;
    $types .= "i";
}

if (!empty($search)) {
    $query .= " AND l.phone_number LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

$query .= " ORDER BY l.id DESC LIMIT ?";
$params[] = $limit;
$types .= "i";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
if ($result) {
    $leads = $result->fetch_all(MYSQLI_ASSOC);
}

$active_menu = 'leads';
include '../header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Lead Management</h2>
        <div style="display: flex; gap: 10px; align-items: center;">
            <form method="GET" action="" style="display: flex; gap: 10px; align-items: center;">
                <div class="search-box" style="position: relative;">
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search Phone..." style="padding: 8px; padding-left: 30px; border-radius: 4px; background: rgba(255, 255, 255, 0.1); color: white; border: 1px solid rgba(255, 255, 255, 0.2);">
                    <span style="position: absolute; left: 8px; top: 8px;">🔍</span>
                </div>
                
                <select name="campaign_id" onchange="this.form.submit()" style="padding: 8px; border-radius: 4px; background: rgba(255, 255, 255, 0.1); color: white; border: 1px solid rgba(255, 255, 255, 0.2);">
                    <option value="" style="color: black;">All Campaigns</option>
                    <?php foreach ($campaigns as $camp): ?>
                        <option value="<?= $camp['id'] ?>" <?= ($selected_campaign_id == $camp['id']) ? 'selected' : '' ?> style="color: black;">
                            <?= htmlspecialchars($camp['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            
            <?php if(!empty($selected_campaign_id)): ?>
                <a href="process_lead.php?action=delete_all&campaign_id=<?= $selected_campaign_id ?>" onclick="return confirm('WARNING: This will delete ALL leads in this campaign. Are you sure?');"><button class="btn-danger">Delete All</button></a>
            <?php endif; ?>

            <a href="import.php">
                <button class="btn-primary"><span>+ Import Leads</span></button>
            </a>
        </div>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Phone Number</th>
                    <th>Campaign</th>
                    <th>Status</th>
                    <th>Uploaded Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($leads)): ?>
                    <tr><td colspan="5" style="text-align:center;">No leads found.</td></tr>
                <?php else: ?>
                    <?php foreach ($leads as $lead): ?>
                    <tr>
                        <td><?= htmlspecialchars($lead['phone_number']) ?></td>
                        <td><?= htmlspecialchars($lead['campaign_name']) ?></td>
                        <td><span class="status-badge status-<?= strtolower($lead['status']) ?>"><?= htmlspecialchars($lead['status']) ?></span></td>
                        <td><?= date('M d, Y', strtotime($lead['created_at'])) ?></td>
                        <td>
                            <a href="edit.php?id=<?= $lead['id'] ?>" class="btn-secondary btn-sm" style="text-decoration: none; padding: 4px 8px; font-size: 12px;">Edit</a>
                            <a href="process_lead.php?action=delete&id=<?= $lead['id'] ?>" class="btn-danger btn-sm" onclick="return confirm('Are you sure?');" style="text-decoration: none; padding: 4px 8px; font-size: 12px;">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include '../footer.php'; ?>