<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];

// Fetch campaigns
$campaigns = [];
$camp_stmt = $conn->prepare("SELECT id, name FROM campaigns WHERE admin_id = ? ORDER BY created_at DESC");
$camp_stmt->bind_param("i", $admin_id);
$camp_stmt->execute();
$result = $camp_stmt->get_result();
$campaigns = $result->fetch_all(MYSQLI_ASSOC);

$active_menu = 'leads';
include '../header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Import Leads</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <div class="table-container" style="padding: 20px; max-width: 600px;">
        <form action="process_lead.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="import">
            
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Select Campaign *</label>
                <select name="campaign_id" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                    <option value="" style="color: black;">Choose a campaign</option>
                    <?php foreach ($campaigns as $camp): ?>
                        <option value="<?= $camp['id'] ?>" style="color: black;"><?= htmlspecialchars($camp['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="margin-bottom: 15px; border: 1px dashed #444; padding: 15px; border-radius: 4px;">
                <label style="display:block; margin-bottom:5px; color: #00d9ff;">Upload CSV File *</label>
                <input type="file" name="csv_file" accept=".csv" required style="color: white;">
                <p style="font-size: 12px; color: #888; margin-top: 5px;">Format: Phone Number in first column</p>
            </div>

            <button type="submit" class="btn-primary">Import Leads</button>
        </form>
    </div>
</div>
<?php include '../footer.php'; ?>