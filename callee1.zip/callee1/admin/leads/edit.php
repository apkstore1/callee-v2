<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];
$lead_id = $_GET['id'] ?? 0;

// Fetch lead and verify ownership
$stmt = $conn->prepare("SELECT l.*, c.name as campaign_name FROM leads l JOIN campaigns c ON l.campaign_id = c.id WHERE l.id = ? AND c.admin_id = ?");
$stmt->bind_param("ii", $lead_id, $admin_id);
$stmt->execute();
$lead = $stmt->get_result()->fetch_assoc();

if (!$lead) {
    header('Location: index.php?error=Lead not found');
    exit;
}

$active_menu = 'leads';
include '../header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Edit Lead</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <div class="table-container" style="padding: 20px; max-width: 600px;">
        <form action="process_lead.php" method="post">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="<?= $lead['id'] ?>">
            
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Campaign</label>
                <input type="text" value="<?= htmlspecialchars($lead['campaign_name']) ?>" disabled style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: #aaa; border-radius: 4px;">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Phone Number *</label>
                <input type="text" name="phone_number" value="<?= htmlspecialchars($lead['phone_number']) ?>" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Status</label>
                <select name="status" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                    <option value="pending" <?= ($lead['status'] == 'pending') ? 'selected' : '' ?> style="color: black;">Pending</option>
                    <option value="called" <?= ($lead['status'] == 'called') ? 'selected' : '' ?> style="color: black;">Called</option>
                    <option value="answered" <?= ($lead['status'] == 'answered') ? 'selected' : '' ?> style="color: black;">Answered</option>
                    <option value="failed" <?= ($lead['status'] == 'failed') ? 'selected' : '' ?> style="color: black;">Failed</option>
                </select>
            </div>

            <button type="submit" class="btn-primary">Update Lead</button>
        </form>
    </div>
</div>
<?php include '../footer.php'; ?>