<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];
$action = $_REQUEST['action'] ?? '';

if ($action === 'import') {
    $campaign_id = $_POST['campaign_id'];
    
    // Verify campaign ownership
    $check = $conn->prepare("SELECT id FROM campaigns WHERE id = ? AND admin_id = ?");
    $check->bind_param("ii", $campaign_id, $admin_id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        header('Location: index.php?error=Access denied');
        exit;
    }

    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
        $file = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($file, "r");
        $count = 0;
        
        if ($handle !== FALSE) {
            $stmt = $conn->prepare("INSERT INTO leads (campaign_id, phone_number, status) VALUES (?, ?, 'pending')");
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $phone = trim($data[0]);
                // Basic validation: check if numeric and not empty
                if (!empty($phone)) {
                    $stmt->bind_param("is", $campaign_id, $phone);
                    $stmt->execute();
                    $count++;
                }
            }
            fclose($handle);
        }
        header("Location: index.php?success=Imported $count leads successfully");
    } else {
        header('Location: import.php?error=File upload failed');
    }

} elseif ($action === 'update') {
    $lead_id = $_POST['id'];
    $phone = $_POST['phone_number'];
    $status = $_POST['status'];

    // Verify ownership
    $check = $conn->prepare("SELECT l.id FROM leads l JOIN campaigns c ON l.campaign_id = c.id WHERE l.id = ? AND c.admin_id = ?");
    $check->bind_param("ii", $lead_id, $admin_id);
    $check->execute();
    
    if ($check->get_result()->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE leads SET phone_number = ?, status = ? WHERE id = ?");
        $stmt->bind_param("ssi", $phone, $status, $lead_id);
        $stmt->execute();
        header('Location: index.php?success=Lead updated successfully');
    } else {
        header('Location: index.php?error=Access denied');
    }

} elseif ($action === 'delete_all') {
    $campaign_id = $_GET['campaign_id'];

    // Verify ownership
    $check = $conn->prepare("SELECT id FROM campaigns WHERE id = ? AND admin_id = ?");
    $check->bind_param("ii", $campaign_id, $admin_id);
    $check->execute();

    if ($check->get_result()->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM leads WHERE campaign_id = ?");
        $stmt->bind_param("i", $campaign_id);
        $stmt->execute();
        header('Location: index.php?success=All leads deleted for this campaign');
    } else {
        header('Location: index.php?error=Access denied');
    }

} elseif ($action === 'delete') {
    $lead_id = $_GET['id'];
    
    // Verify lead belongs to admin's campaign
    $check = $conn->prepare("SELECT l.id FROM leads l JOIN campaigns c ON l.campaign_id = c.id WHERE l.id = ? AND c.admin_id = ?");
    $check->bind_param("ii", $lead_id, $admin_id);
    $check->execute();
    
    if ($check->get_result()->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM leads WHERE id = ?");
        $stmt->bind_param("i", $lead_id);
        $stmt->execute();
        header('Location: index.php?success=Lead deleted');
    } else {
        header('Location: index.php?error=Access denied');
    }
} else {
    header('Location: index.php');
}
?>