<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php'); // Redirect to main login if not admin
    exit;
}

// Re-fetch user permissions on each load to get the latest data
require_once __DIR__ . '/../db_connect.php';
$stmt = $conn->prepare("SELECT allow_auto_dial, credits, status, allow_call, allow_message FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();

// --- STATUS CHECK LOGIC FOR ADMIN ---
$account_status = $user_data['status'] ?? 'active';

if ($account_status === 'suspended') {
    // Blank screen with message
    echo '<body style="background-color: #0f0f1e; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: sans-serif;">
            <div style="text-align: center;">
                <h1 style="font-size: 3rem; color: #ef4444;">Account Suspended</h1>
                <p>Your account has been suspended. Please contact support.</p>
                <a href="/callee1/logout.php" style="color: #00d9ff; text-decoration: none; margin-top: 20px; display: inline-block;">Logout</a>
            </div>
          </body>';
    exit;
} elseif ($account_status === 'inactive' || $account_status === 'unpaid') {
    $msg_title = ($account_status === 'unpaid') ? 'Account Unpaid / Out of Balance' : 'Account Inactive';
    echo '<body style="background-color: #0f0f1e; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: sans-serif;">
            <div style="text-align: center; padding: 40px; background: rgba(255,255,255,0.05); border-radius: 16px; border: 1px solid rgba(255,255,255,0.1);">
                <h1 style="font-size: 2rem; color: #f59e0b;">⚠️ ' . $msg_title . '</h1>
                <p style="margin: 20px 0; color: #9ca3af;">Access to the dashboard is restricted due to your account status.</p>
                <a href="/callee1/logout.php" style="padding: 10px 20px; background: #ef4444; color: white; text-decoration: none; border-radius: 6px;">Logout</a>
            </div>
          </body>';
    exit;
}
// ------------------------------------

$_SESSION['allow_auto_dial'] = $user_data['allow_auto_dial'] ?? 0;
$creditBalance = $user_data['credits'] ?? 0.00;
$adminName = $_SESSION['user_username'] ?? 'Admin';

$admin_can_call = $user_data['allow_call'] ?? 0;
$admin_can_message = $user_data['allow_message'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - VoIP Call Center</title>
    <link rel="stylesheet" href="/callee1/assets/css/dashboard.css">
</head>
<body class="dark-theme">
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
                <p id="adminName"><?php echo htmlspecialchars($adminName); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <a href="/callee1/admin/admin_dashboard.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'overview') ? 'active' : ''; ?>">
                    <span class="icon">📊</span>
                    <span>Dashboard</span>
                </a>
                <a href="/callee1/admin/campaign/index.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'campaigns') ? 'active' : ''; ?>">
                    <span class="icon">🎯</span>
                    <span>Campaigns</span>
                </a>
                <a href="/callee1/admin/leads/index.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'leads') ? 'active' : ''; ?>">
                    <span class="icon">👤</span>
                    <span>Leads</span>
                </a>
                <a href="/callee1/admin/agents/index.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'agents') ? 'active' : ''; ?>">
                    <span class="icon">👥</span>
                    <span>Agents</span>
                </a>
                <a href="/callee1/admin/numbers.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'numbers') ? 'active' : ''; ?>">
                    <span class="icon">#️⃣</span>
                    <span>Numbers</span>
                </a>
                <a href="#" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'calls') ? 'active' : ''; ?>">
                    <span class="icon">📞</span>
                    <span>Call History</span>
                </a>
                <a href="#" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'reports') ? 'active' : ''; ?>">
                    <span class="icon">📈</span>
                    <span>Reports</span>
                </a>
                <a href="#" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'billing') ? 'active' : ''; ?>" data-page="billing">
                    <span class="icon">💳</span>
                    <span>Billing</span>
                </a>
                <a href="#" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'settings') ? 'active' : ''; ?>">
                    <span class="icon">⚙️</span>
                    <span>Settings</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="credit-display">
                    <div class="label">Available Credits</div>
                    <div class="credit-amount" id="creditBalance">$<?php echo number_format($creditBalance, 2); ?></div>
                </div>
                <a href="/callee1/logout.php">
                <button class="btn-logout" onclick="logout()">
                    <span class="icon">🚪</span>
                    <span>Logout</span>
                </button>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-left">
                    <h1 id="pageTitle">Dashboard</h1>
                </div>
                <div class="top-bar-right">
                    <div class="stats-badge">
                        <span class="label">Active Agents</span>
                        <span class="value" id="activeAgents">0</span>
                    </div>
                    <div class="stats-badge">
                        <span class="label">Ongoing Calls</span>
                        <span class="value" id="ongoingCalls">0</span>
                    </div>
                    <!-- Permissions Badges -->
                    <div class="stats-badge" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);">
                        <span class="label">My Permissions</span>
                        <span class="value" style="font-size: 0.9em;">
                            Call: <?= $admin_can_call ? '<span style="color:#4ade80">✅</span>' : '<span style="color:#f87171">✗</span>' ?> | 
                            Msg: <?= $admin_can_message ? '<span style="color:#4ade80">✓</span>' : '<span style="color:#f87171">✗</span>' ?>
                        </span>
                    </div>
                </div>
            </header>

            <?php 
            if (isset($active_menu) && $active_menu == 'agents'){
            if (!$admin_can_call || !$admin_can_message): ?>
            <div style="background: rgba(185, 28, 28, 0.2); color: #fca5a5; padding: 10px 15px; margin: 15px 15px 0 15px; border-radius: 8px; border: 1px solid rgba(248, 113, 113, 0.3); display: flex; align-items: center;">
                <span style="font-size: 1.2em; margin-right: 10px;">⚠️</span>
                <span>
                    <strong>Notice:</strong> Your and Your agents
                    <?= (!$admin_can_call ? 'Calling' : '') ?>
                    <?= (!$admin_can_call && !$admin_can_message ? 'and' : '') ?>
                    <?= (!$admin_can_message ? 'Messaging' : '') ?>
                    permissions have been disabled by the Callee.
                </span>
            </div>
            <?php endif; ?>
            <?php } ?>