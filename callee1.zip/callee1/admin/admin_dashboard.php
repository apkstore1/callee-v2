<?php
session_start();
// The header.php now includes the session check and permission refresh
$active_menu = 'overview';
include 'header.php'; 

// Fetch Dashboard Stats
$active_campaigns_count = 0;
$total_leads_count = 0;

// Count Active Campaigns
$camp_result = $conn->query("SELECT COUNT(*) as count FROM campaigns WHERE status = 'active'");
if ($camp_result) {
    $active_campaigns_count = $camp_result->fetch_assoc()['count'];
}

// Count Total Leads
$leads_result = $conn->query("SELECT COUNT(*) as count FROM leads");
if ($leads_result) {
    $total_leads_count = $leads_result->fetch_assoc()['count'];
}
?>
            <div class="content-area" id="contentArea">
                <!-- Overview Page -->
                <div id="overviewPage" class="page-content.active">
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon blue">🎯</div>
                            <div class="stat-info">
                                <h3>Active Campaigns</h3>
                                <p class="stat-value" id="activeCampaigns"><?php echo $active_campaigns_count; ?></p>
                                <span class="stat-label">Running campaigns</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon green">👤</div>
                            <div class="stat-info">
                                <h3>Total Leads</h3>
                                <p class="stat-value" id="totalLeads"><?php echo $total_leads_count; ?></p>
                                <span class="stat-label">All campaigns</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon purple">📞</div>
                            <div class="stat-info">
                                <h3>Today's Calls</h3>
                                <p class="stat-value" id="todayCalls">0</p>
                                <span class="stat-label">Completed</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon orange">✅</div>
                            <div class="stat-info">
                                <h3>Conversion Rate</h3>
                                <p class="stat-value" id="conversionRate">0%</p>
                                <span class="stat-label">This month</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="charts-grid">
                        <div class="chart-card">
                            <h3>Call Performance</h3>
                            <div id="performanceChart" style="height: 300px;"></div>
                        </div>
                        
                        <div class="chart-card">
                            <h3>Agent Activity</h3>
                            <div id="agentActivity"></div>
                        </div>
                    </div>
                </div>
                
                <!-- Leads Page -->
                <div id="leadsPage" class="page-content">
                    <div class="page-header">
                        <h2>Lead Management</h2>
                        <div style="display: flex; gap: 12px;">
                            <select class="filter-select" id="leadCampaignFilter" onchange="filterLeads()">
                                <option value="">Select Campaign</option>
                            </select>
                            <button class="btn-primary" onclick="openImportLeadsModal()">
                                <span>+ Import Leads</span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Assigned Agent</th>
                                    <th>Last Contact</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="leadsTableBody">
                                <tr>
                                    <td colspan="7" class="text-center">Select a campaign</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </main>
    </div>
    
    <!-- Import Leads Modal -->
    <div id="importLeadsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Import Leads</h2>
                <button class="close-btn" onclick="closeImportLeadsModal()">&times;</button>
            </div>
            <form id="importLeadsForm">
                <div class="form-group">
                    <label>Select Campaign *</label>
                    <select name="campaign_id" id="importCampaignSelect" required>
                        <option value="">Choose a campaign</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Upload CSV File</label>
                    <input type="file" accept=".csv" id="csvFile">
                    <p style="font-size: 12px; color: var(--text-muted); margin-top: 8px;">
                        CSV format: first_name, last_name, phone, email, address, city, state, zip
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeImportLeadsModal()">Cancel</button>
                    <button type="submit" class="btn-primary">Import Leads</button>
                </div>
            </form>
        </div>
    </div>
<?php include 'footer.php'; ?>
