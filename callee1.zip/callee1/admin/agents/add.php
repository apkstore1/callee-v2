<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
$active_menu = 'agents';
include '../header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Add New Agent</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <div class="table-container" style="padding: 20px; max-width: 600px;">
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger" style="color: red; background: rgba(255,0,0,0.1); padding: 10px; margin-bottom: 15px; border-radius: 4px;">
                <?= htmlspecialchars($_GET['error']) ?>
            </div>
        <?php endif; ?>
        <form action="process_agent.php" method="post">
            <input type="hidden" name="action" value="create">
            
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Username *</label>
                <input type="text" name="username" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Password *</label>
                <input type="password" name="password" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <button type="submit" class="btn-primary">Create Agent</button>
        </form>
    </div>
</div>
<?php include '../footer.php'; ?>