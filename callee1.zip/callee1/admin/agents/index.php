<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];

// Fetch agents for this admin
$agents = [];
$stmt = $conn->prepare("SELECT id, username, allow_call, allow_message FROM users WHERE role = 'agent' AND admin_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$agents = $result->fetch_all(MYSQLI_ASSOC);

$active_menu = 'agents';
include '../header.php';
?>

<div class="content-area">
    <?php if (isset($_GET['success'])): ?>
        <div style="color: green; margin-bottom: 15px; padding: 10px; background: rgba(0,255,0,0.1); border-radius: 4px;">
            <?= htmlspecialchars($_GET['success']) ?>
        </div>
    <?php endif; ?>
    
    <div class="page-header">
        <h2>Agent Management</h2>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Call Permission</th>
                    <th>Msg Permission</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($agents)): ?>
                    <tr><td colspan="2" style="text-align:center;">No agents found.</td></tr>
                <?php else: ?>
                    <?php foreach ($agents as $agent): ?>
                    <tr>
                        <td><?= htmlspecialchars($agent['username']) ?></td>
                        <td>
                            <?php if ($agent['allow_call']): ?>
                                <span style="color: #22c55e; font-weight: bold;">✓ Allowed</span>
                            <?php else: ?>
                                <span style="color: #ef4444; font-weight: bold;">✗ Blocked</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($agent['allow_message']): ?>
                                <span style="color: #22c55e; font-weight: bold;">✓ Allowed</span>
                            <?php else: ?>
                                <span style="color: #ef4444; font-weight: bold;">✗ Blocked</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="edit.php?id=<?= $agent['id'] ?>" class="btn-secondary btn-sm" style="text-decoration: none; padding: 4px 8px; font-size: 12px;">Edit</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../footer.php'; ?>