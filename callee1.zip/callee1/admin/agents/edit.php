<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];
$agent_id = $_GET['id'] ?? 0;

// Fetch agent and verify ownership
$stmt = $conn->prepare("SELECT id, username FROM users WHERE id = ? AND role = 'agent' AND admin_id = ?");
$stmt->bind_param("ii", $agent_id, $admin_id);
$stmt->execute();
$agent = $stmt->get_result()->fetch_assoc();

if (!$agent) {
    header('Location: index.php?error=Agent not found');
    exit;
}

$active_menu = 'agents';
include '../header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Edit Agent</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <div class="table-container" style="padding: 20px; max-width: 600px;">
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger" style="color: red; background: rgba(255,0,0,0.1); padding: 10px; margin-bottom: 15px; border-radius: 4px;">
                <?= htmlspecialchars($_GET['error']) ?>
            </div>
        <?php endif; ?>
        <form action="process_agent.php" method="post">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="<?= $agent['id'] ?>">
            
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Username *</label>
                <input type="text" name="username" value="<?= htmlspecialchars($agent['username']) ?>" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">New Password (leave blank to keep current)</label>
                <input type="password" name="password" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <button type="submit" class="btn-primary">Update Agent</button>
        </form>
    </div>
</div>
<?php include '../footer.php'; ?>