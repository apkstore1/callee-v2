<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];
$action = $_REQUEST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (empty($username) || empty($password)) {
            header('Location: add.php?error=All fields are required');
            exit;
        }

        // Check if username or email exists
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            header('Location: add.php?error=Username already exists');
            exit;
        }

        // In a real app, hash the password. For now, storing as is.
        // $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (username, password, role, admin_id) VALUES (?, ?, 'agent', ?)");
        $stmt->bind_param("ssi", $username, $password, $admin_id);
        $stmt->execute();

        header('Location: index.php?success=Agent created successfully');
        exit;

    } elseif ($action === 'update') {
        $agent_id = $_POST['id'];
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Verify ownership
        $check = $conn->prepare("SELECT id FROM users WHERE id = ? AND admin_id = ?");
        $check->bind_param("ii", $agent_id, $admin_id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            header('Location: index.php?error=Access Denied');
            exit;
        }

        if (empty($password)) {
            $stmt = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
            $stmt->bind_param("si", $username, $agent_id);
        } else {
            // In a real app, hash the password.
            $stmt = $conn->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
            $stmt->bind_param("ssi", $username, $password, $agent_id);
        }
        $stmt->execute();
        header('Location: index.php?success=Agent updated successfully');
        exit;
    }
}

if ($action === 'delete') {
    $agent_id = $_GET['id'];

    // Verify ownership before deleting
    $check = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'agent' AND admin_id = ?");
    $check->bind_param("ii", $agent_id, $admin_id);
    $check->execute();

    if ($check->get_result()->num_rows > 0) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $agent_id);
        $stmt->execute();
        header('Location: index.php?success=Agent deleted successfully');
    } else {
        header('Location: index.php?error=Access Denied');
    }
    exit;
}
?>