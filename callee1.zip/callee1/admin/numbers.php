<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}

require_once __DIR__ . '/../db_connect.php';
$admin_id = $_SESSION['user_id'];
$active_menu = 'numbers';

// Handle Release Number Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['release_number_id'])) {
    $release_id = (int)$_POST['release_number_id'];
    $conn->begin_transaction();
    try {
        // Check if admin owns this number
        $check = $conn->prepare("SELECT id FROM admin_numbers WHERE number_id = ? AND admin_id = ?");
        $check->bind_param("ii", $release_id, $admin_id);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            // Remove from admin_numbers
            $del = $conn->prepare("DELETE FROM admin_numbers WHERE number_id = ? AND admin_id = ?");
            $del->bind_param("ii", $release_id, $admin_id);
            $del->execute();
            
            // Set status back to available in phone_numbers
            $upd = $conn->prepare("UPDATE phone_numbers SET status = 'available' WHERE id = ?");
            $upd->bind_param("i", $release_id);
            $upd->execute();
            
            $conn->commit();
            header("Location: numbers.php?msg=released");
            exit;
        }
        $conn->rollback();
    } catch (Exception $e) {
        $conn->rollback();
    }
}

include 'header.php';

// Fetch admin's numbers
$my_numbers = [];
$sql = "SELECT pn.number, pn.type, an.purchase_date, an.expiry_date, an.status, an.number_id 
        FROM admin_numbers an
        JOIN phone_numbers pn ON an.number_id = pn.id
        WHERE an.admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result) {
    $my_numbers = $result->fetch_all(MYSQLI_ASSOC);
}
$stmt->close();

?>

<div class="content-area">
    <div class="page-header">
        <h2>My Numbers</h2>
        <a href="buy_number.php" class="btn-primary">+ Buy New Number</a>
    </div>

    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'released'): ?>
        <div class="alert" style="background: rgba(34, 197, 94, 0.2); color: #86efac; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            Number released successfully.
        </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Phone Number</th>
                    <th>Type</th>
                    <th>Purchase Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($my_numbers)): ?>
                    <?php foreach ($my_numbers as $num): ?>
                        <tr>
                            <td><?= htmlspecialchars($num['number']) ?></td>
                            <td><span class="role-badge"><?= htmlspecialchars($num['type']) ?></span></td>
                            <td><?= date('Y-m-d', strtotime($num['purchase_date'])) ?></td>
                            <td>
                                <?php 
                                $status_class = 'status-assigned'; // default
                                if ($num['status'] == 'active') $status_class = 'status-available';
                                if ($num['status'] == 'pending_payment') $status_class = 'status-reserved';
                                ?>
                                <span class="status-badge <?= $status_class ?>"><?= htmlspecialchars(str_replace('_', ' ', $num['status'])) ?></span>
                            </td>
                            <td>
                                <?php if ($num['status'] == 'pending_payment'): ?>
                                    <button class="btn-primary btn-sm">Pay Now</button>
                                <?php else: ?>
                                    <!---button class="btn-secondary btn-sm">Manage</button----->
                                    <!-----form method="POST" action="numbers.php" style="display:inline-block; margin-left: 5px;" onsubmit="return confirm('Are you sure you want to release this number? It will be removed from your account and made available to others.');">
                                        <input type="hidden" name="release_number_id" value="<?= $num['number_id'] ?>">
                                        <button type="submit" class="btn-danger btn-sm">Release</button>
                                    </form------->
                                    <h4>Contact Support to Release Number</h4>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">You have not purchased any numbers yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>