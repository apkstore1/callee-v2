<?php
include('db_connect.php');
session_start();
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['user_role'] === 'agent') {
        header('Location: agent_dashboard.php');
    } else {
        // Log out or redirect to a generic error page for unhandled roles
        // For now, redirect to index with an error, similar to login.php
        header('Location: index.php?error=Unauthorized role');
        session_unset();
        session_destroy();
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoIP Call Center - Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-header">
            <div class="logo-circle">
                <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
            </div>
            <h1>VoIP Admin Panel</h1>
            <p>Professional Call Management System</p>
        </div>

        <div class="login-card">
            <h2>Welcome Back</h2>
            <p class="subtitle">Enter your Admin credentials to access your dashboard</p>

            <form id="loginForm" class="login-form" action="../login.php" method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <div class="input-with-icon">
                        <svg class="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                        <input type="text" id="username" name="username" placeholder="Enter username" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-with-icon">
                        <svg class="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                        <input type="password" id="password" name="password" placeholder="Enter password" required>
                    </div>
                </div>
                <input type="hidden" name="role" id="role" value="admin">

                <div id="errorMessage" class="error-message" style="display: none;"></div>

                <button type="submit" name="submit" class="btn btn-primary btn-block" id="loginBtn">
                    Sign In
                </button>

                <div class="demo-credentials">
                    Demo: superadmin / password
                </div>
            </form>
        </div>

        <div class="login-footer">
            <p>Supports Asterisk, FreePBX & FreeSWITCH</p>
        </div>
    </div>

    <script>   </script>
</body>
</html>
