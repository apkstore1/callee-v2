<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}

require_once __DIR__ . '/../db_connect.php';
$admin_id = $_SESSION['user_id'];
$message = '';
$msg_type = 'error';

// Handle Buy Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_number_id'])) {
    $number_id_to_buy = (int)$_POST['buy_number_id'];

    $conn->begin_transaction();
    try {
        // 1. Check if number is available and lock it
        $stmt = $conn->prepare("SELECT id FROM phone_numbers WHERE id = ? AND status = 'available' FOR UPDATE");
        $stmt->bind_param("i", $number_id_to_buy);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            throw new Exception("Sorry, this number is no longer available.");
        }
        $stmt->close();

        // 2. Update the number's status to 'assigned'
        $stmt = $conn->prepare("UPDATE phone_numbers SET status = 'assigned' WHERE id = ?");
        $stmt->bind_param("i", $number_id_to_buy);
        $stmt->execute();
        $stmt->close();

        // 3. Insert into admin_numbers with 'pending_payment' status
        $stmt = $conn->prepare("INSERT INTO admin_numbers (admin_id, number_id, status) VALUES (?, ?, 'pending_payment')");
        $stmt->bind_param("ii", $admin_id, $number_id_to_buy);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
        header('Location: numbers.php?success=1');
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $message = $e->getMessage();
    }
}


// Fetch available numbers
$available_numbers = [];
$sql = "SELECT id, number, type, price FROM phone_numbers WHERE status = 'available' ORDER BY type, number";
$result = $conn->query($sql);
if ($result) {
    $available_numbers = $result->fetch_all(MYSQLI_ASSOC);
}

$active_menu = 'numbers';
include 'header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Buy a Number</h2>
        <a href="numbers.php" class="btn-secondary">Back to My Numbers</a>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Phone Number</th>
                    <th>Type</th>
                    <th>Price/Month</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($available_numbers)): ?>
                    <?php foreach ($available_numbers as $num): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($num['number']) ?></strong></td>
                            <td><span class="role-badge"><?= htmlspecialchars($num['type']) ?></span></td>
                            <td>$<?= number_format($num['price'], 2) ?></td>
                            <td>
                                <form action="buy_number.php" method="POST" style="margin:0;"><input type="hidden" name="buy_number_id" value="<?= $num['id'] ?>"><button type="submit" class="btn-primary btn-sm">Buy</button></form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4" class="text-center">No numbers are available for purchase at the moment.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>