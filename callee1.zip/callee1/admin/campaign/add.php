<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
$active_menu = 'campaigns';
include '../header.php';

// Permission check
$allow_auto_dial = $_SESSION['allow_auto_dial'] ?? 0;
?>

<div class="content-area">
    <div class="page-header">
        <h2>Add New Campaign</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <div class="table-container" style="padding: 20px; max-width: 800px;">
        <form action="process_campaign.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create">
            
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Campaign Name *</label>
                <input type="text" name="name" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Description</label>
                <textarea name="description" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;"></textarea>
            </div>

            <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                <div class="form-group" style="flex: 1;">
                    <label style="display:block; margin-bottom:5px;">Start Date *</label>
                    <input type="date" name="start_date" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                </div>
                <div class="form-group" style="flex: 1;">
                    <label style="display:block; margin-bottom:5px;">End Date *</label>
                    <input type="date" name="end_date" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Dialing Method *</label>
                <select name="dial_method" id="dial_method" onchange="toggleUpload()" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                    <option value="manual">Manual Dialing</option>
                    <option value="auto" <?php echo ($allow_auto_dial == 0) ? 'disabled' : ''; ?>>Auto Dialing (Predictive)</option>
                </select>
                <?php if($allow_auto_dial == 0): ?>
                    <small style="color: #888;">Contact Super Admin to enable Auto Dialing.</small>
                <?php endif; ?>
            </div>

            <div class="form-group" id="upload_div" style="display: none; margin-bottom: 15px; border: 1px dashed #444; padding: 15px; border-radius: 4px;">
                <label style="display:block; margin-bottom:5px; color: #00d9ff;">Upload Lead List (CSV) *</label>
                <input type="file" name="lead_file" accept=".csv" style="color: white;">
                <p style="font-size: 12px; color: #888; margin-top: 5px;">Phone numbers in first column</p>
            </div>

            <button type="submit" class="btn-primary">Create Campaign</button>
        </form>
    </div>
</div>

<script>
function toggleUpload() {
    const method = document.getElementById('dial_method').value;
    document.getElementById('upload_div').style.display = (method === 'auto') ? 'block' : 'none';
}
</script>
<?php include '../footer.php'; ?>