<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}
require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];
$campaign_id = $_GET['id'] ?? 0;

// Verify ownership before deleting
$check = $conn->prepare("SELECT id FROM campaigns WHERE id = ? AND admin_id = ?");
$check->bind_param("ii", $campaign_id, $admin_id);
$check->execute();

if ($check->get_result()->num_rows > 0) {
    $stmt = $conn->prepare("DELETE FROM campaigns WHERE id = ?");
    $stmt->bind_param("i", $campaign_id);
    $stmt->execute();
    header('Location: index.php?success=Campaign deleted successfully');
} else {
    header('Location: index.php?error=Campaign not found or access denied');
}
?>