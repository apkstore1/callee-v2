<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}

require_once '../../db_connect.php';

$admin_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if ($action === 'create') {
    $name = $_POST['name'] ?? '';
    $dial_method = $_POST['dial_method'] ?? 'manual';
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $description = $_POST['description'] ?? '';

    // Permission check
    if ($dial_method === 'auto' && (empty($_SESSION['allow_auto_dial']) || $_SESSION['allow_auto_dial'] == 0)) {
        header('Location: add.php?error=Auto dial permission denied');
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO campaigns (name, admin_id, dial_method, start_date, end_date, description, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
    $stmt->bind_param("sissss", $name, $admin_id, $dial_method, $start_date, $end_date, $description);

    if ($stmt->execute()) {
        $campaign_id = $conn->insert_id;
        
        // Handle CSV Upload
        if ($dial_method === 'auto' && isset($_FILES['lead_file']) && $_FILES['lead_file']['error'] == 0) {
            handleCsvUpload($conn, $campaign_id, $_FILES['lead_file']['tmp_name']);
        }

        header('Location: index.php?success=Campaign created successfully');
    } else {
        header('Location: add.php?error=' . urlencode($conn->error));
    }

} elseif ($action === 'update') {
    $campaign_id = $_POST['id'];
    $name = $_POST['name'];
    $dial_method = $_POST['dial_method'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Verify ownership
    $check = $conn->prepare("SELECT id FROM campaigns WHERE id = ? AND admin_id = ?");
    $check->bind_param("ii", $campaign_id, $admin_id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        header('Location: index.php?error=Access denied');
        exit;
    }

    // Permission check
    if ($dial_method === 'auto' && (empty($_SESSION['allow_auto_dial']) || $_SESSION['allow_auto_dial'] == 0)) {
        header('Location: edit.php?id='.$campaign_id.'&error=Auto dial permission denied');
        exit;
    }

    $stmt = $conn->prepare("UPDATE campaigns SET name=?, dial_method=?, start_date=?, end_date=? WHERE id=?");
    $stmt->bind_param("ssssi", $name, $dial_method, $start_date, $end_date, $campaign_id);

    if ($stmt->execute()) {
        // Handle CSV Upload (Append)
        if ($dial_method === 'auto' && isset($_FILES['lead_file']) && $_FILES['lead_file']['error'] == 0) {
            handleCsvUpload($conn, $campaign_id, $_FILES['lead_file']['tmp_name']);
        }
        header('Location: index.php?success=Campaign updated successfully');
    } else {
        header('Location: edit.php?id='.$campaign_id.'&error=' . urlencode($conn->error));
    }
}

function handleCsvUpload($conn, $campaign_id, $file_path) {
    $handle = fopen($file_path, "r");
    if ($handle !== FALSE) {
        $lead_stmt = $conn->prepare("INSERT INTO leads (campaign_id, phone_number, status) VALUES (?, ?, 'pending')");
        
        // Optional: fgetcsv($handle); // Skip header if needed
        
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $phone = trim($data[0]);
            if (!empty($phone)) {
                $lead_stmt->bind_param("is", $campaign_id, $phone);
                $lead_stmt->execute();
            }
        }
        fclose($handle);
    }
}
?>