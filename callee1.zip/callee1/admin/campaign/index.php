<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /callee1/index.php');
    exit;
}

require_once __DIR__ . '/../../db_connect.php';

$admin_id = $_SESSION['user_id'];

// Fetch campaigns for this admin only
$campaigns = [];
$sql = "SELECT c.id, c.name, c.status, c.start_date, c.end_date, c.dial_method, 
        (SELECT COUNT(*) FROM leads l WHERE l.campaign_id = c.id) AS lead_count
        FROM campaigns c
        WHERE c.admin_id = ?
        ORDER BY c.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result) {
    $campaigns = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<?php 
$active_menu = 'campaigns';
include '../header.php'; 
?>

<div class="content-area">
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger" style="color: red; background: rgba(255,0,0,0.1); padding: 10px; margin-bottom: 15px; border-radius: 4px;">
            <?= htmlspecialchars($_GET['error']) ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['success'])): ?>
        <div style="color: green; margin-bottom: 15px; padding: 10px; background: rgba(0,255,0,0.1); border-radius: 4px;">
            <?= htmlspecialchars($_GET['success']) ?>
        </div>
    <?php endif; ?>
    
    <div class="page-header">
        <h2>Campaigns</h2>
        <a href="add.php">
            <button class="btn-primary">
                <span>+ Add Campaign</span>
            </button>
        </a>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Campaign Name</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Leads</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($campaigns)): ?>
                    <tr><td colspan="7" style="text-align:center;">No campaigns found.</td></tr>
                <?php else: ?>
                    <?php foreach ($campaigns as $campaign): ?>
                    <tr>
                        <td><?= htmlspecialchars($campaign['name']) ?></td>
                        <td><?= ucfirst(htmlspecialchars($campaign['dial_method'])) ?></td>
                        <td><span class="status-<?= strtolower(htmlspecialchars($campaign['status'])) ?>"><?= htmlspecialchars($campaign['status']) ?></span></td>
                        <td><?= htmlspecialchars($campaign['lead_count']) ?></td>
                        <td><?= htmlspecialchars($campaign['start_date']) ?></td>
                        <td><?= htmlspecialchars($campaign['end_date']) ?></td>
                        <td>
                            <a href="edit.php?id=<?= $campaign['id'] ?>" class="btn-secondary btn-sm" style="text-decoration: none; padding: 5px 10px; font-size: 12px;">Edit</a>
                            <a href="delete_campaign.php?id=<?= $campaign['id'] ?>" class="btn-danger btn-sm" style="text-decoration: none; padding: 5px 10px; font-size: 12px;" onclick="return confirm('Are you sure?');">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include '../footer.php'; ?>