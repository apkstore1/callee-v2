<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure user is logged in and is an agent
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'agent') {
    header('Location: /callee1/index.php');
    exit;
}

require_once __DIR__ . '/db_connect.php';

$agent_id = $_SESSION['user_id'];
$agent_username = $_SESSION['user_username'] ?? 'Agent';

// Fetch latest status from database
// Modified to fetch Agent Status AND Parent Admin Status
$stmt = $conn->prepare("
    SELECT u.status as agent_status, u.allow_call, u.allow_message,
           a.status as admin_status, a.allow_call as admin_allow_call, a.allow_message as admin_allow_message
    FROM users u 
    LEFT JOIN users a ON u.admin_id = a.id 
    WHERE u.id = ?
");
$stmt->bind_param("i", $agent_id);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();

$agent_status_db = $user_data['agent_status'] ?? 'active';
$admin_status_db = $user_data['admin_status'] ?? 'active';

// --- PERMISSION LOGIC (HIERARCHY) ---
// Agent is allowed ONLY IF: Agent is allowed AND (Parent Admin is allowed OR Parent is NULL/Self)
$can_call = ($user_data['allow_call'] && ($user_data['admin_allow_call'] ?? 1));
$can_message = ($user_data['allow_message'] && ($user_data['admin_allow_message'] ?? 1));

// Convert to JS boolean
$js_can_call = $can_call ? 'true' : 'false';
$js_can_message = $can_message ? 'true' : 'false';

// --- FETCH ASSIGNED CALLER ID ---
$caller_id = '';
$admin_id_for_num = !empty($user_data['admin_id']) ? $user_data['admin_id'] : $agent_id;

$num_stmt = $conn->prepare("SELECT pn.number FROM admin_numbers an JOIN phone_numbers pn ON an.number_id = pn.id WHERE an.admin_id = ? AND an.status = 'active' LIMIT 1");
$num_stmt->bind_param("i", $admin_id_for_num);
$num_stmt->execute();
$num_res = $num_stmt->get_result();
if ($num_res->num_rows > 0) {
    $caller_id = $num_res->fetch_assoc()['number'];
}
// --------------------------------

// --- STATUS CHECK LOGIC FOR AGENT ---
// Priority: Suspended > Unpaid > Inactive

if ($agent_status_db === 'suspended' || $admin_status_db === 'suspended') {
    echo '<body style="background-color: #0f0f1e; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: sans-serif;">
            <div style="text-align: center;">
                <h1 style="font-size: 3rem; color: #ef4444;">Account Suspended</h1>
                <p>Access denied. Please contact your administrator.</p>
                <a href="/callee1/logout.php" style="color: #00d9ff; text-decoration: none; margin-top: 20px; display: inline-block;">Logout</a>
            </div>
          </body>';
    exit;
}

if ($agent_status_db === 'unpaid' || $admin_status_db === 'unpaid' || $agent_status_db === 'inactive' || $admin_status_db === 'inactive') {
    $reason = ($agent_status_db === 'unpaid' || $admin_status_db === 'unpaid') ? 'Account Unpaid / Out of Balance' : 'Account Inactive';
    
    echo '<body style="background-color: #0f0f1e; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: sans-serif;">
            <div style="text-align: center; padding: 40px; background: rgba(255,255,255,0.05); border-radius: 16px; border: 1px solid rgba(255,255,255,0.1);">
                <h1 style="font-size: 2rem; color: #f59e0b;">⚠️ ' . $reason . '</h1>
                <p style="margin: 20px 0; color: #9ca3af;">You cannot access the system at this time.</p>
                <a href="/callee1/logout.php" style="padding: 10px 20px; background: #ef4444; color: white; text-decoration: none; border-radius: 6px;">Logout</a>
            </div>
          </body>';
    exit;
}
// ------------------------------------

$acstatus = $agent_status_db; // Use DB status for display
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Workspace - VoIP Call Center</title>
    <link rel="stylesheet" href="/callee1/assets/css/dashboard.css">
    <link rel="stylesheet" href="/callee1/assets/css/agent.css">
    <link rel="stylesheet" href="/callee1/assets/css/style1.css">
    <script>
        // Inject Telnyx SDK Credentials & Caller ID
        window.AGENT_SDK_CONFIG = {
            caller_id: "<?php echo htmlspecialchars($caller_id); ?>",
            allow_call: <?php echo $js_can_call; ?>,
            allow_message: <?php echo $js_can_message; ?>
        };
    </script>
</head>
<body class="dark-theme">
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Agent Panel</h2>
                <p id="agentName"><?php echo htmlspecialchars($agent_username); ?></p>
                <div class="agent-status-selector">
                    <select id="agentStatus" onchange="changeAgentStatus()">
                        <option value="online">Available</option>
                        <option value="on_break">On Break</option>
                        <option value="offline">Offline</option>
                    </select>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <a href="agent_dashboard.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'dialer') ? 'active' : ''; ?>">
                    <span class="icon">📞</span>
                    <span>Dialer</span>
                </a>
                <a href="agent_messages.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'messages') ? 'active' : ''; ?>">
                    <span class="icon">💬</span>
                    <span>Messages</span>
                </a>
                <a href="agent_leads.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'leads') ? 'active' : ''; ?>">
                    <span class="icon">👥</span>
                    <span>My Leads</span>
                </a>
                <a href="agent_history.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'history') ? 'active' : ''; ?>">
                    <span class="icon">📋</span>
                    <span>Call History</span>
                </a>
                <a href="#" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'performance') ? 'active' : ''; ?>" data-page="performance">
                    <span class="icon">📊</span>
                    <span>My Performance</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="stats-summary">
                    <div class="stat-item">
                        <span class="label">Today's Calls</span>
                        <span class="value" id="todayCalls">0</span>
                    </div>
                    <div class="stat-item">
                        <span class="label">Talk Time</span>
                        <span class="value" id="talkTime">0m</span>
                    </div>
                </div>
                <a href="/callee1/logout.php">
                    <button class="btn-logout">
                        <span class="icon">🚪</span>
                        <span>Logout</span>
                    </button>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-left">
                    <h1 id="pageTitle">Dashboard Overview</h1>
                </div>
                <div class="top-bar-right">
                    <div class="stats-badge">
                        <span class="label">Status</span>
                        <span class="value" id="activeCalls"><?php echo htmlspecialchars($acstatus); ?></span>
                    </div>
                </div>
            </header>