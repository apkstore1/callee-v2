<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$active_menu = 'dialer';
include 'header.php';
?>
            <!-- Dialer Page -->
            <div id="dialerPage" class="page-content active">
                <div class="dialer-layout">
                    <!-- Left Panel - Dialer -->
                    <div class="dialer-panel">
                        <div class="dialer-header">
                            <h2>Dialer</h2>
                            <div class="call-status" id="callStatus">
                                <span class="status-dot"></span>
                                <span class="status-text">Ready</span>
                            </div>
                        </div>
                        
                        <div class="dialer-display">
                            <input type="text" id="phoneNumber" placeholder="Enter phone number" class="phone-input">
                        </div>
                        
                        <div class="dial-pad">
                            <button class="dial-btn" onclick="dialNumber('1')">1</button>
                            <button class="dial-btn" onclick="dialNumber('2')">2<span>ABC</span></button>
                            <button class="dial-btn" onclick="dialNumber('3')">3<span>DEF</span></button>
                            <button class="dial-btn" onclick="dialNumber('4')">4<span>GHI</span></button>
                            <button class="dial-btn" onclick="dialNumber('5')">5<span>JKL</span></button>
                            <button class="dial-btn" onclick="dialNumber('6')">6<span>MNO</span></button>
                            <button class="dial-btn" onclick="dialNumber('7')">7<span>PQRS</span></button>
                            <button class="dial-btn" onclick="dialNumber('8')">8<span>TUV</span></button>
                            <button class="dial-btn" onclick="dialNumber('9')">9<span>WXYZ</span></button>
                            <button class="dial-btn" onclick="dialNumber('*')">*</button>
                            <button class="dial-btn" onclick="dialNumber('0')">0</button>
                            <button class="dial-btn" onclick="dialNumber('#')">#</button>
                        </div>
                        
                        <div class="call-controls">
                            <button class="control-btn call-btn" id="callBtn" onclick="initiateCall()">
                                <span class="icon">📞</span>
                                <span>Call</span>
                            </button>
                            <button class="control-btn hangup-btn" id="hangupBtn" onclick="endCall()" style="display: none;">
                                <span class="icon">📴</span>
                                <span>Hangup</span>
                            </button>
                            <button class="control-btn" id="muteBtn" onclick="toggleMute()" style="display: none;">
                                <span class="icon">🔇</span>
                                <span>Mute</span>
                            </button>
                            <button class="control-btn" id="holdBtn" onclick="toggleHold()" style="display: none;">
                                <span class="icon">⏸️</span>
                                <span>Hold</span>
                            </button>
                        </div>
                        
                        <div class="call-timer" id="callTimer" style="display: none;">
                            <span class="timer-label">Call Duration:</span>
                            <span class="timer-value" id="timerValue">00:00</span>
                        </div>
                    </div>

                    <!-- Right Panel - Lead Info & CRM -->
                    <div class="crm-panel">
                        <div class="panel-header">
                            <h3>Lead Information</h3>
                            <button class="btn-secondary" onclick="loadNextLead()">Next Lead</button>
                        </div>
                        
                        <div id="leadInfo" class="lead-info-container">
                            <div class="empty-state">No lead selected</div>
                        </div>
                        
                        <div id="leadDetails" class="lead-details" style="display: none;">
                            <div class="detail-section">
                                <h4>Contact Details</h4>
                                <div class="detail-row">
                                    <span class="label">Name:</span>
                                    <span class="value" id="leadName">-</span>
                                </div>
                                <div class="detail-row">
                                    <span class="label">Phone:</span>
                                    <span class="value" id="leadPhone">-</span>
                                </div>
                                <div class="detail-row">
                                    <span class="label">Email:</span>
                                    <span class="value" id="leadEmail">-</span>
                                </div>
                                <div class="detail-row">
                                    <span class="label">Address:</span>
                                    <span class="value" id="leadAddress">-</span>
                                </div>
                            </div>
                            
                            <div class="detail-section">
                                <h4>Call Notes</h4>
                                <textarea id="callNotes" placeholder="Enter call notes..." rows="4"></textarea>
                            </div>
                            
                            <div class="detail-section">
                                <h4>Disposition</h4>
                                <select id="disposition" class="disposition-select">
                                    <option value="">Select outcome...</option>
                                    <option value="interested">Interested</option>
                                    <option value="not_interested">Not Interested</option>
                                    <option value="callback">Callback Requested</option>
                                    <option value="no_answer">No Answer</option>
                                    <option value="voicemail">Voicemail</option>
                                    <option value="wrong_number">Wrong Number</option>
                                    <option value="do_not_call">Do Not Call</option>
                                </select>
                            </div>
                            
                            <button class="btn-primary full-width" onclick="saveDisposition()">Save & Next</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Performance Page -->
            <div id="performancePage" class="page-content">
                <div class="page-header">
                    <h1>My Performance</h1>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon blue">📞</div>
                        <div class="stat-info">
                            <h3>Total Calls</h3>
                            <p class="stat-value" id="perfTotalCalls">0</p>
                            <span class="stat-label">This month</span>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon green">⏱️</div>
                        <div class="stat-info">
                            <h3>Talk Time</h3>
                            <p class="stat-value" id="perfTalkTime">0h</p>
                            <span class="stat-label">Total duration</span>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon purple">✅</div>
                        <div class="stat-info">
                            <h3>Conversions</h3>
                            <p class="stat-value" id="perfConversions">0</p>
                            <span class="stat-label">Successful outcomes</span>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon orange">📊</div>
                        <div class="stat-info">
                            <h3>Avg Call Duration</h3>
                            <p class="stat-value" id="perfAvgDuration">0m</p>
                            <span class="stat-label">Per call</span>
                        </div>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h3>Call Activity (Last 7 Days)</h3>
                    <div id="perfChart" style="height: 300px;"></div>
                </div>
            </div>
<?php include 'footer.php'; ?>
