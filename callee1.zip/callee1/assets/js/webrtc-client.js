// SIP.js Client Implementation
let userAgent = null;
let registerer = null;
let activeSession = null;
let remoteAudioElement = null;

window.voiceServerStatus = 'disconnected'; // disconnected, connecting, connected, error
window.voiceServerError = null;

/**
 * Creates and appends a hidden audio element to the body for remote audio.
 */
function createRemoteAudioElement() {
    const existingEl = document.getElementById('remoteAudio');
    if (existingEl) {
        console.log("[SIP.js] Step 1: Found existing <audio id='remoteAudio'> element in HTML.");
        return existingEl;
    }
    console.warn("[SIP.js] Step 1: Could not find <audio id='remoteAudio'>. Creating it dynamically. (It's better to have it in agent_dashboard.php)");
    const audio = document.createElement('audio');
    audio.id = 'remoteAudio';
    audio.autoplay = true;
    document.body.appendChild(audio);
    return audio;
}

/**
 * Initializes the SIP User Agent.
 * Fetches credentials and connects to the SIP server.
 */
async function initializeSIP(callerId) {
    console.log("[SIP.js] Starting initialization...");
    window.voiceServerStatus = 'connecting';
    remoteAudioElement = createRemoteAudioElement();

    // 1. Fetch SIP Credentials from Backend
    let sipConfig = {};
    try {
        console.log("[SIP.js] Fetching SIP credentials...");
        const response = await fetch(window.APP_BASE_URL + '/get_sip_credentials.php', { cache: 'no-store' });
        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || `HTTP Error ${response.status}`);
        }
        
        // Asterisk Server Config (AWS IP)
        // SSL ke liye Domain Name zaroori hai (IP par SSL error dega)
        const asteriskDomain = window.location.hostname; 
        const asteriskPort = '8089'; // Standard Asterisk WSS Port (SSL)

        sipConfig = {
            uri: SIP.UserAgent.makeURI(`sip:${data.username}@${asteriskDomain}`),
            authorizationUsername: data.username,
            authorizationPassword: data.password,
            contactParams: { transport: 'wss' }, // Yeh line add ki hai taake Contact header mein transport=wss jaye
            transportOptions: {
                server: `wss://${asteriskDomain}:${asteriskPort}/ws`,
                traceSip: true
            },
            hackIpInContact: true,
            viaHost: asteriskDomain,
            logLevel: 'debug', // Debugging ke liye
            iceGatheringTimeout: 500, // ICE candidates gather hone ke liye thoda wait karega
            // Fix: Handle Incoming Call (Auto-Answer & Mic Permission)
            delegate: {
                onInvite: (invitation) => {
                    // Header check karne ka sab se pakka tarika (Raw Headers)
                    let callInfo = '';
                    if (invitation.request.headers && invitation.request.headers['Call-Info'] && invitation.request.headers['Call-Info'][0]) {
                        callInfo = invitation.request.headers['Call-Info'][0].raw;
                    } else {
                        callInfo = invitation.request.getHeader('Call-Info') || '';
                    }
                    
                    console.log("Full Call-Info Header:", callInfo);

                    const options = {
                        sessionDescriptionHandlerOptions: {
                            constraints: { audio: true, video: false },
                            // [FIX] Official way to handle tracks in SIP.js v0.20.0
                            peerConnectionDelegate: {
                                ontrack: (event) => {
                                    console.warn('[SIP.js] !!! TRACK RECEIVED via PC Delegate !!!', event.track.kind);
                                    const remoteStream = event.streams[0] || new MediaStream([event.track]);
                                    if (remoteAudioElement) {
                                        remoteAudioElement.srcObject = remoteStream;
                                        remoteAudioElement.muted = false;
                                        remoteAudioElement.play().catch(e => console.error("Playback failed:", e));
                                    }
                                }
                            }
                        }
                    };

                    invitation.stateChange.addListener((state) => {
                        if (state === SIP.SessionState.Established) {
                            console.log("Call Established Success!");
                            
                            // [FIX] Manual Track Grabber (Fallback for v0.20.0 NAT Issues)
                            const sdh = invitation.sessionDescriptionHandler;
                            if (sdh && sdh.peerConnection) {
                                const pc = sdh.peerConnection;
                                const remoteStream = new MediaStream();
                                
                                pc.getReceivers().forEach(receiver => {
                                    if (receiver.track) {
                                        console.log("[SIP.js] Found track manually:", receiver.track.kind);
                                        remoteStream.addTrack(receiver.track);
                                    }
                                });

                                if (remoteAudioElement && remoteStream.getTracks().length > 0) {
                                    remoteAudioElement.srcObject = remoteStream;
                                    remoteAudioElement.play().catch(e => console.error("Play failed:", e));
                                }
                            }

                            if (typeof window.handleIncomingCall === 'function') window.handleIncomingCall();
                        }

                        if (state === SIP.SessionState.Terminated) {
                            activeSession = null;
                            if (typeof window.endCallUI === 'function') window.endCallUI();
                        }
                    });

                    activeSession = invitation;

                    // [FIX 2]: Auto-Answer ya Popup flow
                    if (callInfo.includes('answer-after=0')) {
                        console.log("Auto-Answering...");
                        const popup = document.getElementById('incoming-call-popup');
                        if (popup) popup.remove();
                        if (typeof window.handleIncomingCall === 'function') window.handleIncomingCall();
                        invitation.accept(options);
                    } else {
                        showIncomingCallPopup(invitation, options, () => {
                            console.log("User answered via popup");
                        });
                    }
                }

            },
            sessionDescriptionHandlerFactoryOptions: {
                peerConnectionConfiguration: {
                    iceServers: [
                        { urls: 'stun:stun.l.google.com:19302' },
                        { urls: 'stun:stun1.l.google.com:19302' }
                    ],
                    iceTransportPolicy: 'all'
                },
                preferredAudioCodecs: ['PCMU', 'PCMA']
            }
        };
        console.log("[SIP.js] Credentials received for:", data.username);
        console.log("[SIP.js] Password being used:", data.password); // Check karein ke yeh '100' hai ya 'password100'

    } catch (error) {
        console.error("[SIP.js] Failed to get credentials:", error);
        window.voiceServerStatus = 'error';
        window.voiceServerError = error.message;
        if(typeof updateCallStatusDisplay === 'function') updateCallStatusDisplay('offline');
        return;
    }

    // 2. Initialize SIP.js UserAgent
    try {
        userAgent = new SIP.UserAgent(sipConfig);

        await userAgent.start();
        console.log("[SIP.js] UserAgent started.");

        // Initialize Registerer for SIP Registration (SIP.js v0.20.0+)
        registerer = new SIP.Registerer(userAgent);

        registerer.stateChange.addListener((newState) => {
            console.log(`[SIP.js] Registration state changed: ${newState}`);
            switch (newState) {
                case SIP.RegistererState.Registered:
                    console.log('Agent Online (SIP Registered)');
                    window.voiceServerStatus = 'connected';
                    if(typeof updateCallStatusDisplay === 'function') updateCallStatusDisplay('online');
                    break;
                case SIP.RegistererState.Unregistered:
                case SIP.RegistererState.Terminated:
                    console.warn('Agent Offline (SIP Unregistered)');
                    window.voiceServerStatus = 'disconnected';
                    if(typeof updateCallStatusDisplay === 'function') updateCallStatusDisplay('offline');
                    break;
            }
        });

        await registerer.register();

    } catch (e) {
        console.error("[SIP.js] Error initializing UserAgent:", e);
        let errorMsg = "SIP Client Initialization Failed: " + e.message;
        if (e.message && e.message.includes("code: 1006")) {
            errorMsg = `Connection Failed (1006). Browser cannot reach wss://${asteriskDomain}:${asteriskPort}/ws.\n1. Check AWS Security Group (Allow Port ${asteriskPort}).\n2. Check if Asterisk HTTP Server (TLS) is running.`;
        }
        window.voiceServerStatus = 'error';
        window.voiceServerError = errorMsg;
        if(typeof updateCallStatusDisplay === 'function') updateCallStatusDisplay('offline');
        return;
    }

    // 3. Expose client globally for dialer.js
    window.webrtcClient = {
        isConnected: () => registerer && registerer.state === SIP.RegistererState.Registered,
        
        // Jani, yeh raha tumhara requested inviter function
        dialNumber: async (target, fromNumber) => {
            console.log(`[AMI] Triggering call to ${target} via Asterisk API...`);
            
            try {
                const response = await fetch(window.APP_BASE_URL + '/api/asterisk/make_call.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        phone_number: target,
                        lead_id: (typeof currentLead !== 'undefined' && currentLead) ? currentLead.id : null
                    })
                });
                
                const data = await response.json();
                console.log("[AMI] Call Response:", data);
                
                if (data.success) {
                    console.log("[AMI] Call initiated");
                    // Force UI Change
                    if (typeof window.handleIncomingCall === 'function') window.handleIncomingCall();
                } else {
                    console.error("[AMI] Call failed:", data.message);
                    alert("Call Failed: " + data.message);
                }
            } catch (error) {
                console.error("[AMI] API Error:", error);
            }
        },

        makeCall: async (phoneNumber) => {
            // Wrapper for dialer.js compatibility
            // Fix: Check both closure variable AND global config
            const fromNumber = callerId || (window.AGENT_SDK_CONFIG && window.AGENT_SDK_CONFIG.caller_id);
            console.log("[SIP.js] Making call. From:", fromNumber, "To:", phoneNumber);
            
            if (!fromNumber) {
                alert("Caller ID not found. Please assign a phone number to this agent in the Admin Panel.");
                return;
            }
            return window.webrtcClient.dialNumber(phoneNumber, fromNumber);
        },
        
        endCall: () => {
            if (activeSession) {
                if (activeSession.state === SIP.SessionState.Established) {
                    activeSession.bye();
                } else if (activeSession.state === SIP.SessionState.Initial || activeSession.state === SIP.SessionState.Establishing) {
                    activeSession.cancel();
                }
                activeSession = null;
            }
        },
        
        mute: () => {
            if (activeSession && activeSession.sessionDescriptionHandler) {
                const pc = activeSession.sessionDescriptionHandler.peerConnection;
                pc.getSenders().forEach(sender => {
                    if (sender.track && sender.track.kind === 'audio') {
                        sender.track.enabled = false;
                    }
                });
                console.log("[SIP.js] Audio Muted");
            }
        },
        
        unmute: () => {
            if (activeSession && activeSession.sessionDescriptionHandler) {
                const pc = activeSession.sessionDescriptionHandler.peerConnection;
                pc.getSenders().forEach(sender => {
                    if (sender.track && sender.track.kind === 'audio') {
                        sender.track.enabled = true;
                    }
                });
                console.log("[SIP.js] Audio Unmuted");
            }
        }
    };
}

// The initialization is now called from agent.js on window 'load' event.
// To avoid breaking agent.js, I'll keep the old name.
const initializeWebRTC = initializeSIP;

/**
 * Shows a popup for incoming calls
 */
function showIncomingCallPopup(invitation, options, onAnswer) {
    // Remove existing popup if any
    const existing = document.getElementById('incoming-call-popup');
    if (existing) existing.remove();

    const popup = document.createElement('div');
    popup.id = 'incoming-call-popup';
    popup.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #1f2937;
        color: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        z-index: 10000;
        font-family: sans-serif;
        min-width: 280px;
        border: 1px solid #374151;
        animation: slideIn 0.3s ease-out;
    `;

    const callerName = invitation.remoteIdentity.displayName || invitation.remoteIdentity.uri.user;
    
    popup.innerHTML = `
        <div style="display:flex; align-items:center; margin-bottom:15px;">
            <div style="background:#3b82f6; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin-right:12px; font-size:20px;">📞</div>
            <div>
                <div style="font-size:14px; color:#9ca3af;">Incoming Call</div>
                <div style="font-size:18px; font-weight:bold;">${callerName}</div>
            </div>
        </div>
        <div style="display:flex; gap:10px;">
            <button id="btn-reject" style="flex:1; background:#ef4444; color:white; border:none; padding:10px; border-radius:6px; cursor:pointer; font-weight:bold;">Reject</button>
            <button id="btn-answer" style="flex:1; background:#10b981; color:white; border:none; padding:10px; border-radius:6px; cursor:pointer; font-weight:bold;">Answer</button>
        </div>
    `;

    document.body.appendChild(popup);

    document.getElementById('btn-answer').onclick = () => {
        popup.remove();
        invitation.accept(options).then(onAnswer).catch(e => console.error("[SIP.js] Failed to answer:", e));
    };

    document.getElementById('btn-reject').onclick = () => {
        popup.remove();
        invitation.reject();
    };
}