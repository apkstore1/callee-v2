const API_URL = "/callee1/admin/campaigns" // Absolute path to the campaign API
let currentCampaigns = []

// Load campaigns
async function loadCampaigns() {
  try {
    const response = await fetch(`${API_URL}/get_all.php`)
    const data = await response.json()

    if (data.success) {
      currentCampaigns = data.data
      renderCampaignsTable(data.data)
      populateCampaignSelects(data.data)
    }
  } catch (error) {
    console.error("Error loading campaigns:", error)
  }
}

function renderCampaignsTable(campaigns) {
  const tbody = document.getElementById("campaignsTableBody")
  if (!tbody) return

  if (campaigns.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No campaigns found</td></tr>'
    return
  }

  tbody.innerHTML = campaigns
    .map(
      (campaign) => `
        <tr>
            <td>
                <div style="font-weight: 600;">${campaign.name}</div>
                ${campaign.description ? `<div style="font-size: 12px; color: var(--text-muted);">${campaign.description}</div>` : ""}
            </td>
            <td><span class="role-badge">${campaign.dial_method}</span></td>
            <td><span class="status-badge status-${campaign.status}">${campaign.status}</span></td>
            <td>${campaign.total_leads || 0}</td>
            <td>${campaign.contacted_leads || 0}</td>
            <td>${campaign.start_date ? new Date(campaign.start_date).toLocaleDateString() : "N/A"}</td>
            <td>
                <button class="action-btn" onclick="editCampaign(${campaign.id})">Edit</button>
                <button class="action-btn danger" onclick="deleteCampaign(${campaign.id})">Delete</button>
            </td>
        </tr>
    `,
    )
    .join("")
}

function populateCampaignSelects(campaigns) {
  const leadFilter = document.getElementById("leadCampaignFilter")
  const importSelect = document.getElementById("importCampaignSelect")

  const options = campaigns.map((campaign) => `<option value="${campaign.id}">${campaign.name}</option>`).join("")

  if (leadFilter) {
    leadFilter.innerHTML = '<option value="">Select Campaign</option>' + options
  }

  if (importSelect) {
    importSelect.innerHTML = '<option value="">Choose a campaign</option>' + options
  }
}

function openCreateCampaignModal() {
  document.getElementById("createCampaignModal").classList.add("show")
  
  // Check permissions
  const autoOption = document.getElementById("optionAutoDial")
  const msg = document.getElementById("autoDialMsg")
  
  if (typeof USER_PERMISSIONS !== 'undefined' && USER_PERMISSIONS.allow_auto_dial == 1) {
      autoOption.disabled = false
      msg.style.display = 'none'
  } else {
      autoOption.disabled = true
      msg.style.display = 'block'
  }
}

function closeCreateCampaignModal() {
  document.getElementById("createCampaignModal").classList.remove("show")
  document.getElementById("createCampaignForm").reset()
}

function toggleCampaignUpload() {
    const method = document.getElementById("createDialMethod").value
    document.getElementById("campaignUploadDiv").style.display = (method === 'auto') ? 'block' : 'none'
}

const createCampaignForm = document.getElementById("createCampaignForm")
if (createCampaignForm) {
  createCampaignForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    // No need to convert to JSON, send FormData directly for file upload support

    try {
      const response = await fetch(`${API_URL}/process.php`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        alert("Campaign created successfully!")
        closeCreateCampaignModal()
        loadCampaigns()
      } else {
        alert("Error: " + data.message)
      }
    } catch (error) {
      alert("Error creating campaign")
      console.error(error)
    }
  })
}

async function deleteCampaign(id) {
    if(!confirm("Are you sure you want to delete this campaign?")) return;
    
    const formData = new FormData();
    formData.append('action', 'delete');
    formData.append('id', id);
    
    try {
        const response = await fetch(`${API_URL}/process.php`, {
            method: "POST",
            body: formData
        });
        const data = await response.json();
        if(data.success) loadCampaigns();
        else alert(data.message);
    } catch(e) {
        console.error(e);
    }
}

// Load leads by campaign
async function filterLeads() {
  const campaignId = document.getElementById("leadCampaignFilter").value

  if (!campaignId) {
    document.getElementById("leadsTableBody").innerHTML =
      '<tr><td colspan="7" class="text-center">Select a campaign</td></tr>'
    return
  }

  try {
    const response = await fetch(`${API_URL}/leads/get_by_campaign.php?campaign_id=${campaignId}`)
    const data = await response.json()

    if (data.success) {
      renderLeadsTable(data.data)
    }
  } catch (error) {
    console.error("Error loading leads:", error)
  }
}

function renderLeadsTable(leads) {
  const tbody = document.getElementById("leadsTableBody")

  if (leads.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No leads found</td></tr>'
    return
  }

  tbody.innerHTML = leads
    .map(
      (lead) => `
        <tr>
            <td>
                <div style="font-weight: 600;">${lead.first_name || ""} ${lead.last_name || ""}</div>
            </td>
            <td>${lead.phone}</td>
            <td>${lead.email || "N/A"}</td>
            <td><span class="status-badge status-${lead.status}">${lead.status}</span></td>
            <td>${lead.agent_name || "Unassigned"}</td>
            <td>${lead.updated_at ? new Date(lead.updated_at).toLocaleDateString() : "Never"}</td>
            <td>
                <button class="action-btn" onclick="viewLead(${lead.id})">View</button>
                <button class="action-btn" onclick="callLead('${lead.phone}')">Call</button>
            </td>
        </tr>
    `,
    )
    .join("")
}

function openImportLeadsModal() {
  document.getElementById("importLeadsModal").classList.add("show")
}

function closeImportLeadsModal() {
  document.getElementById("importLeadsModal").classList.remove("show")
  document.getElementById("importLeadsForm").reset()
}

document.getElementById("importLeadsForm").addEventListener("submit", async (e) => {
  e.preventDefault()

  const campaignId = document.getElementById("importCampaignSelect").value
  const fileInput = document.getElementById("csvFile")

  if (!campaignId || !fileInput.files[0]) {
    alert("Please select a campaign and upload a CSV file")
    return
  }

  const file = fileInput.files[0]
  const text = await file.text()
  const rows = text.split("\n").slice(1) // Skip header

  const leads = rows
    .filter((row) => row.trim())
    .map((row) => {
      const [first_name, last_name, phone, email, address, city, state, zip] = row.split(",")
      return { first_name, last_name, phone, email, address, city, state, zip }
    })

  try {
    const response = await fetch(`${API_URL}/leads/import.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ campaign_id: campaignId, leads }),
    })

    const data = await response.json()

    if (data.success) {
      alert(`Successfully imported ${data.inserted} leads! ${data.failed} failed.`)
      closeImportLeadsModal()
      filterLeads()
    } else {
      alert("Error: " + data.message)
    }
  } catch (error) {
    alert("Error importing leads")
    console.error(error)
  }
})

function editCampaign(id) {
  // This should redirect to an edit page. For now, it's a placeholder.
  alert("Edit campaign functionality will be implemented on a separate page. ID: " + id)
}

function viewLead(id) {
  alert("View lead details - ID: " + id)
}

function openAddAgentModal() {
  alert("Add agent modal will be implemented")
}

// Load page data based on navigation
window.addEventListener("DOMContentLoaded", () => {
  // The loadCampaigns() function is now called from the campaign/index.php page itself.
})
