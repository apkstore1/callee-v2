const API_URL = "/api"
let currentUser = null

// Check authentication on page load
document.addEventListener("DOMContentLoaded", async () => {
  const user = localStorage.getItem("user")
  // Redirect removed: Authentication is now handled by PHP sessions
  // if (!user) {
  //   window.location.href = "/index.html"
  //   return
  // }

  currentUser = JSON.parse(user)
  const nameElement = document.getElementById("adminName")
  if (nameElement) {
    nameElement.textContent = currentUser.full_name
  }

  // Setup navigation
  setupNavigation()

  // Load initial data
  loadDashboardData()
})

function setupNavigation() {
  const navItems = document.querySelectorAll(".nav-item")
  const pages = document.querySelectorAll(".page-content")

  navItems.forEach((item) => {
    item.addEventListener("click", (e) => {
      e.preventDefault()

      const page = item.dataset.page

      // Update active states
      navItems.forEach((nav) => nav.classList.remove("active"))
      item.classList.add("active")

      // Show selected page
      pages.forEach((p) => p.classList.remove("active"))
      const pageElement = document.getElementById(`${page}Page`)
      if (pageElement) {
        pageElement.classList.add("active")
      }

      // Update page title
      document.getElementById("pageTitle").textContent = item.textContent.trim()

      // Load page data
      loadPageData(page)
    })
  })
}

async function loadDashboardData() {
  try {
    // Simulate loading stats - will be replaced by actual API calls
    document.getElementById("totalUsers").textContent = "0"
    document.getElementById("todayCalls").textContent = "0"
    document.getElementById("totalDuration").textContent = "0h 0m"
    document.getElementById("totalCredits").textContent = "$0.00"
    document.getElementById("activeCalls").textContent = "0"
    document.getElementById("onlineAgents").textContent = "0"
  } catch (error) {
    console.error("Error loading dashboard:", error)
  }
}

async function loadPageData(page) {
  switch (page) {
    case "users":
      // Declare or import loadUsers here
      break
    case "asterisk":
      // Declare or import loadAsteriskServers here
      break
    case "credits":
      // Declare or import loadCreditTransactions here
      break
    case "calls":
      // Declare or import loadCallLogs here
      break
    case "campaigns":
      // Declare or import loadCampaigns here
      break
    case "reports":
      // Declare or import loadReports here
      break
  }
}


