const AGENT_API_URL = "/callee1/api"
let callStartTime = null
let callTimerInterval = null
let isMuted = false
let isOnHold = false
// webrtcClient is assumed to be initialized globally or in agent.js/webrtc-client.js

// Dialer functions
function dialNumber(digit) {
  const input = document.getElementById("phoneNumber")
  if (input) {
    input.value += digit
  }
}

async function initiateCall() {
  // Check Permissions
  if (window.AGENT_SDK_CONFIG && window.AGENT_SDK_CONFIG.allow_call === false) {
      alert("Calling is disabled by your administrator.");
      return;
  }

  const phoneNumber = document.getElementById("phoneNumber").value
  // Check if currentLead exists globally (from agent.js) or is null
  const leadId = (typeof currentLead !== 'undefined' && currentLead) ? currentLead.id : null;

  if (!phoneNumber) {
    alert("Please enter a phone number")
    return
  }

  console.log("[Dialer] Initiating call to:", phoneNumber)

  try {
    // Use WebRTC client if available and connected
    if (typeof webrtcClient !== 'undefined' && webrtcClient && webrtcClient.isConnected) {
      await webrtcClient.makeCall(phoneNumber)
    } else {
      // Auto-Reconnect Logic
      console.log("[Dialer] Voice server not ready. Status:", window.voiceServerStatus);
      
      if (window.voiceServerStatus === 'error') {
          alert("Voice Server Error: " + (window.voiceServerError || "Unknown Error") + ". Please refresh.");
          return;
      }

      // Try to initialize if not connected
      if (typeof initializeWebRTC === 'function') {
          console.log("[Dialer] Attempting to reconnect...");
          const callerId = window.AGENT_SDK_CONFIG ? window.AGENT_SDK_CONFIG.caller_id : null;
          await initializeWebRTC(callerId);
          
          // Check again after reconnection attempt
          if (typeof webrtcClient !== 'undefined' && webrtcClient && webrtcClient.isConnected) {
              await webrtcClient.makeCall(phoneNumber);
              return;
          }
      }

      alert("Voice Server not connected. Status: " + window.voiceServerStatus + ". Please check internet or refresh.");
      return;
    }

    // Update UI for calling state
    const callBtn = document.getElementById("callBtn")
    const hangupBtn = document.getElementById("hangupBtn")
    const muteBtn = document.getElementById("muteBtn")
    const holdBtn = document.getElementById("holdBtn")
    const callTimer = document.getElementById("callTimer")

    if(callBtn) callBtn.style.display = "none"
    if(hangupBtn) hangupBtn.style.display = "flex"
    if(muteBtn) muteBtn.style.display = "flex"
    if(holdBtn) holdBtn.style.display = "flex"
    if(callTimer) callTimer.style.display = "block"

    if (typeof updateCallStatusDisplay === 'function') {
        updateCallStatusDisplay("on_call")
    }

    // Start call timer
    callStartTime = Date.now()
    callTimerInterval = setInterval(updateCallTimer, 1000)
  } catch (error) {
    console.error("[Dialer] Error initiating call:", error)
    alert("Failed to initiate call: " + error.message)
  }
}

function endCall() {
  console.log("[Dialer] Ending call")

  // End call via WebRTC if available
  if (typeof webrtcClient !== 'undefined' && webrtcClient) {
    webrtcClient.endCall()
  }

  // Stop timer
  if (callTimerInterval) {
    clearInterval(callTimerInterval)
    callTimerInterval = null
  }

  // Calculate call duration
  const duration = callStartTime ? Math.floor((Date.now() - callStartTime) / 1000) : 0

  // Update UI
  const callBtn = document.getElementById("callBtn")
  const hangupBtn = document.getElementById("hangupBtn")
  const muteBtn = document.getElementById("muteBtn")
  const holdBtn = document.getElementById("holdBtn")
  const callTimer = document.getElementById("callTimer")

  if(callBtn) callBtn.style.display = "flex"
  if(hangupBtn) hangupBtn.style.display = "none"
  if(muteBtn) muteBtn.style.display = "none"
  if(holdBtn) holdBtn.style.display = "none"
  if(callTimer) callTimer.style.display = "none"

  if (typeof updateCallStatusDisplay === 'function') {
      updateCallStatusDisplay("online")
  }

  // Log call end
  logCallEnd(duration)
}

// Helper for WebRTC callback
function endCallUI() {
    endCall();
}

function toggleMute() {
  isMuted = !isMuted

  if (typeof webrtcClient !== 'undefined' && webrtcClient) {
    if (isMuted) {
      webrtcClient.mute()
    } else {
      webrtcClient.unmute()
    }
  }

  const muteBtn = document.getElementById("muteBtn")
  if(muteBtn) {
      muteBtn.querySelector(".icon").textContent = isMuted ? "🔊" : "🔇"
      muteBtn.querySelector("span:last-child").textContent = isMuted ? "Unmute" : "Mute"
  }
}

function toggleHold() {
  isOnHold = !isOnHold
  const holdBtn = document.getElementById("holdBtn")
  if(holdBtn) {
      holdBtn.querySelector(".icon").textContent = isOnHold ? "▶️" : "⏸️"
      holdBtn.querySelector("span:last-child").textContent = isOnHold ? "Resume" : "Hold"
  }
}

function updateCallTimer() {
  if (!callStartTime) return

  const elapsed = Math.floor((Date.now() - callStartTime) / 1000)
  const minutes = Math.floor(elapsed / 60)
  const seconds = elapsed % 60

  const timerValue = document.getElementById("timerValue")
  if(timerValue) {
      timerValue.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
  }
}

async function logCallEnd(duration) {
  try {
    await fetch(`${AGENT_API_URL}/calls/end.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        duration: duration,
        call_status: "answered",
      }),
    })
  } catch (error) {
    console.error("[Dialer] Error ending call:", error)
  }
}