document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault()

  const username = document.getElementById("username").value
  const password = document.getElementById("password").value
  const errorMessage = document.getElementById("errorMessage")
  const loginBtn = document.getElementById("loginBtn")

  // Hide previous errors
  errorMessage.style.display = "none"

  // Disable button
  loginBtn.disabled = true
  loginBtn.textContent = "Signing in..."

  try {
    const response = await fetch("api/auth/login.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    })

    const data = await response.json()

    if (data.success) {
      // Redirect based on role
      switch (data.role) {
        case "super_admin":
          window.location.href = "super-admin.html"
          break
        case "admin":
          window.location.href = "admin.html"
          break
        case "agent":
          window.location.href = "agent.html"
          break
        default:
          window.location.href = "agent.html"
      }
    } else {
      errorMessage.textContent = data.message || "Login failed. Please check your credentials."
      errorMessage.style.display = "block"
      loginBtn.disabled = false
      loginBtn.textContent = "Sign In"
    }
  } catch (error) {
    console.error("[v0] Login error:", error)
    errorMessage.textContent = "Connection error. Please try again."
    errorMessage.style.display = "block"
    loginBtn.disabled = false
    loginBtn.textContent = "Sign In"
  }
})
