// AGENT_API_URL is already defined in dialer.js
if (typeof AGENT_API_URL === 'undefined') console.error("Dialer script not loaded!");
let currentLead = null

// Agent status management
async function changeAgentStatus() {
  const status = document.getElementById("agentStatus").value
  console.log("[v0] Changing agent status to:", status)

  try {
    // Update status in database
    const response = await fetch(`/callee1/update_status.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    })

    if (response.ok) {
      updateCallStatusDisplay(status)
    }
  } catch (error) {
    console.error("[v0] Error updating status:", error)
  }
}

function updateCallStatusDisplay(status) {
  const statusDot = document.querySelector(".status-dot")
  const statusText = document.querySelector(".status-text")

  statusDot.className = "status-dot"

  switch (status) {
    case "online":
      statusText.textContent = "Available"
      break
    case "on_call":
      statusDot.classList.add("calling")
      statusText.textContent = "On Call"
      break
    case "on_break":
      statusDot.classList.add("offline")
      statusText.textContent = "On Break"
      break
    case "offline":
      statusDot.classList.add("offline")
      statusText.textContent = "Offline"
      break
  }
}

// Lead management
async function loadNextLead() {
  try {
    const response = await fetch(`/callee1/get_next_lead.php`)
    const data = await response.json()

    if (data.success && data.data) {
      currentLead = data.data
      displayLeadInfo(data.data)
    } else {
      alert(data.message || "No more leads available")
    }
  } catch (error) {
    console.error("[v0] Error loading lead:", error)
  }
}

function displayLeadInfo(lead) {
  document.getElementById("leadInfo").style.display = "none"
  document.getElementById("leadDetails").style.display = "flex"

  document.getElementById("leadName").textContent = `${lead.first_name || ""} ${lead.last_name || ""}`
  document.getElementById("leadPhone").textContent = lead.phone_number || lead.phone || "-"
  document.getElementById("leadEmail").textContent = lead.email || "-"
  document.getElementById("leadAddress").textContent =
    `${lead.address || ""} ${lead.city || ""} ${lead.state || ""} ${lead.zip || ""}`.trim() || "-"

  document.getElementById("phoneNumber").value = lead.phone_number || lead.phone
  document.getElementById("callNotes").value = lead.notes || ""
}

async function saveDisposition() {
  const disposition = document.getElementById("disposition").value
  const notes = document.getElementById("callNotes").value

  if (!disposition) {
    alert("Please select a disposition")
    return
  }

  if (!currentLead) {
    alert("No lead selected")
    return
  }

  try {
    await fetch(`/callee1/save_disposition.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        lead_id: currentLead.id,
        disposition: disposition,
        notes: notes,
      }),
    })

    alert("Disposition saved successfully!")

    document.getElementById("disposition").value = ""
    document.getElementById("callNotes").value = ""
    document.getElementById("phoneNumber").value = ""

    loadNextLead()
  } catch (error) {
    console.error("[v0] Error saving disposition:", error)
    alert("Error saving disposition")
  }
}

async function filterMyLeads() {
  const status = document.getElementById("leadStatusFilter").value

  try {
    const params = new URLSearchParams()
    if (status) params.append("status", status)

    const response = await fetch(`/callee1/get_my_leads.php?${params}`)
    const data = await response.json()

    if (data.success) {
      renderMyLeadsTable(data.data)
    }
  } catch (error) {
    console.error("[v0] Error loading leads:", error)
  }
}

function renderMyLeadsTable(leads) {
  const tbody = document.getElementById("myLeadsTableBody")

  if (leads.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No leads assigned</td></tr>'
    return
  }

  tbody.innerHTML = leads
    .map(
      (lead) => `
        <tr>
            <td>${lead.phone_number || lead.phone}</td>
            <td><span class="status-badge status-${lead.status}">${lead.status}</span></td>
            <td>${lead.campaign_name || "N/A"}</td>
            <td>${lead.created_at ? new Date(lead.created_at).toLocaleDateString() : "N/A"}</td>
            <td>
                <button class="action-btn" onclick="loadLeadToDialer(${lead.id})">Call</button>
            </td>
        </tr>
    `,
    )
    .join("")
}

async function loadLeadToDialer(leadId) {
  try {
    // Agar hum leads page par hain (dialer page nahi hai), toh dashboard par redirect karein lead ID ke saath
    if (!document.getElementById('dialerPage')) {
        window.location.href = `agent_dashboard.php?dial_lead=${leadId}`;
        return;
    }

    const response = await fetch(`/callee1/get_lead.php?id=${leadId}`)
    const data = await response.json()

    if (data.success) {
      currentLead = data.data
      displayLeadInfo(data.data)

      // Switch to dialer tab if we are in SPA mode
      const dialerLink = document.querySelector('[data-page="dialer"]');
      if (dialerLink) dialerLink.click();
    }
  } catch (error) {
    console.error("[v0] Error loading lead:", error)
  }
}

function openNewMessageModal() {
  alert("New message modal will be implemented")
}

// Initialize on load
window.addEventListener("DOMContentLoaded", async () => {
  const user = localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : null;
  if (user) {
    const nameEl = document.getElementById("agentName");
    if(nameEl) nameEl.textContent = user.full_name
  }

  // Setup navigation for agent panel
  setupNavigation()

  // Check URL parameters for auto-dialing a lead (from agent_leads.php redirect)
  const urlParams = new URLSearchParams(window.location.search);
  const dialLeadId = urlParams.get('dial_lead');
  if (dialLeadId) {
      loadLeadToDialer(dialLeadId);
      // Clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
  }
})

// Initialize WebRTC only after EVERYTHING (including external scripts) is loaded
window.addEventListener("load", async () => {
  try {
    // Initialize Telnyx SDK
    const callerId = window.AGENT_SDK_CONFIG ? window.AGENT_SDK_CONFIG.caller_id : null;
    if (typeof initializeWebRTC === 'function') {
        await initializeWebRTC(callerId);
    }
  } catch (error) {
    console.error("[Agent] SDK initialization failed:", error);
  }
});

// initializeWebRTC is now loaded from assets/js/webrtc-client.js

function setupNavigation() {
  const navItems = document.querySelectorAll(".nav-item")
  const pages = document.querySelectorAll(".page-content")

  navItems.forEach((item) => {
    item.addEventListener("click", (e) => {
      const page = item.dataset.page
      
      // Agar data-page attribute nahi hai, toh normal link navigation hone dein
      if (!page) return;

      e.preventDefault()

      navItems.forEach((nav) => nav.classList.remove("active"))
      item.classList.add("active")

      pages.forEach((p) => p.classList.remove("active"))
      const pageElement = document.getElementById(`${page}Page`)
      if (pageElement) {
        pageElement.classList.add("active")
      }

      if (page === "leads") {
        filterMyLeads()
      }
    })
  })
}
