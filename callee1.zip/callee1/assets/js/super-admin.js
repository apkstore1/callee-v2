// Super Admin specific functionality

let allUsers = []
const API_URL = "https://your-api-url.com" // Declare API_URL variable

async function loadUsers() {
  try {
    const search = document.getElementById("userSearch").value
    const role = document.getElementById("roleFilter").value
    const status = document.getElementById("statusFilter").value

    const params = new URLSearchParams()
    if (search) params.append("search", search)
    if (role) params.append("role", role)
    if (status) params.append("status", status)

    const response = await fetch(`${API_URL}/users/get_all.php?${params}`)
    const data = await response.json()

    if (data.success) {
      allUsers = data.data
      renderUsersTable(data.data)
    }
  } catch (error) {
    console.error("Error loading users:", error)
  }
}

function renderUsersTable(users) {
  const tbody = document.getElementById("usersTableBody")

  if (users.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No users found</td></tr>'
    return
  }

  tbody.innerHTML = users
    .map(
      (user) => `
        <tr>
            <td>
                <div style="font-weight: 600;">${user.full_name}</div>
                <div style="font-size: 12px; color: var(--text-muted);">${user.username}</div>
            </td>
            <td>${user.email}</td>
            <td><span class="role-badge role-${user.role}">${user.role.replace("_", " ")}</span></td>
            <td><span class="status-badge status-${user.status}">${user.status}</span></td>
            <td>$${Number.parseFloat(user.credits).toFixed(2)}</td>
            <td>${user.last_login ? new Date(user.last_login).toLocaleDateString() : "Never"}</td>
            <td>
                <button class="action-btn" onclick="editUser(${user.id})">Edit</button>
                <button class="action-btn danger" onclick="deleteUser(${user.id})">Delete</button>
            </td>
        </tr>
    `,
    )
    .join("")
}

function filterUsers() {
  loadUsers()
}

function openCreateUserModal() {
  document.getElementById("createUserModal").classList.add("show")
}

function closeCreateUserModal() {
  document.getElementById("createUserModal").classList.remove("show")
  document.getElementById("createUserForm").reset()
}

document.getElementById("createUserForm").addEventListener("submit", async (e) => {
  e.preventDefault()

  const formData = new FormData(e.target)
  const userData = Object.fromEntries(formData)

  try {
    const response = await fetch(`${API_URL}/users/create.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    })

    const data = await response.json()

    if (data.success) {
      alert(
        `User created successfully!\n\nSIP Extension: ${data.data.sip_extension}\nSIP Password: ${data.data.sip_password}`,
      )
      closeCreateUserModal()
      loadUsers()
    } else {
      alert("Error: " + data.message)
    }
  } catch (error) {
    alert("Error creating user")
    console.error(error)
  }
})

function editUser(userId) {
  alert("Edit user functionality will be implemented")
}

async function deleteUser(userId) {
  if (!confirm("Are you sure you want to delete this user?")) return

  try {
    const response = await fetch(`${API_URL}/users/delete.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id: userId }),
    })

    const data = await response.json()

    if (data.success) {
      alert("User deleted successfully")
      loadUsers()
    } else {
      alert("Error: " + data.message)
    }
  } catch (error) {
    alert("Error deleting user")
    console.error(error)
  }
}

async function loadAsteriskServers() {
  try {
    const response = await fetch(`${API_URL}/asterisk/servers.php`)
    const data = await response.json()

    if (data.success) {
      renderServersTable(data.data)
    }
  } catch (error) {
    console.error("Error loading servers:", error)
  }
}

function renderServersTable(servers) {
  const tbody = document.getElementById("serversTableBody")

  if (servers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">No servers configured</td></tr>'
    return
  }

  tbody.innerHTML = servers
    .map(
      (server) => `
        <tr>
            <td>${server.name}</td>
            <td>${server.host}</td>
            <td>${server.ami_port}</td>
            <td><span class="status-badge status-${server.status}">${server.status}</span></td>
            <td>${server.current_calls}</td>
            <td>${server.max_channels}</td>
            <td>
                <button class="action-btn" onclick="testServer(${server.id})">Test</button>
                <button class="action-btn danger" onclick="removeServer(${server.id})">Remove</button>
            </td>
        </tr>
    `,
    )
    .join("")
}

function openAddServerModal() {
  alert("Add Asterisk server functionality will be implemented")
}

function testServer(serverId) {
  alert("Server test functionality will be implemented")
}

function removeServer(serverId) {
  alert("Remove server functionality will be implemented")
}

// Load dashboard stats with API
async function loadDashboardStats() {
  try {
    const response = await fetch(`${API_URL}/dashboard/stats.php`)
    const result = await response.json()

    if (result.success) {
      const data = result.data

      document.getElementById("totalUsers").textContent = data.total_users
      document.getElementById("todayCalls").textContent = data.today_calls

      const hours = Math.floor(data.total_duration / 3600)
      const minutes = Math.floor((data.total_duration % 3600) / 60)
      document.getElementById("totalDuration").textContent = `${hours}h ${minutes}m`

      document.getElementById("totalCredits").textContent = `$${Number.parseFloat(data.total_credits || 0).toFixed(2)}`
      document.getElementById("activeCalls").textContent = data.active_calls
      document.getElementById("onlineAgents").textContent = data.online_agents

      // Render campaigns
      renderCampaigns(data.active_campaigns)
    }
  } catch (error) {
    console.error("Error loading dashboard stats:", error)
  }
}

function renderCampaigns(campaigns) {
  const container = document.getElementById("campaignsList")

  if (campaigns.length === 0) {
    container.innerHTML = '<p class="empty-state">No active campaigns</p>'
    return
  }

  container.innerHTML = campaigns
    .map(
      (campaign) => `
        <div class="campaign-item">
            <div class="campaign-header">
                <div class="campaign-name">${campaign.name}</div>
                <div class="campaign-status">${campaign.status}</div>
            </div>
            <div class="campaign-stats">
                ${campaign.leads_count} leads • Created ${new Date(campaign.created_at).toLocaleDateString()}
            </div>
        </div>
    `,
    )
    .join("")
}

// Override the original loadDashboardData
window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    loadDashboardStats()
  }, 100)
})
