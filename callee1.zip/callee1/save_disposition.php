<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$lead_id = $data['lead_id'] ?? null;
$disposition = $data['disposition'] ?? '';
$notes = $data['notes'] ?? '';

if (!$lead_id || !$disposition) {
    echo json_encode(['success' => false, 'message' => 'Missing data']);
    exit;
}

$stmt = $conn->prepare("UPDATE leads SET status = ?, notes = CONCAT(IFNULL(notes, ''), '\n', ?) WHERE id = ?");
$stmt->bind_param("ssi", $disposition, $notes, $lead_id);
$stmt->execute();

echo json_encode(['success' => true]);
?>