<?php
// Telnyx API Configuration
define('TELNYX_API_KEY', 'KEY019C2E118125F59BC2291F66DAF512AC_Hh2OO4t1NL8SUUoja8kWaV'); // Telnyx Portal se nayi Key generate karke yahan paste karein
define('TELNYX_PUBLIC_KEY', 'QXnogzJetrMc39/+DrVNFDkyjfFesV2qJTbLowhqxOk='); // Optional: for webhook verification
define('TELNYX_CONNECTION_ID', '2880157907012290296');
define('TELNYX_MESSAGING_PROFILE_ID', '400199ee-7f75-49f0-9abf-b0e011d89ef9'); // Telnyx Portal se Profile ID le kar yahan dalein

// ZAROORI: Yahan apne server ka public IP address ya domain name likhein
define('BASE_WEBHOOK_URL', 'https://webhook.site/56723bd0-99d4-42f0-b1a5-2151ebb752d3');

// Fetch Billing Rates from Database
// Note: This file assumes $conn is already available from the including script (db_connect.php)

$default_call_rate = 0.015;
$default_sms_rate = 0.005;

if (isset($conn)) {
    $rates_query = $conn->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('call_rate_per_minute', 'sms_rate_per_segment')");
    if ($rates_query) {
        while ($row = $rates_query->fetch_assoc()) {
            if ($row['setting_key'] == 'call_rate_per_minute') $default_call_rate = (float)$row['setting_value'];
            if ($row['setting_key'] == 'sms_rate_per_segment') $default_sms_rate = (float)$row['setting_value'];
        }
    }
}

define('CALL_RATE_PER_MINUTE', $default_call_rate);
define('SMS_RATE_PER_SEGMENT', $default_sms_rate);