<?php
class AsteriskAMI {
    private $host;
    private $port;
    private $username;
    private $password;
    private $socket;
    private $timeout = 3;

    public function __construct($host, $port, $username, $password) {
        $this->host = $host;
        $this->port = $port;
        $this->username = $username;
        $this->password = $password;
    }

    public function connect() {
        $this->socket = @fsockopen($this->host, $this->port, $errno, $errstr, $this->timeout);
        if (!$this->socket) {
            throw new Exception("AMI Connection Failed: $errstr ($errno)");
        }

        // Login Action
        $response = $this->sendRequest([
            'Action' => 'Login',
            'Username' => $this->username,
            'Secret' => $this->password
        ]);

        if (stripos($response, 'Authentication accepted') === false && stripos($response, 'Success') === false) {
            $this->disconnect();
            throw new Exception("AMI Login Failed. Check credentials in manager.conf.");
        }
    }

    public function disconnect() {
        if ($this->socket) {
            $this->sendRequest(['Action' => 'Logoff']);
            fclose($this->socket);
            $this->socket = null;
        }
    }

    public function originate($channel, $exten, $context, $priority, $callerId, $variables = []) {
        $params = [
            'Action' => 'Originate',
            'Channel' => $channel,
            'Exten' => $exten,
            'Context' => $context,
            'Priority' => $priority,
            'CallerID' => $callerId,
            'Async' => 'true'
        ];
        return $this->sendRequest($params, $variables);
    }

    private function sendRequest($params, $variables = []) {
        $req = "";
        foreach ($params as $key => $value) $req .= "$key: $value\r\n";
        foreach ($variables as $key => $value) $req .= "Variable: $key=$value\r\n";
        $req .= "\r\n";

        fwrite($this->socket, $req);
        return fread($this->socket, 4096);
    }
}
?>