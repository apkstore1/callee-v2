<?php
session_start();
require_once '../../db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$duration = $input['duration'] ?? 0;
$status = 'completed'; // Force status to completed
$user_id = $_SESSION['user_id'];

// Update the most recent call for this user that is pending/initiated
$stmt = $conn->prepare("UPDATE call_logs SET duration = ?, status = ? WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->bind_param("isi", $duration, $status, $user_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Call log updated']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>