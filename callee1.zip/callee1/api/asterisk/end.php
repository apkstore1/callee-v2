<?php
session_start();
require_once '../../db_connect.php';
require_once '../telnyx_config.php'; // For Default Rates
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$duration = $input['duration'] ?? 0;
$status = 'completed'; // Force status to completed
$user_id = $_SESSION['user_id'];

// 1. Fetch User Info to determine Payer
$stmt = $conn->prepare("SELECT id, role, admin_id FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Determine who pays (Admin or Self)
$payer_id = ($user['role'] == 'agent' && !empty($user['admin_id'])) ? $user['admin_id'] : $user_id;

// 2. Get Call Rate (Custom or Default)
$rate_stmt = $conn->prepare("SELECT custom_call_rate FROM users WHERE id = ?");
$rate_stmt->bind_param("i", $payer_id);
$rate_stmt->execute();
$rate_res = $rate_stmt->get_result()->fetch_assoc();

$call_rate = ($rate_res && $rate_res['custom_call_rate'] !== null && $rate_res['custom_call_rate'] > 0) 
             ? (float)$rate_res['custom_call_rate'] 
             : CALL_RATE_PER_MINUTE;

// Update the most recent call for this user that is pending/initiated
// Yeh duration UI timer se hai, billing ke liye nahi. Billing webhook se hogi.
$stmt = $conn->prepare("UPDATE call_logs SET duration = ? WHERE user_id = ? AND status != 'completed' ORDER BY id DESC LIMIT 1");
$stmt->bind_param("ii", $duration, $user_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Call duration from UI logged. Billing will be handled by webhook.']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>