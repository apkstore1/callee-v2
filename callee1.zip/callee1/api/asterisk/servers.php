<?php
require_once '../config/cors.php';
require_once '../config/database.php';

session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $query = "SELECT * FROM asterisk_servers ORDER BY created_at DESC";
        $stmt = $db->prepare($query);
        $stmt->execute();
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "data" => $stmt->fetchAll()
        ]);
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        
        if(!empty($data->name) && !empty($data->host) && !empty($data->ami_username) && !empty($data->ami_password)) {
            $query = "INSERT INTO asterisk_servers (name, host, ami_port, ami_username, ami_password, 
                      websocket_url, max_channels) 
                      VALUES (:name, :host, :ami_port, :ami_username, :ami_password, :websocket_url, :max_channels)";
            
            $stmt = $db->prepare($query);
            
            $ami_port = isset($data->ami_port) ? $data->ami_port : 5038;
            $websocket_url = isset($data->websocket_url) ? $data->websocket_url : null;
            $max_channels = isset($data->max_channels) ? $data->max_channels : 100;
            
            $stmt->bindParam(":name", $data->name);
            $stmt->bindParam(":host", $data->host);
            $stmt->bindParam(":ami_port", $ami_port);
            $stmt->bindParam(":ami_username", $data->ami_username);
            $stmt->bindParam(":ami_password", $data->ami_password);
            $stmt->bindParam(":websocket_url", $websocket_url);
            $stmt->bindParam(":max_channels", $max_channels);
            
            if($stmt->execute()) {
                http_response_code(201);
                echo json_encode([
                    "success" => true,
                    "message" => "Asterisk server added successfully"
                ]);
            } else {
                http_response_code(500);
                echo json_encode(["success" => false, "message" => "Failed to add server"]);
            }
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Missing required fields"]);
        }
        break;
}
?>
