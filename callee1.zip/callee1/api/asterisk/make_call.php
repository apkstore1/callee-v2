<?php
session_start();
header('Content-Type: application/json');

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// 2. Get Input Data
$input = json_decode(file_get_contents('php://input'), true);
$target_number = $input['phone_number'] ?? '';

if (empty($target_number)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Phone number is required']);
    exit;
}

// 3. Agent Extension (Assuming username is '100')
$agent_extension = $_SESSION['user_username']; 

// 4. AMI Credentials (MUST MATCH /etc/asterisk/manager.conf)
$ami_host = "127.0.0.1"; // Localhost use karein (Public IP timeout dega)
$ami_port = 5038;
$ami_user = "portaluser";      // Step 1 wala user
$ami_pass = "1997Mushariq";      // Step 1 wala password

// 5. Connect to AMI
$timeout = 5;
$socket = @fsockopen($ami_host, $ami_port, $errno, $errstr, $timeout);

if (!$socket) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => "AMI Connection Failed: $errstr ($errno). Check manager.conf"]);
    exit;
}

// 6. Login & Originate Call
fputs($socket, "Action: Login\r\n");
fputs($socket, "Username: $ami_user\r\n");
fputs($socket, "Secret: $ami_pass\r\n\r\n");

// Thoda wait karein taake Login process ho jaye (Buffer safety)
usleep(200000); // 0.2 seconds delay

// Agent ko pehle call jayegi (PJSIP/100), jab woh uthayega to Target dial hoga
fputs($socket, "Action: Originate\r\n");
fputs($socket, "Channel: PJSIP/$agent_extension\r\n");
fputs($socket, "Context: from-portal\r\n"); // Outbound context
fputs($socket, "Exten: " . trim($target_number) . "\r\n");
fputs($socket, "Priority: 1\r\n");
fputs($socket, "CallerID: <" . trim($agent_extension) . ">\r\n");
fputs($socket, "Async: true\r\n\r\n");

fputs($socket, "Action: Logoff\r\n\r\n");
fclose($socket);

echo json_encode(['success' => true, 'message' => 'Call initiated successfully']);
?>
