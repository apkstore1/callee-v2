<?php
session_start();
header('Content-Type: application/json');

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../../db_connect.php';

// 2. Get Input Data
$input = json_decode(file_get_contents('php://input'), true);
$target_number = $input['phone_number'] ?? '';

if (empty($target_number)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Phone number is required']);
    exit;
}

// 3. Agent Extension & Caller ID Fetch
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT u.sip_extension, u.role, u.admin_id FROM users u WHERE u.id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (empty($user['sip_extension'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Agent SIP extension not configured.']);
    exit;
}
$agent_extension = $user['sip_extension'];

// Fetch Assigned Caller ID (PSTN Number)
// Agar agent hai to admin ka number uthao, agar admin hai to apna number uthao
$lookup_id = ($user['role'] == 'agent' && !empty($user['admin_id'])) ? $user['admin_id'] : $user_id;

$stmt_num = $conn->prepare("SELECT pn.number FROM admin_numbers an JOIN phone_numbers pn ON an.number_id = pn.id WHERE an.admin_id = ? AND an.status = 'active' LIMIT 1");
$stmt_num->bind_param("i", $lookup_id);
$stmt_num->execute();
$res_num = $stmt_num->get_result();
$num_row = $res_num->fetch_assoc();
$assigned_caller_id = $num_row ? $num_row['number'] : ''; // Default empty if no number assigned

// Webhook ko link karne ke liye ek unique call ID banayein
$unique_call_id = uniqid('call_');
$client_state_data = json_encode(['user_id' => $user_id, 'call_id' => $unique_call_id]);
$client_state_base64 = base64_encode($client_state_data);

// Originate se pehle call log karein
try {
    $log_stmt = $conn->prepare("INSERT INTO call_logs (user_id, call_id, phone_number, from_number, status) VALUES (?, ?, ?, ?, 'initiated')");
    if (!$log_stmt) {
        throw new Exception("Database Prepare Error: " . $conn->error);
    }
    $log_stmt->bind_param("isss", $user_id, $unique_call_id, $target_number, $assigned_caller_id);
    if (!$log_stmt->execute()) {
        throw new Exception("Database Execute Error: " . $log_stmt->error);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Call Log Error: ' . $e->getMessage()]);
    exit;
}

// 4. AMI Credentials (MUST MATCH /etc/asterisk/manager.conf)
$ami_host = "127.0.0.1"; // Localhost use karein (Public IP timeout dega)
$ami_port = 5038;
$ami_user = "portaluser";      // Step 1 wala user
$ami_pass = "1997Mushariq";      // Step 1 wala password

// 5. Connect to AMI
$timeout = 5;
$socket = @fsockopen($ami_host, $ami_port, $errno, $errstr, $timeout);

if ($socket) {
    // 1. Login and wait for response
    fwrite($socket, "Action: Login\r\nUsername: $ami_user\r\nSecret: $ami_pass\r\n\r\n");
    
    $login_response = "";
    while (!feof($socket)) {
        $line = fgets($socket);
        $login_response .= $line;
        if (trim($line) == "") break; 
    }

    if (strpos($login_response, 'Success') !== false) {
        // Nayi call lagane se pehle purani saaf karo (Force Hangup)
        $hangup_cmd = "Action: Hangup\r\n";
        $hangup_cmd .= "Channel: PJSIP/" . trim($agent_extension) . "\r\n\r\n"; // Is se extension ki har call cut jayegi
        fwrite($socket, $hangup_cmd);
        usleep(100000); // 0.1 sec wait for cleanup

        // 2. Send Originate
        $out = "Action: Originate\r\n";
        $out .= "Channel: PJSIP/" . trim($agent_extension) . "\r\n";
        $out .= "Context: from-portal\r\n";
        $out .= "Exten: " . trim($target_number) . "\r\n";
        $out .= "Priority: 1\r\n";
        // Yeh line tumhare assigned Telnyx number ko Asterisk tak le jayegi
        // Yeh client_state Telnyx webhook mein wapis ayega
        $out .= "Variable: TELNYX_CLIENT_STATE=" . $client_state_base64 . "\r\n";
        $out .= "Variable: REAL_CALLERID=" . trim($assigned_caller_id) . "\r\n"; 
        // ... baki variables ke niche ye add karo
        $out .= "Variable: PJSIP_HEADER(add,Call-Info)=<sip:localhost>\;answer-after=0\r\n";
        $out .= "Variable: DIRECTION=ORIGINATE\r\n";
        $out .= "CallerID: <" . trim($target_number) . ">\r\n";
        $out .= "Async: yes\r\n\r\n";

        fwrite($socket, $out);

        // 3. IMPORTANT: Wait and Read the Queue response
        $originate_response = "";
        while (!feof($socket)) {
            $line = fgets($socket);
            $originate_response .= $line;
            if (strpos($line, "Message: Originate successfully queued") !== false || strpos($line, "Error") !== false) {
                break;
            }
        }

        // 4. Ab Logoff bhejo
        fwrite($socket, "Action: Logoff\r\n\r\n");
        fclose($socket);
        echo json_encode(['success' => true, 'message' => 'Call initiated', 'debug' => $originate_response]);
    } else {
        fclose($socket);
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'AMI Login Failed', 'debug' => $login_response]);
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => "AMI Connection Failed: $errstr ($errno). Check manager.conf"]);
}
?>
