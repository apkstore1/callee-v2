<?php
// require_once '../config/cors.php'; // Optional depending on setup
require_once '../../db_connect.php'; // Using main db_connect
require_once 'ami_connect.php';

session_start();

if(!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

$db = $conn; // Using global $conn from db_connect.php

$data = json_decode(file_get_contents("php://input"));

if(empty($data->phone_number)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Phone number required"]);
    exit();
}

try {
    // Get user SIP extension
    $user_query = "SELECT sip_extension FROM users WHERE id = ?";
    $user_stmt = $db->prepare($user_query);
    $user_stmt->bind_param("i", $_SESSION['user_id']);
    $user_stmt->execute();
    $user = $user_stmt->get_result()->fetch_assoc();
    
    if(!$user || !$user['sip_extension']) {
        // Fallback for testing if no extension set
        $user['sip_extension'] = 'PJSIP/101'; 
        // throw new Exception("User SIP extension not configured");
    }
    
    // AMI Credentials (As requested)
    $ami_host = "13.60.248.243"; // AWS Public IP
    $ami_port = 5038;
    $ami_user = "portaluser";
    $ami_pass = "1997Mushariq";
    
    // Connect to AMI
    $ami = new AsteriskAMI(
        $ami_host,
        $ami_port,
        $ami_user,
        $ami_pass
    );
    
    $ami->connect();
    
    // Originate call
    // Assuming PJSIP is used as per instruction
    $channel = "PJSIP/" . $user['sip_extension']; // e.g., PJSIP/1001
    $exten = $data->phone_number;
    $context = "from-portal"; // Context created in extensions.conf
    
    $variables = [
        "CALLERID(num)" => $user['sip_extension'],
        "USER_ID" => $_SESSION['user_id']
    ];
    
    $response = $ami->originate($channel, $exten, $context, 1, null, $variables);
    
    $ami->disconnect();
    
    // Log call initiation
    $log_query = "INSERT INTO call_logs (user_id, lead_id, phone_number, call_direction, call_start, call_status) VALUES (?, ?, ?, 'outbound', NOW(), 'pending')";
    $log_stmt = $db->prepare($log_query);
    
    $lead_id = isset($data->lead_id) ? $data->lead_id : null;
    
    $log_stmt->bind_param("iis", $_SESSION['user_id'], $lead_id, $data->phone_number);
    $log_stmt->execute();
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Call initiated",
        "call_id" => $db->insert_id,
        "ami_response" => $response
    ]);
    
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>
