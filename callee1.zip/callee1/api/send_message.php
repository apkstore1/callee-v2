<?php
session_start();
require_once '../db_connect.php';
require_once 'telnyx_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$to_number = $data['to'] ?? '';
$message_body = $data['text'] ?? '';

if (empty($to_number) || empty($message_body)) {
    echo json_encode(['success' => false, 'message' => 'Recipient and message body required']);
    exit;
}

// 1. Check Credits
$stmt = $conn->prepare("SELECT credits, admin_id FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$available_credits = $user['credits'];

// If user is an agent, check admin's credits
if (!empty($user['admin_id'])) {
    $admin_stmt = $conn->prepare("SELECT credits FROM users WHERE id = ?");
    $admin_stmt->bind_param("i", $user['admin_id']);
    $admin_stmt->execute();
    $admin_res = $admin_stmt->get_result()->fetch_assoc();
    if ($admin_res) {
        $available_credits = $admin_res['credits'];
    }
}

$estimated_cost = SMS_RATE_PER_SEGMENT; // Simple calculation, can be improved for long texts

if ($available_credits < $estimated_cost) {
    echo json_encode(['success' => false, 'message' => 'Insufficient credits.']);
    exit;
}

// 2. Get Sender Number
$admin_id = $user['admin_id'] ? $user['admin_id'] : $user_id;
$num_sql = "SELECT pn.number FROM admin_numbers an JOIN phone_numbers pn ON an.number_id = pn.id WHERE an.admin_id = ? AND an.status = 'active' LIMIT 1";
$num_stmt = $conn->prepare($num_sql);
$num_stmt->bind_param("i", $admin_id);
$num_stmt->execute();
$num_res = $num_stmt->get_result();

if ($num_res->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'No active number found to send message.']);
    exit;
}
$from_number = $num_res->fetch_assoc()['number'];

// 3. Send via Telnyx
$telnyx_url = "https://api.telnyx.com/v2/messages";
$payload = [
    'from' => $from_number,
    'to' => $to_number,
    'text' => $message_body
];

$ch = curl_init($telnyx_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . TELNYX_API_KEY
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code === 200) {
    // 4. Deduct Credit & Log
    $charge_id = !empty($user['admin_id']) ? $user['admin_id'] : $user_id;
    $conn->query("UPDATE users SET credits = credits - $estimated_cost WHERE id = $charge_id");
    $conn->query("INSERT INTO message_logs (user_id, to_number, from_number, direction, body, cost, status) VALUES ($user_id, '$to_number', '$from_number', 'outbound', '$message_body', $estimated_cost, 'sent')");
    
    echo json_encode(['success' => true, 'message' => 'Message sent']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to send message via provider.']);
}
?>