<?php
session_start();
require_once '../db_connect.php';
require_once 'telnyx_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Generate a deterministic SIP username based on User ID and App ID
// This ensures we always find the same user on Telnyx without storing it in DB
$app_suffix = substr(md5(TELNYX_CONNECTION_ID), 0, 8);
$sip_username = "agent_{$user_id}_{$app_suffix}";

// 1. Check if this SIP User exists on Telnyx
$ch = curl_init();
$filter_url = "https://api.telnyx.com/v2/telephony_credentials?filter[sip_username]=" . urlencode($sip_username);

curl_setopt($ch, CURLOPT_URL, $filter_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Fix for local dev environments
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . TELNYX_API_KEY
]);

$response = curl_exec($ch);
$cred_data = json_decode($response, true);
curl_close($ch);

$credential_id = null;

if (!empty($cred_data['data'])) {
    // User exists
    $credential_id = $cred_data['data'][0]['id'];
} else {
    // 2. User does not exist, Create it
    // We generate a random password because we will never use it (we use Tokens)
    $random_password = base64_encode(random_bytes(16));

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.telnyx.com/v2/telephony_credentials");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . TELNYX_API_KEY
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'connection_id' => TELNYX_CONNECTION_ID,
        'sip_username' => $sip_username,
        'sip_password' => $random_password
    ]));

    $create_res = curl_exec($ch);
    $create_data = json_decode($create_res, true);
    curl_close($ch);

    if (isset($create_data['data']['id'])) {
        $credential_id = $create_data['data']['id'];
    } else {
        error_log("Telnyx Auto-Create Failed: " . $create_res);
        echo json_encode(['success' => false, 'message' => 'Failed to create Telnyx user.']);
        exit;
    }
}

// 3. Generate JWT Token
$ch = curl_init();
$token_url = "https://api.telnyx.com/v2/telephony_credentials/{$credential_id}/token";

curl_setopt($ch, CURLOPT_URL, $token_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{}'); // Empty body required
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . TELNYX_API_KEY
]);

$token_response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$token_data = json_decode($token_response, true);

if ($http_code === 201 || $http_code === 200) {
    // Token generated successfully
    echo json_encode([
        'success' => true, 
        'token' => $token_data['data'], // This is the JWT
        'sip_username' => $sip_username
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to generate token.']);
}
?>