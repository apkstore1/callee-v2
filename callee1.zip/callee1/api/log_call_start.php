<?php
session_start();
require_once '../db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);

$phone_number = $data['phone_number'] ?? '';
$call_control_id = $data['telnyx_call_id'] ?? '';
$lead_id = $data['lead_id'] ?? null;

if (empty($phone_number) || empty($call_control_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing data']);
    exit;
}

// Log the call start so billing can find it later
$stmt = $conn->prepare("INSERT INTO call_logs (user_id, lead_id, phone_number, direction, status, telnyx_call_control_id) VALUES (?, ?, ?, 'outbound', 'initiated', ?)");
$stmt->bind_param("iisss", $user_id, $lead_id, $phone_number, $call_control_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>