<?php
require_once '../../db_connect.php';
require_once '../telnyx_config.php';

// Receive Webhook Data
$payload = file_get_contents('php://input');
$data = json_decode($payload, true);

if (!isset($data['data']['event_type'])) {
    http_response_code(400);
    exit;
}

$event_type = $data['data']['event_type'];
$call_control_id = $data['data']['payload']['call_control_id'];

// Handle Call Hangup (Billing)
if ($event_type === 'call.hangup') {
    $end_time = $data['data']['payload']['end_time'];
    $start_time = $data['data']['payload']['start_time'];
    
    // Calculate Duration in Minutes (Ceiling)
    $start = strtotime($start_time);
    $end = strtotime($end_time);
    $duration_seconds = $end - $start;
    $duration_minutes = ceil($duration_seconds / 60);
    
    // Calculate Cost
    $cost = $duration_minutes * CALL_RATE_PER_MINUTE;
    
    // Find User associated with this call
    $stmt = $conn->prepare("SELECT user_id FROM call_logs WHERE telnyx_call_control_id = ?");
    $stmt->bind_param("s", $call_control_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['user_id'];
        
        // Determine who to charge (User or their Admin)
        $u_stmt = $conn->prepare("SELECT admin_id FROM users WHERE id = ?");
        $u_stmt->bind_param("i", $user_id);
        $u_stmt->execute();
        $u_res = $u_stmt->get_result()->fetch_assoc();
        
        $charge_user_id = $user_id;
        if ($u_res && !empty($u_res['admin_id'])) {
            $charge_user_id = $u_res['admin_id'];
        }

        // Deduct Credits
        $upd_user = $conn->prepare("UPDATE users SET credits = credits - ? WHERE id = ?");
        $upd_user->bind_param("di", $cost, $charge_user_id);
        $upd_user->execute();
        
        // Update Call Log
        $upd_log = $conn->prepare("UPDATE call_logs SET status = 'completed', duration = ?, cost = ?, end_time = NOW() WHERE telnyx_call_control_id = ?");
        $upd_log->bind_param("idss", $duration_seconds, $cost, $call_control_id);
        $upd_log->execute();
    }
}

http_response_code(200);
?>