<?php
require_once '../../db_connect.php';
require_once '../telnyx_config.php';
header('Content-Type: application/json');

// Receive Webhook Data
$payload = file_get_contents('php://input');
$data = json_decode($payload, true);

if (!isset($data['data']['event_type']) || !isset($data['data']['payload']['call_control_id'])) {
    http_response_code(400);
    exit;
}

$event_type = $data['data']['event_type'];
$webhook_payload = $data['data']['payload'];
$call_control_id = $webhook_payload['call_control_id'];

// Event: Call Initiated - Link Telnyx ID with our call log
if ($event_type === 'call.initiated' && isset($webhook_payload['client_state'])) {
    $client_state_base64 = $webhook_payload['client_state'];
    $client_state_data = json_decode(base64_decode($client_state_base64), true);

    if ($client_state_data && isset($client_state_data['call_id'])) {
        $call_id = $client_state_data['call_id'];
        
        // call_logs mein telnyx_call_control_id update karein
        $stmt = $conn->prepare("UPDATE call_logs SET telnyx_call_control_id = ? WHERE call_id = ?");
        $stmt->bind_param("ss", $call_control_id, $call_id);
        $stmt->execute();
    }
}

// Event: Call Hangup - The Real Billing Logic
if ($event_type === 'call.hangup') { // MODIFIED: Removed direction check to handle both
    $end_time = $webhook_payload['end_time'];
    $start_time = $webhook_payload['start_time'];
    
    // Calculate Duration in Seconds
    $start = strtotime($start_time);
    $end = strtotime($end_time);
    $duration_seconds = $end - $start;

    // Agar call answer hi nahi hui to duration 0 hogi, koi charge nahi
    if ($duration_seconds <= 0) {
        $upd_log = $conn->prepare("UPDATE call_logs SET status = 'not_answered' WHERE telnyx_call_control_id = ?");
        $upd_log->bind_param("s", $call_control_id);
        $upd_log->execute();
        http_response_code(200);
        exit;
    }

    $duration_minutes = ceil($duration_seconds / 60);
    $payer_id = null;

    // --- Determine Payer ID based on call direction ---
    if ($webhook_payload['direction'] === 'outbound') {
        // For outbound, find the user who initiated the call from our logs
        $stmt = $conn->prepare("SELECT user_id FROM call_logs WHERE telnyx_call_control_id = ?");
        $stmt->bind_param("s", $call_control_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user_id = $result->fetch_assoc()['user_id'];
            
            // Find who pays for this user (their admin or themselves)
            $u_stmt = $conn->prepare("SELECT role, admin_id FROM users WHERE id = ?");
            $u_stmt->bind_param("i", $user_id);
            $u_stmt->execute();
            $u_res = $u_stmt->get_result()->fetch_assoc();
            
            $payer_id = ($u_res && $u_res['role'] == 'agent' && !empty($u_res['admin_id'])) ? $u_res['admin_id'] : $user_id;
        }
    } elseif ($webhook_payload['direction'] === 'inbound') {
        // For inbound, find the admin who owns the 'to' number
        $inbound_number = $webhook_payload['to'];
        
        $num_stmt = $conn->prepare(
            "SELECT an.admin_id FROM phone_numbers pn JOIN admin_numbers an ON pn.id = an.number_id WHERE pn.number = ?"
        );
        $num_stmt->bind_param("s", $inbound_number);
        $num_stmt->execute();
        $num_res = $num_stmt->get_result();
        if ($num_res->num_rows > 0) {
            $payer_id = $num_res->fetch_assoc()['admin_id'];
        }
    }

    // --- If a payer was found, proceed with billing ---
    if ($payer_id) {
        // Get Call Rate (Custom or Default)
        $rate_stmt = $conn->prepare("SELECT custom_call_rate FROM users WHERE id = ?");
        $rate_stmt->bind_param("i", $payer_id);
        $rate_stmt->execute();
        $rate_res = $rate_stmt->get_result()->fetch_assoc();

        $call_rate = ($rate_res && $rate_res['custom_call_rate'] !== null && $rate_res['custom_call_rate'] > 0) 
                     ? (float)$rate_res['custom_call_rate'] 
                     : CALL_RATE_PER_MINUTE;

        // Calculate Cost
        $cost = $duration_minutes * $call_rate;

        // Deduct Credits
        $upd_user = $conn->prepare("UPDATE users SET credits = credits - ? WHERE id = ?");
        $upd_user->bind_param("di", $cost, $payer_id);
        $upd_user->execute();
        
        // Update or Create Call Log with final values
        if ($webhook_payload['direction'] === 'outbound') {
            $upd_log = $conn->prepare("UPDATE call_logs SET status = 'completed', duration = ?, cost = ?, start_time = ?, end_time = ? WHERE telnyx_call_control_id = ?");
            $upd_log->bind_param("idsss", $duration_seconds, $cost, $start_time, $end_time, $call_control_id);
            $upd_log->execute();
        } else { // Inbound
            $from_number = $webhook_payload['from'];
            $to_number = $webhook_payload['to'];
            $log_stmt = $conn->prepare("INSERT INTO call_logs (user_id, telnyx_call_control_id, from_number, phone_number, status, duration, cost, start_time, end_time) VALUES (?, ?, ?, ?, 'completed', ?, ?, ?, ?)");
            $log_stmt->bind_param("isssisss", $payer_id, $call_control_id, $from_number, $to_number, $duration_seconds, $cost, $start_time, $end_time);
            $log_stmt->execute();
        }
    }
}

http_response_code(200);
?>