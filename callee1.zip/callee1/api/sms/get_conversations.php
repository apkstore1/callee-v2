<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false]);
    exit;
}

require_once '../../db_connect.php';
$user_id = $_SESSION['user_id'];

// Fetch unique conversations (grouped by the other party's number)
// We look at both inbound and outbound messages involving this user (or their assigned number context)
// For simplicity, we fetch messages logged by this user_id

$sql = "
    SELECT 
        CASE 
            WHEN direction = 'outbound' THEN to_number 
            ELSE from_number 
        END as contact_number,
        MAX(created_at) as last_msg_time,
        (SELECT body FROM message_logs m2 WHERE m2.id = MAX(m1.id)) as last_message,
        (SELECT direction FROM message_logs m3 WHERE m3.id = MAX(m1.id)) as last_direction
    FROM message_logs m1
    WHERE user_id = ?
    GROUP BY contact_number
    ORDER BY last_msg_time DESC
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    // Table likely doesn't exist yet, return empty list
    echo json_encode(['success' => true, 'data' => []]);
    exit;
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$conversations = [];
while ($row = $result->fetch_assoc()) {
    $conversations[] = $row;
}

echo json_encode(['success' => true, 'data' => $conversations]);
?>