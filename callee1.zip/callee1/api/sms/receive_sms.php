<?php
// api/sms/receive_sms.php
require_once '../../db_connect.php';
require_once '../telnyx_config.php';

// Receive Webhook Data
$payload = file_get_contents('php://input');
$data = json_decode($payload, true);

// Validate Event Type
if (!isset($data['data']['event_type']) || $data['data']['event_type'] !== 'message.received') {
    http_response_code(200); // Return 200 to acknowledge other events (like delivery reports)
    exit;
}

$message_data = $data['data']['payload'];
$from_number = $message_data['from']['phone_number'];
// Telnyx 'to' field is an array
$to_number = $message_data['to'][0]['phone_number'] ?? ''; 
$body = $message_data['text'];
$cost = 0; // Incoming messages are usually free or billed differently
$direction = 'inbound';
$status = 'received';

// Find which user (Admin) owns this 'to_number'
$stmt = $conn->prepare("SELECT an.admin_id FROM admin_numbers an JOIN phone_numbers pn ON an.number_id = pn.id WHERE pn.number = ? AND an.status = 'active' LIMIT 1");
$stmt->bind_param("s", $to_number);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user_id = $row['admin_id'];

    // Ensure table exists
    $conn->query("CREATE TABLE IF NOT EXISTS message_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        direction ENUM('inbound', 'outbound'),
        from_number VARCHAR(20),
        to_number VARCHAR(20),
        body TEXT,
        cost DECIMAL(10,4) DEFAULT 0,
        status VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Insert into message_logs
    $insert = $conn->prepare("INSERT INTO message_logs (user_id, direction, from_number, to_number, body, cost, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $insert->bind_param("issssds", $user_id, $direction, $from_number, $to_number, $body, $cost, $status);
    $insert->execute();
}

http_response_code(200);
?>