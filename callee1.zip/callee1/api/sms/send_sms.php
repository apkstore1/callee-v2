<?php
session_start();
header('Content-Type: application/json');

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once '../../db_connect.php';
require_once '../telnyx_config.php'; // Rates and API Keys

$user_id = $_SESSION['user_id'];
$input = json_decode(file_get_contents('php://input'), true);
$to_number = $input['to_number'] ?? '';
$message_body = $input['message'] ?? '';

if (empty($to_number) || empty($message_body)) {
    echo json_encode(['success' => false, 'message' => 'Recipient and message body required']);
    exit;
}

// 2. Fetch Sender Info & Admin ID for Billing
$stmt = $conn->prepare("
    SELECT u.id, u.role, u.admin_id, u.allow_message,
           a.allow_message as admin_allow_message
    FROM users u 
    LEFT JOIN users a ON u.admin_id = a.id 
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$can_message = ($user['allow_message'] && ($user['admin_allow_message'] ?? 1));

if (!$can_message) {
    echo json_encode(['success' => false, 'message' => 'Messaging permission denied']);
    exit;
}

// Determine who pays (Admin or Self)
$payer_id = ($user['role'] == 'agent' && !empty($user['admin_id'])) ? $user['admin_id'] : $user_id;

// --- CUSTOM RATE LOGIC START ---
// Check if the payer (Admin) has a custom SMS rate set
$rate_stmt = $conn->prepare("SELECT custom_sms_rate FROM users WHERE id = ?");
$rate_stmt->bind_param("i", $payer_id);
$rate_stmt->execute();
$rate_res = $rate_stmt->get_result()->fetch_assoc();
$current_sms_rate = ($rate_res && $rate_res['custom_sms_rate'] !== null && $rate_res['custom_sms_rate'] > 0) ? (float)$rate_res['custom_sms_rate'] : SMS_RATE_PER_SEGMENT;
// --- CUSTOM RATE LOGIC END ---

// Fetch Assigned Caller ID (From Number)
$num_stmt = $conn->prepare("SELECT pn.number FROM admin_numbers an JOIN phone_numbers pn ON an.number_id = pn.id WHERE an.admin_id = ? AND an.status = 'active' LIMIT 1");
$num_stmt->bind_param("i", $payer_id);
$num_stmt->execute();
$num_res = $num_stmt->get_result();

if ($num_res->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'No active phone number assigned']);
    exit;
}
$from_number = $num_res->fetch_assoc()['number'];

// Sanitize numbers (Remove spaces, dashes, etc.)
$to_number = preg_replace('/[^0-9+]/', '', $to_number);
$from_number = preg_replace('/[^0-9+]/', '', $from_number);

// Ensure E.164 Format (Add + if missing)
if (strpos($to_number, '+') !== 0) $to_number = '+' . $to_number;
if (strpos($from_number, '+') !== 0) $from_number = '+' . $from_number;

// 3. Calculate Cost
$char_count = mb_strlen($message_body);
$segments = ceil($char_count / 160);
$cost = $segments * $current_sms_rate;

// 4. Check Credits
$credit_stmt = $conn->prepare("SELECT credits FROM users WHERE id = ?");
$credit_stmt->bind_param("i", $payer_id);
$credit_stmt->execute();
$credits = $credit_stmt->get_result()->fetch_assoc()['credits'];

if ($credits < $cost) {
    echo json_encode(['success' => false, 'message' => 'Insufficient credits']);
    exit;
}

// 5. Send via Telnyx API
$telnyx_url = "https://api.telnyx.com/v2/messages";
$data = [
    "from" => $from_number,
    "to" => $to_number,
    "text" => $message_body
];

// Add Messaging Profile ID if configured
if (defined('TELNYX_MESSAGING_PROFILE_ID') && TELNYX_MESSAGING_PROFILE_ID !== 'YOUR_MESSAGING_PROFILE_ID_HERE') {
    $data['messaging_profile_id'] = TELNYX_MESSAGING_PROFILE_ID;
}

$ch = curl_init($telnyx_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer " . TELNYX_API_KEY
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = json_decode($response, true);

if ($http_code >= 200 && $http_code < 300) {
    // 6. Deduct Credits
    $deduct_stmt = $conn->prepare("UPDATE users SET credits = credits - ? WHERE id = ?");
    $deduct_stmt->bind_param("di", $cost, $payer_id);
    $deduct_stmt->execute();

    // 7. Save to Database
    // Assuming table 'messages' exists: id, user_id, direction, from_number, to_number, body, cost, status, created_at
    $status = 'sent';
    $direction = 'outbound';
    
    // Create table if not exists (Safety check, ideally run once in DB)
    $conn->query("CREATE TABLE IF NOT EXISTS message_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        direction ENUM('inbound', 'outbound'),
        from_number VARCHAR(20),
        to_number VARCHAR(20),
        body TEXT,
        cost DECIMAL(10,4) DEFAULT 0,
        status VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $log_stmt = $conn->prepare("INSERT INTO message_logs (user_id, direction, from_number, to_number, body, cost, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if ($log_stmt) {
        $log_stmt->bind_param("issssds", $user_id, $direction, $from_number, $to_number, $message_body, $cost, $status);
        $log_stmt->execute();
    } else {
        // Log error if table structure is wrong
        error_log("Prepare failed in send_sms: " . $conn->error);
    }

    echo json_encode([
        'success' => true, 
        'message' => 'Message sent', 
        'cost' => $cost, 
        'segments' => $segments,
        'remaining_credits' => $credits - $cost
    ]);
} else {
    $error_msg = $result['errors'][0]['detail'] ?? 'Unknown Telnyx Error';
    echo json_encode([
        'success' => false, 
        'message' => 'Telnyx Error: ' . $error_msg,
        'debug_from' => $from_number,
        'debug_profile' => defined('TELNYX_MESSAGING_PROFILE_ID') ? TELNYX_MESSAGING_PROFILE_ID : 'None'
    ]);
}
?>