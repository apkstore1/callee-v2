<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit;
}

require_once '../../db_connect.php';
$user_id = $_SESSION['user_id'];
$contact_number = $_GET['number'] ?? '';

if (empty($contact_number)) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

$sql = "SELECT * FROM message_logs 
        WHERE user_id = ? 
        AND (from_number = ? OR to_number = ?) 
        ORDER BY created_at ASC";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    // Table likely doesn't exist yet, return empty list
    echo json_encode(['success' => true, 'data' => []]);
    exit;
}

$stmt->bind_param("iss", $user_id, $contact_number, $contact_number);
$stmt->execute();
$result = $stmt->get_result();

$messages = $result->fetch_all(MYSQLI_ASSOC);
echo json_encode(['success' => true, 'data' => $messages]);
?>