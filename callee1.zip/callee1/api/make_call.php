<?php
session_start();
require_once '../db_connect.php';
require_once 'telnyx_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$to_number = $data['phone_number'] ?? '';
$lead_id = $data['lead_id'] ?? null;

if (empty($to_number)) {
    echo json_encode(['success' => false, 'message' => 'Phone number required']);
    exit;
}

// 1. Check User Credits
$stmt = $conn->prepare("SELECT credits, admin_id FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$available_credits = $user['credits'];

// If user is an agent (has admin_id), check admin's credits instead
if (!empty($user['admin_id'])) {
    $admin_stmt = $conn->prepare("SELECT credits FROM users WHERE id = ?");
    $admin_stmt->bind_param("i", $user['admin_id']);
    $admin_stmt->execute();
    $admin_res = $admin_stmt->get_result()->fetch_assoc();
    if ($admin_res) {
        $available_credits = $admin_res['credits'];
    }
}

if ($available_credits < 0.05) { // Minimum balance check
    echo json_encode(['success' => false, 'message' => 'Insufficient credits to make a call.']);
    exit;
}

// 2. Get Caller ID (From assigned numbers)
// Logic: Get the first active number assigned to this agent's admin
$admin_id = $user['admin_id'] ? $user['admin_id'] : $user_id;
$num_sql = "SELECT pn.number FROM admin_numbers an JOIN phone_numbers pn ON an.number_id = pn.id WHERE an.admin_id = ? AND an.status = 'active' LIMIT 1";
$num_stmt = $conn->prepare($num_sql);
$num_stmt->bind_param("i", $admin_id);
$num_stmt->execute();
$num_res = $num_stmt->get_result();

if ($num_res->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'No active caller ID found. Please purchase a number first.']);
    exit;
}
$from_number = $num_res->fetch_assoc()['number'];

// Ensure E.164 format (Add + if missing)
if (strpos($to_number, '+') !== 0) $to_number = '+' . $to_number;
if (strpos($from_number, '+') !== 0) $from_number = '+' . $from_number;

// 3. Initiate Call via Telnyx API
$telnyx_url = "https://api.telnyx.com/v2/calls";
$payload = [
    'connection_id' => TELNYX_CONNECTION_ID, // Uses ID from config file
    'to' => $to_number,
    'from' => $from_number,
    'webhook_url' => BASE_WEBHOOK_URL . '/callee1/api/telnyx_voice.php', // Important for billing
    'webhook_url_method' => 'POST'
];

$ch = curl_init($telnyx_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . TELNYX_API_KEY
]);

$response = curl_exec($ch);

if ($response === false) {
    $curl_err = curl_error($ch);
    curl_close($ch);
    echo json_encode(['success' => false, 'message' => 'Connection Error: ' . $curl_err]);
    exit;
}

$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = json_decode($response, true);

if ($http_code === 201 || $http_code === 200) {
    $call_control_id = $result['data']['call_control_id'];
    
    // 4. Log Initial Call
    $log_stmt = $conn->prepare("INSERT INTO call_logs (user_id, lead_id, phone_number, direction, status, telnyx_call_control_id) VALUES (?, ?, ?, 'outbound', 'initiated', ?)");
    $log_stmt->bind_param("iisss", $user_id, $lead_id, $to_number, $call_control_id);
    $log_stmt->execute();

    echo json_encode(['success' => true, 'message' => 'Call initiated', 'call_id' => $call_control_id]);
} else {
    // Log error for debugging
    error_log("Telnyx Error: " . $response);
    
    // Extract detailed error from Telnyx response
    $error_msg = 'Failed to connect call via provider.';
    if (isset($result['errors']) && is_array($result['errors'])) {
        $details = [];
        foreach ($result['errors'] as $err) {
            $details[] = $err['detail'] ?? $err['title'] ?? 'Unknown error';
        }
        $error_msg .= ' Details: ' . implode(', ', $details);
    }
    
    echo json_encode(['success' => false, 'message' => $error_msg]);
}
?>