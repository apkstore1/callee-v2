<?php
require_once '../../db_connect.php';
require_once '../telnyx_config.php'; // For Default Rates
header('Content-Type: application/json');

// Receive Webhook Data
$payload = file_get_contents('php://input');
$data = json_decode($payload, true);

if (!isset($data['data']['event_type']) || !isset($data['data']['payload'])) {
    http_response_code(400);
    exit;
}

$event_type = $data['data']['event_type'];
$webhook_payload = $data['data']['payload'];

// Handle Inbound Message
if ($event_type === 'message.received') {
    // Telnyx sends 'to' as an array, we take the first one
    $to_number = isset($webhook_payload['to'][0]['phone_number']) ? $webhook_payload['to'][0]['phone_number'] : $webhook_payload['to'];
    $from_number = $webhook_payload['from']['phone_number'];
    $body = $webhook_payload['text'];
    $parts = isset($webhook_payload['parts']) ? $webhook_payload['parts'] : 1; // Number of segments
    
    // 1. Find who owns this number (The Admin)
    // Check admin_numbers table to find the owner
    $stmt = $conn->prepare("
        SELECT an.admin_id 
        FROM phone_numbers pn 
        JOIN admin_numbers an ON pn.id = an.number_id 
        WHERE pn.number = ? AND an.status = 'active'
    ");
    $stmt->bind_param("s", $to_number);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $payer_id = $result->fetch_assoc()['admin_id'];
        
        // 2. Get Cost from Telnyx Webhook and add a surcharge
        $cost = 0;
        if (isset($webhook_payload['cost']) && isset($webhook_payload['cost']['amount'])) {
            $cost = (float)$webhook_payload['cost']['amount'];
        }
        $cost += 0.002; // Add a 0.002 surcharge
        
        // 4. Deduct Credits
        $upd_user = $conn->prepare("UPDATE users SET credits = credits - ? WHERE id = ?");
        $upd_user->bind_param("di", $cost, $payer_id);
        $upd_user->execute();
        
        // 5. Log Message to Database
        $direction = 'inbound';
        $status = 'received';
        
        // Ensure table exists
        $conn->query("CREATE TABLE IF NOT EXISTS message_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            direction ENUM('inbound', 'outbound'),
            from_number VARCHAR(20),
            to_number VARCHAR(20),
            body TEXT,
            cost DECIMAL(10,4) DEFAULT 0,
            status VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");

        $log_stmt = $conn->prepare("INSERT INTO message_logs (user_id, direction, from_number, to_number, body, cost, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $log_stmt->bind_param("issssds", $payer_id, $direction, $from_number, $to_number, $body, $cost, $status);
        $log_stmt->execute();
    }
}

http_response_code(200);
?>