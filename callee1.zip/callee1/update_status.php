<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$status = $data['status'] ?? 'offline';
$agent_id = $_SESSION['user_id'];

// Update availability_status
$stmt = $conn->prepare("UPDATE users SET availability_status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $agent_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>