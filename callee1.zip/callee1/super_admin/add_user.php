<?php
include '../db_connect.php';

// Fetch admins for dropdown
$admins = [];
$admin_res = $conn->query("SELECT id, username FROM users WHERE role = 'admin'");
if ($admin_res) {
    $admins = $admin_res->fetch_all(MYSQLI_ASSOC);
}

// Calculate next available SIP extension
$next_sip_ext = 101; // Default start
$ext_query = "SELECT MAX(CAST(sip_extension AS UNSIGNED)) as max_ext FROM users WHERE sip_extension REGEXP '^[0-9]+$'";
$ext_res = $conn->query($ext_query);
if ($ext_res && $row = $ext_res->fetch_assoc()) {
    if ($row['max_ext'] > 0) {
        $next_sip_ext = (int)$row['max_ext'] + 1;
    }
}

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $admin_id = !empty($_POST['admin_id']) ? (int)$_POST['admin_id'] : 'NULL';
    $sip_extension = !empty($_POST['sip_extension']) ? $_POST['sip_extension'] : $next_sip_ext;
    $sip_password = !empty($_POST['sip_password']) ? $_POST['sip_password'] : 'password' . $sip_extension;

    if (!empty($username) && !empty($password) && !empty($role) && !empty($status)) {
        
      $sql = "INSERT INTO users (username, password, role, status, admin_id, sip_extension, sip_password) VALUES ('$username', '$password', '$role', '$status', $admin_id, '$sip_extension', '$sip_password')";
        $result = $conn->query($sql);

        if ($result == 1 ) {
            // --- AUTOMATIC PJSIP.CONF UPDATE ---
            $pjsip_file = '/etc/asterisk/pjsip.conf';
            
            $pjsip_content  = "\n";
            $pjsip_content .= "; ==============================\n";
            $pjsip_content .= "; AGENT $sip_extension\n";
            $pjsip_content .= "; ==============================\n";
            $pjsip_content .= "[$sip_extension]\n";
            $pjsip_content .= "type=endpoint\n";
            $pjsip_content .= "context=from-portal\n";
            $pjsip_content .= "disallow=all\n";
            $pjsip_content .= "allow=ulaw,vp8,opus\n";
            $pjsip_content .= "auth=$sip_extension-auth\n";
            $pjsip_content .= "aors=$sip_extension-aor\n";
            $pjsip_content .= "use_avpf=yes\n";
            $pjsip_content .= "media_encryption=dtls\n";
            $pjsip_content .= "dtls_verify=fingerprint\n";
            $pjsip_content .= "dtls_setup=actpass\n";
            $pjsip_content .= "ice_support=yes\n";
            $pjsip_content .= "media_use_received_transport=yes\n";
            $pjsip_content .= "rtcp_mux=yes\n";
            $pjsip_content .= "transport=transport-ws\n";
            $pjsip_content .= "webrtc=yes\n";
            $pjsip_content .= "dtls_cert_file=/etc/asterisk/keys/asterisk.pem\n";
            $pjsip_content .= "dtls_private_key=/etc/asterisk/keys/asterisk.pem\n";
            $pjsip_content .= "dtls_ca_file=/etc/asterisk/keys/ca.crt\n\n";
            
            $pjsip_content .= "[$sip_extension-auth]\n";
            $pjsip_content .= "type=auth\n";
            $pjsip_content .= "auth_type=userpass\n";
            $pjsip_content .= "password=$sip_password\n";
            $pjsip_content .= "username=$sip_extension\n\n";
            
            $pjsip_content .= "[$sip_extension-aor]\n";
            $pjsip_content .= "type=aor\n";
            $pjsip_content .= "max_contacts=1\n";
            $pjsip_content .= "remove_existing=yes\n";

            // Append to file if writable
            if (file_exists($pjsip_file) && is_writable($pjsip_file)) {
                file_put_contents($pjsip_file, $pjsip_content, FILE_APPEND | LOCK_EX);
            }
            // -----------------------------------

            header("Location: user_management.php");
            exit();
        } else {
            $error = "Error: " . $conn->error;
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<?php 
$active_menu = 'users';
include 'header.php'; ?>
            
            <div class="content-area" id="contentArea"> 
    <!-- Create User Modal -->
    <div id="createUserModal" class="modal.show">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New User</h2>
                <button class="close-btn" onclick="closeCreateUserModal()">&times;</button>
            </div>
             <?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
            <form id="createUserForm" action="add_user.php" method="post" class="modal-fields">
                <div class="form-row">
                    <div class="form-group">
                        <label>Username *</label>
                        <input type="text" name="username" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Role *</label>
                        <select name="role" required>
                            <option value="agent">Agent</option>
                            <option value="admin">Admin</option>
                            <option value="super_admin">Super Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Assign Admin (For Agents)</label>
                        <select name="admin_id">
                            <option value="">-- None --</option>
                            <?php foreach ($admins as $admin): ?>
                                <option value="<?= $admin['id'] ?>"><?= htmlspecialchars($admin['username']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="unpaid">Unpaid</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>SIP Extension</label>
                        <input type="text" name="sip_extension" placeholder="Ex: 101" value="<?= $next_sip_ext ?>">
                    </div>
                    <div class="form-group">
                        <label>SIP Password</label>
                        <input type="text" name="sip_password" placeholder="Ex: password101" value="password<?= $next_sip_ext ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Password *</label>
                        <input type="password" name="password" required>
                    </div>
                    <!-----div class="form-group">
                        <label>Initial Credits</label>
                        <input type="number" name="credits" value="0" step="0.01">
                    </div-------->
                </div>
                <div class="modal-footer">
                    <a href="user_management.php">
                    <button type="button" class="btn-secondary" onclick="closeCreateUserModal()">Cancel</button></a>
                    <button type="submit" name="submit" class="btn-primary">Create User</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
