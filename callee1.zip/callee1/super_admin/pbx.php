<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}
?>
<?php 
$active_menu = 'pbx';
include 'header.php'; ?>
            
            </div>
<?php include 'footer.php'; ?>