        </main>
    </div>
    
    <!-- Common JavaScript files -->
    <script src="/js/dashboard.js"></script>
    <script src="/js/super-admin.js"></script>
    <!-- Any other common scripts -->
</body>
</html>