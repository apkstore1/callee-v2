<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}
include '../db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['admin_id'], $_POST['amount'], $_POST['action'])) {
        $admin_id = intval($_POST['admin_id']);
        $amount = floatval($_POST['amount']);
        $action = $_POST['action'];

        if ($amount <= 0) {
            header('Location: credit_management.php?error=invalidamount');
            exit;
        }

        try {
            // Start a transaction to ensure data integrity
            $pdo->beginTransaction();

            // Lock the row for update to prevent race conditions
            $stmt = $pdo->prepare("SELECT credits FROM users WHERE id = ? AND role = 'admin' FOR UPDATE");
            $stmt->execute([$admin_id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($admin) {
                $current_credits = $admin['credits'];

                if ($action === 'add') {
                    $new_credits = $current_credits + $amount;
                } elseif ($action === 'remove') {
                    // Check if removal would result in negative balance
                    if ($current_credits < $amount) {
                        throw new Exception("Cannot remove more credits than the admin has.");
                    }
                    $new_credits = $current_credits - $amount;
                } else {
                    throw new Exception("Invalid action.");
                }

                $update_stmt = $pdo->prepare("UPDATE users SET credits = ? WHERE id = ?");
                $update_stmt->execute([$new_credits, $admin_id]);
                
                // Commit the transaction
                $pdo->commit();
                header('Location: credit_management.php?success=1');
            } else {
                throw new Exception("Admin user not found.");
            }
        } catch (Exception $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            header('Location: credit_management.php?error=' . urlencode($e->getMessage()));
        }
    } else {
        header('Location: credit_management.php?error=invaliddata');
    }
} else {
    header('Location: credit_management.php');
}
exit;
