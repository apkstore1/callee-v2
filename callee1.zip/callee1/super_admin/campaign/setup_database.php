<?php
// This script is for one-time setup of the database tables for the campaign feature.
// Run this script once to set up the database.

// Include the database connection file
require_once __DIR__ . '/../../db_connect.php';

try {
    // SQL to create the campaigns table
    $sql_create_campaigns = "
    CREATE TABLE IF NOT EXISTS `campaigns` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `name` VARCHAR(255) NOT NULL,
      `admin_id` INT,
      `dial_method` ENUM('manual', 'auto') DEFAULT 'manual',
      `start_date` DATE,
      `end_date` DATE,
      `status` VARCHAR(50) DEFAULT 'pending',
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";

    // Execute the create table statement for campaigns
    $pdo->exec($sql_create_campaigns);
    echo "Table 'campaigns' created successfully (if it didn't exist).<br>";

    // SQL to add 'allow_auto_dial' column to 'users' table
    $sql_add_column_users = "
    ALTER TABLE `users`
    ADD COLUMN `allow_auto_dial` BOOLEAN DEFAULT 0;
    ";

    // Check if the column already exists before trying to add it
    $stmt = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'allow_auto_dial'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec($sql_add_column_users);
        echo "Column 'allow_auto_dial' added to 'users' table successfully.<br>";
    } else {
        echo "Column 'allow_auto_dial' already exists in 'users' table.<br>";
    }

    // SQL to create the leads table
    $sql_create_leads = "
    CREATE TABLE IF NOT EXISTS `leads` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `campaign_id` INT,
      `phone_number` VARCHAR(20) NOT NULL,
      `status` VARCHAR(50) DEFAULT 'pending', -- e.g., pending, called, answered
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";

    // Execute the create table statement for leads
    $pdo->exec($sql_create_leads);
    echo "Table 'leads' created successfully (if it didn't exist).<br>";


} catch (PDOException $e) {
    die("Database setup failed: " . $e->getMessage());
}

echo "Database setup complete.";
?>
