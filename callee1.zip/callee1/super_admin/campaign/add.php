<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: /callee1/index.php');
    exit;
}
include '../../db_connect.php';

// Fetch admins with their auto_dial permission status
$admins = [];
$res = $conn->query("SELECT id, username, allow_auto_dial FROM users WHERE role = 'admin'");
if ($res) {
    $admins = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<?php 
$active_menu = 'campaigns';
include '../header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h2>Create New Campaign</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <div class="table-container" style="padding: 20px; max-width: 800px;">
        <form action="process_campaign.php" method="post" enctype="multipart/form-data" class="modal-fields">
            <input type="hidden" name="action" value="create">
            
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Campaign Name *</label>
                <input type="text" name="campaign_name" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Assign Admin *</label>
                <select name="admin_id" id="admin_id" required onchange="checkAutoDialPermission()" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                    <option value="" data-allow="0">-- Select Admin --</option>
                    <?php foreach ($admins as $admin): ?>
                        <option value="<?= $admin['id'] ?>" data-allow="<?= $admin['allow_auto_dial'] ?>">
                            <?= htmlspecialchars($admin['username']) ?> 
                            <?= ($admin['allow_auto_dial'] ? '(Auto Dial Allowed)' : '') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Dialing Method *</label>
                <select name="dial_method" id="dial_method" onchange="toggleFileUpload()" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                    <option value="manual">Manual Dialing</option>
                    <option value="auto" id="option_auto" disabled>Auto Dialing (Predictive)</option>
                </select>
                <small id="auto_dial_msg" style="color: #aaa; display: none;">Selected admin does not have permission for Auto Dialing.</small>
            </div>

            <div class="form-group" id="file_upload_div" style="margin-bottom: 15px; display: none; border: 1px dashed #444; padding: 15px; border-radius: 4px;">
                <label style="display:block; margin-bottom:5px; color: #00d9ff;">Upload Lead List (CSV) *</label>
                <input type="file" name="lead_list" accept=".csv" style="color: white;">
                <p style="font-size: 12px; color: #888; margin-top: 5px;">Format: Phone Number in first column.</p>
            </div>

            <div class="form-row" style="display: flex; gap: 15px;">
                <div class="form-group" style="flex: 1; margin-bottom: 15px;">
                    <label style="display:block; margin-bottom:5px;">Start Date *</label>
                    <input type="date" name="start_date" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                </div>
                <div class="form-group" style="flex: 1; margin-bottom: 15px;">
                    <label style="display:block; margin-bottom:5px;">End Date *</label>
                    <input type="date" name="end_date" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                </div>
            </div>

            <div class="form-footer" style="margin-top: 20px;">
                <button type="submit" class="btn-primary">Create Campaign</button>
            </div>
        </form>
    </div>
</div>

<script>
function checkAutoDialPermission() {
    var adminSelect = document.getElementById('admin_id');
    var selectedOption = adminSelect.options[adminSelect.selectedIndex];
    var allowAutoDial = selectedOption.getAttribute('data-allow');
    var autoOption = document.getElementById('option_auto');
    var dialSelect = document.getElementById('dial_method');
    var msg = document.getElementById('auto_dial_msg');

    if (allowAutoDial == '1') {
        autoOption.disabled = false;
        msg.style.display = 'none';
    } else {
        autoOption.disabled = true;
        dialSelect.value = 'manual'; // Reset to manual
        msg.style.display = 'block';
    }
    toggleFileUpload();
}

function toggleFileUpload() {
    var method = document.getElementById('dial_method').value;
    document.getElementById('file_upload_div').style.display = (method === 'auto') ? 'block' : 'none';
}
</script>
<?php include '../footer.php'; ?>