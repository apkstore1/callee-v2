<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: /callee1/index.php');
    exit;
}

require_once __DIR__ . '/../../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'create';
    $campaign_name = $_POST['campaign_name'] ?? '';
    $admin_id = $_POST['admin_id'] ?? null;
    $start_date = $_POST['start_date'] ?? null;
    $end_date = $_POST['end_date'] ?? null;
    $dial_method = $_POST['dial_method'] ?? 'manual';

    // Server-side validation
    if (empty($campaign_name) || empty($admin_id) || empty($start_date) || empty($end_date)) {
        header('Location: index.php?error=missingfields');
        exit;
    }

    // Verify Admin Permission for Auto Dial
    if ($dial_method === 'auto') {
        $check = $conn->query("SELECT allow_auto_dial FROM users WHERE id = " . (int)$admin_id);
        $row = $check->fetch_assoc();
        if (!$row || $row['allow_auto_dial'] == 0) {
            header('Location: index.php?error=Admin does not have auto dial permission');
            exit;
        }
    }

    if ($action === 'create') {
        // Insert campaign
        $stmt = $conn->prepare("INSERT INTO campaigns (name, admin_id, dial_method, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("sisss", $campaign_name, $admin_id, $dial_method, $start_date, $end_date);
        
        if ($stmt->execute()) {
            $campaign_id = $conn->insert_id;
            $stmt->close();

            // Handle CSV Upload
            handleCsvUpload($conn, $campaign_id);

            header('Location: index.php?success=Campaign created successfully');
        } else {
            header('Location: index.php?error=' . urlencode($conn->error));
        }
    } elseif ($action === 'update') {
        $campaign_id = $_POST['campaign_id'];
        $stmt = $conn->prepare("UPDATE campaigns SET name=?, admin_id=?, dial_method=?, start_date=?, end_date=? WHERE id=?");
        $stmt->bind_param("sisssi", $campaign_name, $admin_id, $dial_method, $start_date, $end_date, $campaign_id);
        
        if ($stmt->execute()) {
            $stmt->close();
            // Handle CSV Upload (Append leads)
            handleCsvUpload($conn, $campaign_id);
            header('Location: index.php?success=Campaign updated successfully');
        } else {
            header('Location: index.php?error=' . urlencode($conn->error));
        }
    }
    exit;
}

function handleCsvUpload($conn, $campaign_id) {
    if (isset($_FILES['lead_list']) && $_FILES['lead_list']['error'] == UPLOAD_ERR_OK) {
        $csv_file = $_FILES['lead_list']['tmp_name'];
        
        if (($handle = fopen($csv_file, "r")) !== FALSE) {
            $lead_stmt = $conn->prepare("INSERT INTO leads (campaign_id, phone_number, status) VALUES (?, ?, 'pending')");
            
            // Optional: Skip header if first row contains text
            // fgetcsv($handle); 

            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $phone_number = trim($data[0]); // Assuming phone number is in the first column
                if (!empty($phone_number) && is_numeric($phone_number)) {
                    $lead_stmt->bind_param("is", $campaign_id, $phone_number);
                    $lead_stmt->execute();
                }
            }
            fclose($handle);
            $lead_stmt->close();
        }
    }
}
?>
