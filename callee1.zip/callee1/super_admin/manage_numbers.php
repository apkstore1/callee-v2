<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}
include '../db_connect.php';

// Handle form submission for adding/editing a number
$message = '';
$msg_type = 'error';

// Fetch Admins for dropdown
$admins_list = [];
$admin_res = $conn->query("SELECT id, username FROM users WHERE role = 'admin'");
if ($admin_res) {
    $admins_list = $admin_res->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'delete') {
        $id = (int)$_POST['number_id'];
        $stmt = $conn->prepare("DELETE FROM phone_numbers WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $message = "Number deleted successfully!";
            $msg_type = 'success';
        } else {
            $message = "Error deleting number: " . $conn->error;
        }
        $stmt->close();
    } elseif ($action === 'add' || $action === 'edit') {
        $number = $_POST['number'];
        $type = $_POST['type'];
        $price = (float)$_POST['price'];
        
        if (!empty($number) && !empty($type) && $price >= 0) {
            if ($action === 'add') {
                $status = 'available';
                $stmt = $conn->prepare("INSERT INTO phone_numbers (number, type, price, status) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssds", $number, $type, $price, $status);
            } else {
                $id = (int)$_POST['number_id'];
                $stmt = $conn->prepare("UPDATE phone_numbers SET number=?, type=?, price=? WHERE id=?");
                $stmt->bind_param("ssdi", $number, $type, $price, $id);
            }

            if ($stmt->execute()) {
                $message = "Number " . ($action == 'add' ? "added" : "updated") . " successfully!";
                $msg_type = 'success';
            } else {
                $message = "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $message = "Please fill all fields correctly.";
        }
    } elseif ($action === 'assign_number') {
        $number_id = (int)$_POST['number_id'];
        $admin_id = (int)$_POST['admin_id'];
        
        $conn->begin_transaction();
        try {
            // Check if number is available
            $check = $conn->query("SELECT id FROM phone_numbers WHERE id = $number_id AND status = 'available'");
            if ($check->num_rows == 0) throw new Exception("Number is not available.");

            // Assign to admin
            $stmt = $conn->prepare("INSERT INTO admin_numbers (admin_id, number_id, status) VALUES (?, ?, 'active')");
            $stmt->bind_param("ii", $admin_id, $number_id);
            $stmt->execute();

            // Update phone_numbers status
            $conn->query("UPDATE phone_numbers SET status = 'assigned' WHERE id = $number_id");

            $conn->commit();
            $message = "Number assigned to admin successfully!";
            $msg_type = 'success';
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error assigning number: " . $e->getMessage();
        }
    } elseif ($action === 'update_status') {
        $assignment_id = (int)$_POST['assignment_id'];
        $new_status = $_POST['status'];
        
        $stmt = $conn->prepare("UPDATE admin_numbers SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $assignment_id);
        if ($stmt->execute()) {
            $message = "Status updated successfully!";
            $msg_type = 'success';
        } else {
            $message = "Error updating status: " . $conn->error;
        }
    } elseif ($action === 'revoke_number') {
        $assignment_id = (int)$_POST['assignment_id'];
        $number_id = (int)$_POST['number_id'];

        $conn->begin_transaction();
        try {
            $conn->query("DELETE FROM admin_numbers WHERE id = $assignment_id");
            $conn->query("UPDATE phone_numbers SET status = 'available' WHERE id = $number_id");
            $conn->commit();
            $message = "Number revoked and returned to pool.";
            $msg_type = 'success';
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error revoking number: " . $e->getMessage();
        }
    }
}

// Fetch all numbers from the pool
$numbers = [];
$result = $conn->query("SELECT * FROM phone_numbers ORDER BY created_at DESC");
if ($result) {
    $numbers = $result->fetch_all(MYSQLI_ASSOC);
}

// Fetch Assigned Numbers
$assigned_numbers = [];
$sql_assigned = "SELECT an.id as assignment_id, an.status as admin_status, an.purchase_date, 
                 pn.id as number_id, pn.number, pn.type, u.username as admin_name 
                 FROM admin_numbers an 
                 JOIN phone_numbers pn ON an.number_id = pn.id 
                 JOIN users u ON an.admin_id = u.id 
                 ORDER BY an.purchase_date DESC";
$res_assigned = $conn->query($sql_assigned);
if ($res_assigned) {
    $assigned_numbers = $res_assigned->fetch_all(MYSQLI_ASSOC);
}

$active_menu = 'numbers';
include 'header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>Number Pool</h2>
        <button class="btn-primary" onclick="openNumberModal()">+ Add Number</button>
    </div>

    <?php if ($message): ?>
        <div class="alert" style="background: <?= $msg_type == 'success' ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)' ?>; color: <?= $msg_type == 'success' ? '#86efac' : '#fca5a5' ?>; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="filter-bar" style="margin-bottom: 15px; display: flex; gap: 10px;">
        <input type="text" id="poolSearch" placeholder="Search Number..." class="search-input" onkeyup="filterPool()">
        <select id="poolTypeFilter" class="filter-select" onchange="filterPool()">
            <option value="">All Types</option>
            <option value="local">Local</option>
            <option value="toll-free">Toll-Free</option>
        </select>
        <select id="poolStatusFilter" class="filter-select" onchange="filterPool()">
            <option value="">All Status</option>
            <option value="available">Available</option>
            <option value="assigned">Assigned</option>
            <option value="reserved">Reserved</option>
        </select>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Number</th>
                    <th>Type</th>
                    <th>Price/Month</th>
                    <th>Status</th>
                    <th>Added On</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="poolTableBody">
                <?php if (!empty($numbers)): ?>
                    <?php foreach ($numbers as $num): ?>
                        <tr>
                            <td><?= htmlspecialchars($num['number']) ?></td>
                            <td><span class="role-badge"><?= htmlspecialchars($num['type']) ?></span></td>
                            <td>$<?= number_format($num['price'], 2) ?></td>
                            <td><span class="status-badge status-<?= htmlspecialchars($num['status']) ?>"><?= htmlspecialchars($num['status']) ?></span></td>
                            <td><?= date('Y-m-d', strtotime($num['created_at'])) ?></td>
                            <td>
                                <button class="btn-secondary btn-sm" onclick="openEditModal(<?= $num['id'] ?>, '<?= htmlspecialchars($num['number']) ?>', '<?= htmlspecialchars($num['type']) ?>', <?= $num['price'] ?>)">Edit</button>
                                <button class="btn-danger btn-sm" onclick="deleteNumber(<?= $num['id'] ?>)">Delete</button>
                                <?php if ($num['status'] === 'available'): ?>
                                    <button class="btn-primary btn-sm" onclick="openAssignModal(<?= $num['id'] ?>, '<?= htmlspecialchars($num['number']) ?>')">Assign</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center">No numbers found in the pool.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="page-header" style="margin-top: 40px;">
        <h2>Assigned Numbers Management</h2>
    </div>

    <div class="filter-bar" style="margin-bottom: 15px; display: flex; gap: 10px;">
        <input type="text" id="assignedSearch" placeholder="Search Number or Admin..." class="search-input" onkeyup="filterAssigned()">
        <select id="assignedStatusFilter" class="filter-select" onchange="filterAssigned()">
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="pending_payment">Pending Payment</option>
        </select>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Number</th>
                    <th>Assigned To</th>
                    <th>Assigned Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="assignedTableBody">
                <?php if (!empty($assigned_numbers)): ?>
                    <?php foreach ($assigned_numbers as $assign): ?>
                        <tr>
                            <td><?= htmlspecialchars($assign['number']) ?></td>
                            <td><?= htmlspecialchars($assign['admin_name']) ?></td>
                            <td><?= date('Y-m-d', strtotime($assign['purchase_date'])) ?></td>
                            <td>
                                <span class="status-badge status-<?= ($assign['admin_status'] == 'active' ? 'available' : ($assign['admin_status'] == 'inactive' ? 'busy' : 'reserved')) ?>">
                                    <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $assign['admin_status']))) ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn-secondary btn-sm" onclick="openStatusModal(<?= $assign['assignment_id'] ?>, '<?= $assign['admin_status'] ?>', '<?= htmlspecialchars($assign['number']) ?>')">Change Status</button>
                                <button class="btn-danger btn-sm" onclick="revokeNumber(<?= $assign['assignment_id'] ?>, <?= $assign['number_id'] ?>)">Revoke</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">No numbers currently assigned to admins.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add/Edit Number Modal -->
<div id="numberModal" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
            <h2 id="modalTitle">Add New Number</h2>
            <button class="close-btn" onclick="closeNumberModal()">&times;</button>
        </div>
        <form id="numberForm" action="manage_numbers.php" method="POST" class="modal-fields">
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="number_id" id="numberId" value="">
            <div class="form-group"><label>Phone Number</label><input type="text" name="number" placeholder="+1xxxxxxxxxx" required></div>
            <div class="form-group"><label>Number Type</label><select name="type" required><option value="local">Local</option><option value="toll-free">Toll-Free</option></select></div>
            <div class="form-group"><label>Price (per month)</label><input type="number" name="price" step="0.01" min="0" placeholder="0.00" required></div>
            <div class="modal-footer"><button type="button" class="btn-secondary" onclick="closeNumberModal()">Cancel</button><button type="submit" class="btn-primary">Save Number</button></div>
        </form>
    </div>
</div>

<!-- Assign Number Modal -->
<div id="assignModal" class="modal">
    <div class="modal-content" style="max-width: 400px;">
        <div class="modal-header">
            <h2>Assign Number</h2>
            <button class="close-btn" onclick="closeAssignModal()">&times;</button>
        </div>
        <form action="manage_numbers.php" method="POST" class="modal-fields">
            <input type="hidden" name="action" value="assign_number">
            <input type="hidden" name="number_id" id="assignNumberId">
            <p style="margin-bottom: 15px;">Assigning: <strong id="assignNumberDisplay"></strong></p>
            <div class="form-group">
                <label>Select Admin</label>
                <select name="admin_id" required>
                    <option value="">-- Select Admin --</option>
                    <?php foreach ($admins_list as $admin): ?>
                        <option value="<?= $admin['id'] ?>"><?= htmlspecialchars($admin['username']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeAssignModal()">Cancel</button>
                <button type="submit" class="btn-primary">Assign</button>
            </div>
        </form>
    </div>
</div>

<!-- Change Status Modal -->
<div id="statusModal" class="modal">
    <div class="modal-content" style="max-width: 400px;">
        <div class="modal-header">
            <h2>Change Status</h2>
            <button class="close-btn" onclick="closeStatusModal()">&times;</button>
        </div>
        <form action="manage_numbers.php" method="POST" class="modal-fields">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="assignment_id" id="statusAssignmentId">
            <p style="margin-bottom: 15px;">Number: <strong id="statusNumberDisplay"></strong></p>
            <div class="form-group">
                <label>Status</label>
                <select name="status" id="statusSelect" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="pending_payment">Pending Payment</option>
                </select>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeStatusModal()">Cancel</button>
                <button type="submit" class="btn-primary">Update Status</button>
            </div>
        </form>
    </div>
</div>

<script>
function openNumberModal(){
    document.getElementById('numberModal').style.display='flex';
    document.getElementById('modalTitle').innerText = 'Add New Number';
    document.getElementById('formAction').value = 'add';
    document.getElementById('numberId').value = '';
    document.getElementById('numberForm').reset();
}
function openEditModal(id, number, type, price){
    document.getElementById('numberModal').style.display='flex';
    document.getElementById('modalTitle').innerText = 'Edit Number';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('numberId').value = id;
    document.querySelector('input[name="number"]').value = number;
    document.querySelector('select[name="type"]').value = type;
    document.querySelector('input[name="price"]').value = price;
}
function deleteNumber(id){
    if(confirm('Are you sure you want to delete this number?')){
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'manage_numbers.php';
        const inputAction = document.createElement('input');
        inputAction.type = 'hidden';
        inputAction.name = 'action';
        inputAction.value = 'delete';
        form.appendChild(inputAction);
        const inputId = document.createElement('input');
        inputId.type = 'hidden';
        inputId.name = 'number_id';
        inputId.value = id;
        form.appendChild(inputId);
        document.body.appendChild(form);
        form.submit();
    }
}

// Assign Modal Functions
function openAssignModal(numberId, number){
    document.getElementById('assignModal').style.display='flex';
    document.getElementById('assignNumberId').value = numberId;
    document.getElementById('assignNumberDisplay').innerText = number;
}
function closeAssignModal(){
    document.getElementById('assignModal').style.display='none';
}

// Status Modal Functions
function openStatusModal(assignmentId, currentStatus, number){
    document.getElementById('statusModal').style.display='flex';
    document.getElementById('statusAssignmentId').value = assignmentId;
    document.getElementById('statusNumberDisplay').innerText = number;
    document.getElementById('statusSelect').value = currentStatus;
}
function closeStatusModal(){
    document.getElementById('statusModal').style.display='none';
}

// Revoke Function
function revokeNumber(assignmentId, numberId){
    if(confirm('Are you sure you want to revoke this number? It will be removed from the admin account and become available in the pool.')){
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'manage_numbers.php';
        const inputAction = document.createElement('input');
        inputAction.type = 'hidden'; inputAction.name = 'action'; inputAction.value = 'revoke_number';
        form.appendChild(inputAction);
        const inputId = document.createElement('input');
        inputId.type = 'hidden'; inputId.name = 'assignment_id'; inputId.value = assignmentId;
        form.appendChild(inputId);
        const inputNumId = document.createElement('input');
        inputNumId.type = 'hidden'; inputNumId.name = 'number_id'; inputNumId.value = numberId;
        form.appendChild(inputNumId);
        document.body.appendChild(form);
        form.submit();
    }
}

function filterPool() {
    const search = document.getElementById('poolSearch').value.toLowerCase();
    const type = document.getElementById('poolTypeFilter').value.toLowerCase();
    const status = document.getElementById('poolStatusFilter').value.toLowerCase();
    const rows = document.querySelectorAll('#poolTableBody tr');

    rows.forEach(row => {
        if(row.cells.length < 2) return;
        const number = row.cells[0].innerText.toLowerCase();
        const rowType = row.cells[1].innerText.toLowerCase();
        const rowStatus = row.cells[3].innerText.toLowerCase();

        const matchesSearch = number.includes(search);
        const matchesType = type === '' || rowType.includes(type);
        const matchesStatus = status === '' || rowStatus.includes(status);

        row.style.display = (matchesSearch && matchesType && matchesStatus) ? '' : 'none';
    });
}

function filterAssigned() {
    const search = document.getElementById('assignedSearch').value.toLowerCase();
    const status = document.getElementById('assignedStatusFilter').value.toLowerCase().replace('_', ' ');
    const rows = document.querySelectorAll('#assignedTableBody tr');

    rows.forEach(row => {
        if(row.cells.length < 2) return;
        const number = row.cells[0].innerText.toLowerCase();
        const admin = row.cells[1].innerText.toLowerCase();
        const rowStatus = row.cells[3].innerText.toLowerCase();

        const matchesSearch = number.includes(search) || admin.includes(search);
        const matchesStatus = status === '' || rowStatus.includes(status);

        row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
    });
}

function closeNumberModal(){document.getElementById('numberModal').style.display='none'}
window.onclick=function(e){
    if(e.target==document.getElementById('numberModal')) closeNumberModal();
    if(e.target==document.getElementById('assignModal')) closeAssignModal();
    if(e.target==document.getElementById('statusModal')) closeStatusModal();
};
</script>

<?php include 'footer.php'; ?>