<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: user_management.php?error_msg=Unauthorized');
    exit;
}

include '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $user_id = (int)$_POST['user_id'];
    
    // Determine which permission is being updated
    $field = '';
    $value = 0;
    $type_def = 'i'; // Default integer for permissions

    if (isset($_POST['allow_auto_dial'])) {
        $field = 'allow_auto_dial';
        $value = 1; // Checkbox sent means on
    } elseif (isset($_POST['allow_call'])) {
        $field = 'allow_call';
        $value = 1;
    } elseif (isset($_POST['allow_message'])) {
        $field = 'allow_message';
        $value = 1;
    } elseif (isset($_POST['custom_call_rate'])) {
        $field = 'custom_call_rate';
        $value = $_POST['custom_call_rate'] === '' ? NULL : $_POST['custom_call_rate'];
        $type_def = 'd'; // Decimal/Double
    } elseif (isset($_POST['custom_sms_rate'])) {
        $field = 'custom_sms_rate';
        $value = $_POST['custom_sms_rate'] === '' ? NULL : $_POST['custom_sms_rate'];
        $type_def = 'd'; // Decimal/Double
    } else {
        // If checkbox is unchecked, it's not sent in POST, so we need to check what was intended.
        // A simple way is to check keys, but since we submit form on change, we handle "off" logic carefully.
        // For simplicity in this specific UI flow where each toggle is a separate form:
        // We need to know WHICH toggle was clicked. 
        // Since the form submits on change, the unchecked box won't send the key.
        // FIX: We will check which key is MISSING if we assume one form per row per toggle? 
        // Actually, the previous code was flawed for unchecking because `isset` returns false.
        // Let's handle it by checking what *could* be sent.
        // Since we have 3 separate forms in the HTML above, we need a hidden input to identify the field or handle logic differently.
        // BETTER APPROACH: Update the HTML to include a hidden field for the permission name, OR handle individually.
        
        // Let's assume the previous logic was: if isset -> 1, else -> 0. 
        // But since we don't know which one was clicked if it's off, we need to detect the context.
        // Let's update the SQL to be dynamic based on what IS present, 
        // BUT for "OFF" state, the browser sends nothing.
        // To fix this properly without changing HTML structure too much:
        // We will assume this file handles one update at a time.
        // Since we can't easily know which one was unchecked, we will rely on a hidden input 'permission_type' if we could, 
        // but let's try to infer or just update the one that is set.
        
        // WAIT: The original code `isset($_POST['allow_auto_dial']) ? 1 : 0` implies it sets to 0 if not set.
        // But if I click "Allow Call", `allow_auto_dial` is not set, so it would disable auto dial!
        // We must fix this.
        
        // Let's look at the HTML I added. Each toggle is its OWN form.
        // So if I toggle "Allow Call", only `user_id` and `allow_call` (if checked) are sent.
        // If I uncheck "Allow Call", only `user_id` is sent.
        // This is ambiguous.
        
        // QUICK FIX: Modify the HTML in user_management.php to include a hidden input `permission_type`.
        // I will update the PHP here to expect `permission_type`.
    }

    // Since I cannot edit the HTML in this block to add hidden inputs easily without making the diff huge,
    // I will use a trick: The HTML I provided above uses `onchange="this.form.submit()"`.
    // I will update the HTML in Step 1 to include `<input type="hidden" name="perm_type" value="allow_call">`.
    
    // Let's rewrite the HTML part in Step 1 slightly to include hidden inputs, 
    // and then write the PHP here to use them.
    
    // RE-PLAN for PHP:
    // I will assume the user will update the HTML as per my previous diff, but I will add the hidden input in the diff above.
    // Wait, I can't edit the previous diff block. I will provide the corrected HTML diff below.
}

// Correct Logic with hidden input support (See updated HTML diff below)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['perm_type'])) {
    $user_id = (int)$_POST['user_id'];
    $perm_type = $_POST['perm_type'];
    
    // Validate permission type
    $allowed_perms = ['allow_auto_dial', 'allow_call', 'allow_message', 'custom_call_rate', 'custom_sms_rate'];
    if (!in_array($perm_type, $allowed_perms)) {
        die("Invalid permission type");
    }

    // Check if the checkbox for this specific permission was checked
    // The checkbox name should match the perm_type
    if ($type_def === 'i') {
        $value = isset($_POST[$perm_type]) ? 1 : 0;
    } else {
        // For rates, value is already set above
    }

    // Use the field name determined above or fallback to perm_type if logic matches
    $target_field = $field ? $field : $perm_type;

    $stmt = $conn->prepare("UPDATE users SET $target_field = ? WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param($type_def . "i", $value, $user_id);
        if ($stmt->execute()) {
            header('Location: user_management.php?success_msg=Permission_updated');
            exit;
        } 
        echo "Error updating record: " . $stmt->error;
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    header('Location: user_management.php?error_msg=Invalid_request');
    exit;
}
?>
