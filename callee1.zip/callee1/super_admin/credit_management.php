<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}
include '../db_connect.php';

$message = '';
$msg_type = '';

// Handle Credit Update Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_credits'])) {
    $admin_id = (int)$_POST['admin_id'];
    $amount = (float)$_POST['amount'];
    $operation = $_POST['operation']; // 'add' or 'deduct'

    if ($amount > 0) {
        if ($operation === 'deduct') {
            $amount = -$amount; // Make amount negative for deduction
        }

        // Update query using MySQLi
        $stmt = $conn->prepare("UPDATE users SET credits = credits + ? WHERE id = ? AND role = 'admin'");
        $stmt->bind_param("di", $amount, $admin_id);

        if ($stmt->execute()) {
            $message = "Credits updated successfully!";
            $msg_type = "success";
        } else {
            $message = "Error updating credits: " . $conn->error;
            $msg_type = "error";
        }
        $stmt->close();
    } else {
        $message = "Please enter a valid amount.";
        $msg_type = "error";
    }
}

// Fetch all admins and their credit balances
$admins = [];
$sql = "SELECT u.id, u.username, u.credits, (SELECT COUNT(id) FROM users WHERE admin_id = u.id) as agent_count 
        FROM users u 
        WHERE u.role = 'admin'";
$result = $conn->query($sql);
if ($result) {
    $admins = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<?php 
$active_menu = 'credits';
include 'header.php'; ?>
            
            <div class="content-area">
                <div class="page-header">
                    <h2>Credit Management</h2>
                </div>

                <?php if ($message): ?>
                    <div style="padding: 15px; margin-bottom: 20px; border-radius: 8px; background: <?= $msg_type == 'success' ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)' ?>; color: <?= $msg_type == 'success' ? '#86efac' : '#fca5a5' ?>; border: 1px solid <?= $msg_type == 'success' ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)' ?>;">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Admin Name</th>
                                <th>Agents Linked</th>
                                <th>Current Balance</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($admins)): ?>
                                <?php foreach ($admins as $admin): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($admin['username']) ?></td>
                                        <td><?= htmlspecialchars($admin['agent_count']) ?></td>
                                        <td style="font-weight: bold; color: #00ff88;">$<?= number_format($admin['credits'], 2) ?></td>
                                        <td>
                                            <button class="btn-primary btn-sm" onclick="openCreditModal(<?= $admin['id'] ?>, '<?= htmlspecialchars($admin['username']) ?>')">
                                                Manage Credits
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="4" class="text-center">No admins found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Credit Modal -->
            <div id="creditModal" class="modal">
                <div class="modal-content" style="max-width: 500px;">
                    <div class="modal-header">
                        <h2 id="modalTitle">Manage Credits</h2>
                        <button class="close-btn" onclick="closeCreditModal()">&times;</button>
                    </div>
                    <form action="credit_management.php" method="POST" class="modal-fields">
                        <input type="hidden" name="admin_id" id="modalAdminId">
                        <input type="hidden" name="update_credits" value="1">
                        
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label>Admin Account</label>
                            <input type="text" id="modalAdminName" disabled style="width: 100%; padding: 10px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 4px;">
                        </div>

                        <div class="form-group" style="margin-bottom: 15px;">
                            <label>Action</label>
                            <select name="operation" style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 4px;">
                                <option value="add">Add Credits (+)</option>
                                <option value="deduct">Deduct Credits (-)</option>
                            </select>
                        </div>

                        <div class="form-group" style="margin-bottom: 20px;">
                            <label>Amount ($)</label>
                            <input type="number" name="amount" step="0.01" min="0.01" placeholder="0.00" required style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 4px;">
                        </div>

                        <div class="form-footer">
                            <button type="button" class="btn-secondary" onclick="closeCreditModal()">Cancel</button>
                            <button type="submit" class="btn-primary">Update Balance</button>
                        </div>
                    </form>
                </div>
            </div>

            <script>
            function openCreditModal(id, username) {
                document.getElementById('modalAdminId').value = id;
                document.getElementById('modalAdminName').value = username;
                document.getElementById('modalTitle').innerText = 'Manage Credits: ' + username;
                
                const modal = document.getElementById('creditModal');
                modal.style.display = 'flex';
                // Small delay to allow display:flex to apply before adding opacity class if you have transitions
                setTimeout(() => {
                    modal.classList.add('show');
                }, 10);
            }

            function closeCreditModal() {
                const modal = document.getElementById('creditModal');
                modal.classList.remove('show');
                setTimeout(() => {
                    modal.style.display = 'none';
                }, 200); // Match transition duration
            }

            // Close modal if clicked outside
            window.onclick = function(event) {
                const modal = document.getElementById('creditModal');
                if (event.target == modal) {
                    closeCreditModal();
                }
            }
            </script>

<?php include 'footer.php'; ?>
