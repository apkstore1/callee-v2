<?php
include '../db_connect.php';

$id = 0;
if(isset($_GET['id'])) {
    $id = $_GET['id'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $sql = "DELETE FROM users WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: user_management.php");
        exit();
    } else {
        $error = "Error deleting user: " . $conn->error;
    }
}
?>
<?php 
$active_menu = 'users';
include 'header.php'; ?>
            <div class="content-area">
                <div class="container">
                    <h2>Delete User</h2>
                    <?php if(isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
                    <p>Are you sure you want to delete this user?</p>
                    <form action="delete_user.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" value="Delete">
                        <a href="user_management.php">Cancel</a>
                    </form>
                </div>
            </div>
<?php include 'footer.php'; ?>
