<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}

include '../db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: user_management.php?error_msg=Invalid User ID');
    exit;
}

$error_message = '';
$success_message = '';

// Fetch admins for dropdown
$admins = [];
$admin_res = $conn->query("SELECT id, username FROM users WHERE role = 'admin'");
if ($admin_res) {
    $admins = $admin_res->fetch_all(MYSQLI_ASSOC);
}

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $password = $_POST['password'];
    $admin_id = !empty($_POST['admin_id']) ? (int)$_POST['admin_id'] : NULL;
    $sip_extension = $_POST['sip_extension'];
    $sip_password = $_POST['sip_password'];

    if (empty($username) || empty($role) || empty($status)) {
        $error_message = "Username, Role, and Status are required.";
    } else {
        if (!empty($password)) {
            // Update with password
            // Note: Using plain text to match add_user.php. If hashing is needed, use password_hash($password, PASSWORD_DEFAULT)
            $sql = "UPDATE users SET username = ?, role = ?, status = ?, password = ?, admin_id = ?, sip_extension = ?, sip_password = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssissi", $username, $role, $status, $password, $admin_id, $sip_extension, $sip_password, $id);
        } else {
            // Update without password
            $sql = "UPDATE users SET username = ?, role = ?, status = ?, admin_id = ?, sip_extension = ?, sip_password = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssissi", $username, $role, $status, $admin_id, $sip_extension, $sip_password, $id);
        }

        try {
            if ($stmt->execute()) {
                $success_message = "User updated successfully!";
            } else {
                $error_message = "Error updating user: " . $stmt->error;
            }
        } catch (mysqli_sql_exception $e) {
            $error_message = "Database Error: " . $e->getMessage();
        }
        $stmt->close();
    }
}

// Fetch User Data
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: user_management.php?error_msg=User not found');
    exit;
}
?>
<?php 
$active_menu = 'users';
include 'header.php'; ?>
            
            <div class="content-area">
                <div class="page-header">
                    <h2>Edit User</h2>
                    <a href="user_management.php">
                        <button class="btn-secondary">Back to Users</button>
                    </a>
                </div>

                <?php if ($error_message): ?>
                    <p style="color:red; margin-bottom: 15px;"><?php echo $error_message; ?></p>
                <?php endif; ?>
                <?php if ($success_message): ?>
                    <p style="color:green; margin-bottom: 15px;"><?php echo $success_message; ?></p>
                <?php endif; ?>

                <div class="table-container" style="padding: 20px; max-width: 600px;">
                    <form action="edit_user.php?id=<?php echo $id; ?>" method="post" class="modal-fields">
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px;">Username *</label>
                            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                        </div>
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px;">Role *</label>
                            <select name="role" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                                <option value="agent" <?php echo ($user['role'] === 'agent') ? 'selected' : ''; ?>>Agent</option>
                                <option value="admin" <?php echo ($user['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                                <option value="superadmin" <?php echo ($user['role'] === 'superadmin') ? 'selected' : ''; ?>>Super Admin</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px;">Assign Admin (For Agents)</label>
                            <select name="admin_id" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                                <option value="">-- None --</option>
                                <?php foreach ($admins as $admin): ?>
                                    <option value="<?= $admin['id'] ?>" <?php echo ($user['admin_id'] == $admin['id']) ? 'selected' : ''; ?>><?= htmlspecialchars($admin['username']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px;">Status *</label>
                            <select name="status" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                                <option value="active" <?php echo ($user['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo ($user['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                <option value="unpaid" <?php echo ($user['status'] === 'unpaid') ? 'selected' : ''; ?>>Unpaid</option>
                                <option value="suspended" <?php echo ($user['status'] === 'suspended') ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px;">SIP Extension</label>
                            <input type="text" name="sip_extension" value="<?php echo htmlspecialchars($user['sip_extension'] ?? ''); ?>" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                        </div>
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display:block; margin-bottom:5px;">SIP Password</label>
                            <input type="text" name="sip_password" value="<?php echo htmlspecialchars($user['sip_password'] ?? ''); ?>" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                        </div>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label style="display:block; margin-bottom:5px;">Password</label>
                            <input type="password" name="password" placeholder="Leave blank to keep current password" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                        </div>
                        <div class="form-footer">
                            <button type="submit" name="submit" class="btn-primary">Update User</button>
                        </div>
                    </form>
                </div>
            </div>
<?php include 'footer.php'; ?>