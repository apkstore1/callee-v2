<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: /callee1/index.php');
    exit;
}
include '../../db_connect.php';

$error_message = '';
$carrier = null;

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$carrier_id = $_GET['id'];

// Fetch carrier details
$stmt = $conn->prepare("SELECT carrier_name, host, port, username FROM sip_carriers WHERE id = ?");
$stmt->bind_param("i", $carrier_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $carrier = $result->fetch_assoc();
} else {
    header('Location: index.php?error=notfound');
    exit;
}
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $carrier_name = $_POST['carrier_name'];
    $host = $_POST['host'];
    $port = $_POST['port'];
    $username = $_POST['username'];
    $secret = $_POST['secret']; // Can be empty if not changed

    if (empty($carrier_name) || empty($host) || empty($port)) {
        $error_message = "Carrier Name, Host, and Port are required.";
    } else {
        if (!empty($secret)) {
            $sql = "UPDATE sip_carriers SET carrier_name=?, host=?, port=?, username=?, secret=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssissi", $carrier_name, $host, $port, $username, $secret, $carrier_id);
        } else {
            $sql = "UPDATE sip_carriers SET carrier_name=?, host=?, port=?, username=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssisi", $carrier_name, $host, $port, $username, $carrier_id);
        }
        
        if ($stmt->execute()) {
            header("Location: index.php?success=updated");
            exit;
        } else {
            $error_message = "Error updating carrier: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<?php 
$active_menu = 'sip_carriers';
include '../header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h2>Edit SIP Carrier</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <?php if ($error_message): ?>
        <p style="color:red; margin-bottom: 15px;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <div class="table-container" style="padding: 20px; max-width: 600px;">
        <form action="edit.php?id=<?= $carrier_id ?>" method="post" class="modal-fields">
            <div class="form-group" style="margin-bottom: 15px;"><label style="display:block; margin-bottom:5px;">Carrier Name *</label><input type="text" name="carrier_name" value="<?= htmlspecialchars($carrier['carrier_name']) ?>" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;"></div>
            <div class="form-group" style="margin-bottom: 15px;"><label style="display:block; margin-bottom:5px;">Host / IP Address *</label><input type="text" name="host" value="<?= htmlspecialchars($carrier['host']) ?>" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;"></div>
            <div class="form-group" style="margin-bottom: 15px;"><label style="display:block; margin-bottom:5px;">Port</label><input type="number" name="port" value="<?= htmlspecialchars($carrier['port']) ?>" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;"></div>
            <div class="form-group" style="margin-bottom: 15px;"><label style="display:block; margin-bottom:5px;">Username (SIP User)</label><input type="text" name="username" value="<?= htmlspecialchars($carrier['username']) ?>" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;"></div>
            <div class="form-group" style="margin-bottom: 20px;"><label style="display:block; margin-bottom:5px;">Secret / Password</label><input type="text" name="secret" placeholder="Leave blank to keep current" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;"></div>
            <div class="form-footer"><button type="submit" name="submit" class="btn-primary">Update Carrier</button></div>
        </form>
    </div>
</div>
<?php include '../footer.php'; ?>