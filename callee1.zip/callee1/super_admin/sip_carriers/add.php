<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: /callee1/index.php');
    exit;
}
include '../../db_connect.php';

$error = '';

if (isset($_POST['submit'])) {
    $carrier_name = $_POST['carrier_name'];
    $host = $_POST['host'];
    $port = !empty($_POST['port']) ? $_POST['port'] : 5060;
    $username = $_POST['username'];
    $secret = $_POST['secret'];

    if (!empty($carrier_name) && !empty($host)) {
        $stmt = $conn->prepare("INSERT INTO sip_carriers (carrier_name, host, port, username, secret) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiss", $carrier_name, $host, $port, $username, $secret);
        
        if ($stmt->execute()) {
            header("Location: index.php?success=created");
            exit();
        } else {
            $error = "Error: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error = "Carrier Name and Host are required.";
    }
}
?>
<?php 
$active_menu = 'sip_carriers';
include '../header.php'; ?>

<div class="content-area">
    <div class="page-header">
        <h2>Add New SIP Carrier</h2>
        <a href="index.php"><button class="btn-secondary">Back</button></a>
    </div>

    <?php if ($error): ?>
        <p style="color:red; margin-bottom: 15px;"><?php echo $error; ?></p>
    <?php endif; ?>

    <div class="table-container" style="padding: 20px; max-width: 600px;">
        <form action="add.php" method="post" class="modal-fields">
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Carrier Name *</label>
                <input type="text" name="carrier_name" placeholder="e.g. SignalWire, Telnyx" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Host / IP Address *</label>
                <input type="text" name="host" placeholder="e.g. sip.telnyx.com" required style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Port</label>
                <input type="number" name="port" value="5060" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:5px;">Username (SIP User)</label>
                <input type="text" name="username" placeholder="SIP Username" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>
            <div class="form-group" style="margin-bottom: 20px;">
                <label style="display:block; margin-bottom:5px;">Secret / Password</label>
                <input type="text" name="secret" placeholder="SIP Password" style="width: 100%; padding: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
            </div>
            <div class="form-footer">
                <button type="submit" name="submit" class="btn-primary">Add Carrier</button>
            </div>
        </form>
    </div>
</div>
<?php include '../footer.php'; ?>