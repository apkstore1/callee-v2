<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: /callee1/index.php');
    exit;
}
include '../../db_connect.php';

// Fetch existing SIP carriers
$sql = "SELECT * FROM sip_carriers";
$result = $conn->query($sql);
?>
<?php 
$active_menu = 'sip_carriers';
include '../header.php'; ?>
            
            <div class="content-area">
                <div class="page-header">
                    <h2>SIP Carriers</h2>
                    <a href="add.php">
                        <button class="btn-primary">
                            <span>+ Add Carrier</span>
                        </button>
                    </a>
                </div>

                <?php if (isset($_GET['success'])): ?>
                    <p style="color:green; margin-bottom:15px;">
                        <?php 
                        if($_GET['success'] == 'created') echo "Carrier added successfully!";
                        if($_GET['success'] == 'updated') echo "Carrier updated successfully!";
                        if($_GET['success'] == 'deleted') echo "Carrier deleted successfully!";
                        ?>
                    </p>
                <?php endif; ?>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Carrier Name</th>
                                <th>Host (IP/Domain)</th>
                                <th>Port</th>
                                <th>Username</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['id']) ?></td>
                                        <td><?= htmlspecialchars($row['carrier_name']) ?></td>
                                        <td><?= htmlspecialchars($row['host']) ?></td>
                                        <td><?= htmlspecialchars($row['port']) ?></td>
                                        <td><?= htmlspecialchars($row['username']) ?></td>
                                        <td>
                                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn-secondary btn-sm">Edit</a>
                                            <a href="delete.php?id=<?= $row['id'] ?>" class="btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this carrier?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align:center;">No SIP Carriers found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
<?php include '../footer.php'; ?>
