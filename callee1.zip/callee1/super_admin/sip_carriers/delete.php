<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: /callee1/index.php');
    exit;
}
include '../../db_connect.php';

if (!isset($_GET['id'])) {
    header('Location: index.php?error=noid');
    exit;
}

$carrier_id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM sip_carriers WHERE id = ?");
$stmt->bind_param("i", $carrier_id);

if ($stmt->execute()) {
    header("Location: index.php?success=deleted");
} else {
    header("Location: index.php?error=deletefailed");
}
$stmt->close();
$conn->close();
?>