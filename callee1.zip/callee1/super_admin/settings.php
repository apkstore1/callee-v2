<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}

include '../db_connect.php';

$message = '';
$msg_type = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $call_rate = $_POST['call_rate'];
    $sms_rate = $_POST['sms_rate'];

    if (is_numeric($call_rate) && is_numeric($sms_rate)) {
        // Update Call Rate
        $stmt1 = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'call_rate_per_minute'");
        $stmt1->bind_param("s", $call_rate);
        $stmt1->execute();

        // Update SMS Rate
        $stmt2 = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'sms_rate_per_segment'");
        $stmt2->bind_param("s", $sms_rate);
        $stmt2->execute();

        $message = "System rates updated successfully!";
        $msg_type = "success";
    } else {
        $message = "Please enter valid numeric values.";
        $msg_type = "error";
    }
}

// Fetch Current Settings
$settings = [];
$res = $conn->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$active_menu = 'settings';
include 'header.php';
?>

<div class="content-area">
    <div class="page-header">
        <h2>System Settings</h2>
    </div>

    <?php if ($message): ?>
        <div class="alert" style="background: <?= $msg_type == 'success' ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)' ?>; color: <?= $msg_type == 'success' ? '#86efac' : '#fca5a5' ?>; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="table-container" style="max-width: 600px; padding: 30px;">
        <form action="settings.php" method="POST" class="modal-fields">
            <h3 style="margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px;">Billing Rates</h3>
            
            <div class="form-group" style="margin-bottom: 20px;">
                <label>Call Rate (Per Minute in USD)</label>
                <input type="number" name="call_rate" step="0.001" min="0" value="<?= htmlspecialchars($settings['call_rate_per_minute'] ?? '0.015') ?>" required style="width: 100%; padding: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                <small style="color: #9ca3af;">Cost deducted from admin credits for every minute of outbound call.</small>
            </div>

            <div class="form-group" style="margin-bottom: 30px;">
                <label>SMS Rate (Per Segment in USD)</label>
                <input type="number" name="sms_rate" step="0.001" min="0" value="<?= htmlspecialchars($settings['sms_rate_per_segment'] ?? '0.005') ?>" required style="width: 100%; padding: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white; border-radius: 4px;">
                <small style="color: #9ca3af;">Cost deducted for each SMS segment (approx 160 chars).</small>
            </div>

            <div class="form-footer">
                <button type="submit" class="btn-primary">Save Settings</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>