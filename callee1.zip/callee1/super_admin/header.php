<?php

// Placeholder for admin name, active calls, online agents - these would typically come from a session or database
$adminName = $_SESSION['username'] ?? 'Super Admin User'; // Assuming username is stored in session
$activeCalls = 0; // Placeholder
$onlineAgents = 0; // Placeholder

// You might want to fetch actual values for activeCalls and onlineAgents from your database or Asterisk API
// Example:
/*
require_once '../../db_connect.php'; // Adjust path
$stmt = $pdo->query("SELECT COUNT(*) FROM active_calls");
$activeCalls = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'online' AND role = 'agent'");
$onlineAgents = $stmt->fetchColumn();
*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <link rel="stylesheet" href="/callee1/assets/css/dashboard.css">
    <!-- Any other common head elements like favicons, global scripts, etc. -->
</head>
<body class="dark-theme">
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Super Admin</h2>
                <p id="adminName"><?php echo htmlspecialchars($adminName); ?></p>
            </div>
            
            <nav class="sidebar-nav">
                <a href="/callee1/super_admin/super_admin_dashboard.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'overview') ? 'active' : ''; ?>" data-page="overview">
                    <span class="icon">📊</span>
                    <span>Overview</span>
                </a>
                <a href="/callee1/super_admin/user_management.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'users') ? 'active' : ''; ?>" data-page="users">
                    <span class="icon">👥</span>
                    <span>User Management</span>
                </a>
                <a href="/callee1/super_admin/pbx.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'pbx') ? 'active' : ''; ?>" data-page="pbx">
                    <span class="icon">☎️</span>
                    <span>PBX Servers</span>
                </a>
                <a href="/callee1/super_admin/sip_carriers/index.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'sip_carriers') ? 'active' : ''; ?>" data-page="sip-carriers">
                    <span class="icon">📡</span>
                    <span>SIP Carriers</span>
                </a>
                <a href="/callee1/super_admin/manage_numbers.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'numbers') ? 'active' : ''; ?>" data-page="numbers">
                    <span class="icon">#️⃣</span>
                    <span>Manage Numbers</span>
                </a>
                <a href="/callee1/super_admin/credit_management.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'credits') ? 'active' : ''; ?>" data-page="credits">
                    <span class="icon">💳</span>
                    <span>Credit Management</span>
                </a>
                <a href="#" class="nav-item" data-page="calls">
                    <span class="icon">📞</span>
                    <span>Call Logs</span>
                </a> 
                <a href="/callee1/super_admin/campaign/" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'campaigns') ? 'active' : ''; ?>" data-page="campaigns">
                    <span class="icon">🎯</span>
                    <span>Campaigns</span>
                </a>
                <a href="#" class="nav-item" data-page="reports">
                    <span class="icon">📈</span>
                    <span>Reports</span>
                </a>
                <a href="/callee1/super_admin/settings.php" class="nav-item <?php echo (isset($active_menu) && $active_menu == 'settings') ? 'active' : ''; ?>" data-page="settings">
                    <span class="icon">⚙️</span>
                    <span>Settings</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <a href="/callee1/logout.php">
                <button class="btn-logout" onclick="logout()">
                    <span class="icon">🚪</span>
                    <span>Logout</span>
                </button>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-left">
                    <h1 id="pageTitle">Dashboard Overview</h1>
                </div>
                <div class="top-bar-right">
                    <div class="stats-badge">
                        <span class="label">Active Calls</span>
                        <span class="value" id="activeCalls"><?php echo htmlspecialchars($activeCalls); ?></span>
                    </div>
                    <div class="stats-badge">
                        <span class="label">Online Agents</span>
                        <span class="value" id="onlineAgents"><?php echo htmlspecialchars($onlineAgents); ?></span>
                    </div>
                </div>
            </header>
