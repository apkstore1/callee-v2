<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: index.php');
    exit;
}

require_once '../db_connect.php';

$active_menu = 'overview';
include 'header.php'; 

// Fetch Dashboard Stats
$total_users = 0;
$total_credits = 0.00;

// Total Users
$u_res = $conn->query("SELECT COUNT(*) as count FROM users");
if ($u_res) $total_users = $u_res->fetch_assoc()['count'];

// Total Credits
$c_res = $conn->query("SELECT SUM(credits) as total FROM users");
if ($c_res) {
    $row = $c_res->fetch_assoc();
    $total_credits = $row['total'] ?? 0.00;
}
?>
            
            <div class="content-area" id="contentArea">
                <!-- Overview Page -->
                <div id="overviewPage" class="page-content active">
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon blue">👥</div>
                            <div class="stat-info">
                                <h3>Total Users</h3>
                                <p class="stat-value" id="totalUsers"><?php echo $total_users; ?></p>
                                <span class="stat-label">All system users</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon green">📞</div>
                            <div class="stat-info">
                                <h3>Today's Calls</h3>
                                <p class="stat-value" id="todayCalls">0</p>
                                <span class="stat-label">Total calls today</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon purple">⏱️</div>
                            <div class="stat-info">
                                <h3>Call Duration</h3>
                                <p class="stat-value" id="totalDuration">0h 0m</p>
                                <span class="stat-label">Total today</span>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon orange">💰</div>
                            <div class="stat-info">
                                <h3>Total Credits</h3>
                                <p class="stat-value" id="totalCredits">$<?php echo number_format($total_credits, 2); ?></p>
                                <span class="stat-label">System-wide balance</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="charts-grid">
                        <div class="chart-card">
                            <h3>Call Activity (Last 7 Days)</h3>
                            <div id="callActivityChart" style="height: 300px;"></div>
                        </div>
                        
                        <div class="chart-card">
                            <h3>Active Campaigns</h3>
                            <div id="campaignsList" class="list-container">
                                <p class="empty-state">Loading campaigns...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Users Page -->
                <div id="usersPage" class="page-content">
                    <div class="page-header">
                        <h2>User Management</h2>
                        <button class="btn-primary" onclick="openCreateUserModal()">
                            <span>+ Add User</span>
                        </button>
                    </div>
                    
                    <div class="filters-bar">
                        <input type="text" placeholder="Search users..." class="search-input" id="userSearch" onkeyup="filterUsers()">
                        <select class="filter-select" id="roleFilter" onchange="filterUsers()">
                            <option value="">All Roles</option>
                            <option value="super_admin">Super Admin</option>
                            <option value="admin">Admin</option>
                            <option value="agent">Agent</option>
                        </select>
                        <select class="filter-select" id="statusFilter" onchange="filterUsers()">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                    
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Credits</th>
                                    <th>Last Login</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="usersTableBody">
                                <tr>
                                    <td colspan="7" class="text-center">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Asterisk Servers Page -->
                <div id="asteriskPage" class="page-content">
                    <div class="page-header">
                        <h2>Asterisk Server Management</h2>
                        <button class="btn-primary" onclick="openAddServerModal()">
                            <span>+ Add Server</span>
                        </button>
                    </div>
                    
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Server Name</th>
                                    <th>Host</th>
                                    <th>AMI Port</th>
                                    <th>Status</th>
                                    <th>Current Calls</th>
                                    <th>Max Channels</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="serversTableBody">
                                <tr>
                                    <td colspan="7" class="text-center">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- PBX Servers Page -->
                <div id="pbxPage" class="page-content">
                    <div class="page-header">
                        <h2>PBX Server Management</h2>
                        <button class="btn-primary" onclick="openAddServerModal()">
                            <span>+ Add Server</span>
                        </button>
                    </div>
                    
                    <!-- Added PBX type info cards -->
                    <div class="info-cards">
                        <div class="info-card">
                            <h4>Asterisk</h4>
                            <p>Open source PBX with AMI interface</p>
                            <span class="badge">Ports: 5038 (AMI)</span>
                        </div>
                        <div class="info-card">
                            <h4>FreePBX</h4>
                            <p>Asterisk-based with web GUI</p>
                            <span class="badge">Ports: 5038 (AMI)</span>
                        </div>
                        <div class="info-card">
                            <h4>FreeSWITCH</h4>
                            <p>Scalable platform with ESL</p>
                            <span class="badge">Ports: 8021 (ESL)</span>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Server Name</th>
                                    <th>PBX Type</th>
                                    <th>Host</th>
                                    <th>Port</th>
                                    <th>Status</th>
                                    <th>Current Calls</th>
                                    <th>Max Channels</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="serversTableBody">
                                <tr>
                                    <td colspan="8" class="text-center">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
</div>
    
    <!-- Common JavaScript files -->
    <script src="/js/dashboard.js"></script>
    <script src="/js/super-admin.js"></script>
    <!-- Any other common scripts -->
</body>
</html>
