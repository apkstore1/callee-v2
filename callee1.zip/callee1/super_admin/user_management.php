<?php
error_reporting(E_ALL); // Report all errors, warnings, and notices
ini_set('display_errors', '1'); // Display errors on the screen
ini_set('display_startup_errors', '1'); // Display startup errors
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'superadmin') {
    header('Location: ../index.php');
    exit;
}

include '../db_connect.php';

// --- MySQLi Method (Simple & Direct) ---
// Fetch admins for filter dropdown
$admins_filter_list = [];
$admin_res = mysqli_query($conn, "SELECT id, username FROM users WHERE role = 'admin'");
if ($admin_res) {
    $admins_filter_list = mysqli_fetch_all($admin_res, MYSQLI_ASSOC);
}

// Build Query based on filters
$where = [];
$role_filter = isset($_GET['role']) ? $_GET['role'] : '';
$admin_filter = isset($_GET['admin_filter']) ? $_GET['admin_filter'] : '';

if ($role_filter === 'admin') {
    $where[] = "u.role = 'admin'";
} elseif ($role_filter === 'agent') {
    $where[] = "u.role = 'agent'";
}

if (!empty($admin_filter) && is_numeric($admin_filter)) {
    $admin_id_filter = (int)$admin_filter;
    $where[] = "u.admin_id = $admin_id_filter";
}

$where_sql = count($where) > 0 ? "WHERE " . implode(' AND ', $where) : "";

$sql = "SELECT u.id, u.username, u.role, u.status, u.credits, u.custom_call_rate, u.custom_sms_rate, u.allow_auto_dial, u.allow_call, u.allow_message, u.sip_extension, u.sip_password, a.username AS admin_name 
        FROM users u 
        LEFT JOIN users a ON u.admin_id = a.id $where_sql";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error fetching users: " . mysqli_error($conn));
}

// Saare users ko array mein nikalne ke liye
$users = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Ab aap $users ko foreach loop mein use kar sakte hain
?>
<?php 
$active_menu = 'users';
include 'header.php'; ?>
            
            <style>
                .table-container {
                    overflow-x: auto;
                    white-space: nowrap; /* Prevents wrapping inside cells */
                }
            </style>

            <div class="content-area"> 
                <div id="usersPage">
                    <?php if (isset($_GET['success_msg'])) { 
                        $status = htmlspecialchars($_GET['success_msg']);
                        echo "<p style='color:green;'>$status</p>"; 
                    } ?>
                    <?php if (isset($_GET['error_msg'])) { 
                        $status = htmlspecialchars($_GET['error_msg']);
                        echo "<p style='color:red;'>$status</p>"; 
                    } ?>
                    <div class="page-header">
                        <h2>All Users</h2>
                        <a href="add_user.php">
                            <button class="btn-primary">
                                <span>+ Add User</span>
                            </button>
                        </a>
                    </div>
                    
                    <!-- Filter Section -->
                    <div class="filter-bar" style="margin-bottom: 20px; display: flex; gap: 10px; align-items: center; background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; flex-wrap: wrap;">
                        <a href="user_management.php" class="btn-secondary" style="<?= ($role_filter == '') ? 'background-color: #00d9ff; color: #000;' : '' ?>">All Users</a>
                        <a href="user_management.php?role=admin" class="btn-secondary" style="<?= ($role_filter == 'admin') ? 'background-color: #00d9ff; color: #000;' : '' ?>">Admins Only</a>
                        <a href="user_management.php?role=agent" class="btn-secondary" style="<?= ($role_filter == 'agent') ? 'background-color: #00d9ff; color: #000;' : '' ?>">Agents Only</a>
                        
                        <form action="user_management.php" method="GET" style="display: flex; gap: 10px; margin-left: auto;">
                            <?php if($role_filter): ?><input type="hidden" name="role" value="<?= htmlspecialchars($role_filter) ?>"><?php endif; ?>
                            <select name="admin_filter" onchange="this.form.submit()" style="padding: 8px; border-radius: 4px; background: rgba(255, 255, 255, 0.1); color: white; border: 1px solid rgba(255, 255, 255, 0.2);">
                                <option value="" style="color: black;">-- Filter by Admin --</option>
                                <?php foreach ($admins_filter_list as $adm): ?>
                                    <option value="<?= $adm['id'] ?>" <?= ($admin_filter == $adm['id']) ? 'selected' : '' ?> style="color: black;"><?= htmlspecialchars($adm['username']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </div>

                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Credits</th>
                                    <th>Call Rate ($)</th>
                                    <th>SMS Rate ($)</th>
                                    <th>SIP Ext</th>
                                    <th>SIP Pass</th>
                                    <th>Allow Auto-Dial</th>
                                    <th>Allow Call</th>
                                    <th>Allow Message</th>
                                    <th>Assigned Admin</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="usersTableBody">
                                <?php if (!empty($users)): ?>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($user['id']) ?></td>
                                            <td><?= htmlspecialchars($user['username']) ?></td>
                                            <td><?= htmlspecialchars($user['role']) ?></td>
                                            <td><?= htmlspecialchars($user['status']) ?></td>
                                            <td><?= htmlspecialchars($user['credits']) ?></td>
                                            <td>
                                                <form action="update_permission.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <input type="hidden" name="perm_type" value="custom_call_rate">
                                                    <input type="number" step="0.0001" name="custom_call_rate" value="<?= htmlspecialchars($user['custom_call_rate'] ?? '') ?>" placeholder="Default" style="width: 70px; padding: 5px; border-radius: 4px; border: 1px solid #ccc; color: black;" onchange="this.form.submit()">
                                                </form>
                                            </td>
                                            <td>
                                                <form action="update_permission.php" method="POST">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <input type="hidden" name="perm_type" value="custom_sms_rate">
                                                    <input type="number" step="0.0001" name="custom_sms_rate" value="<?= htmlspecialchars($user['custom_sms_rate'] ?? '') ?>" placeholder="Default" style="width: 70px; padding: 5px; border-radius: 4px; border: 1px solid #ccc; color: black;" onchange="this.form.submit()">
                                                </form>
                                            </td>
                                            <td><?= htmlspecialchars($user['sip_extension'] ?? '') ?></td>
                                            <td><?= htmlspecialchars($user['sip_password'] ?? '') ?></td>
                                            <td>
                                                <form action="update_permission.php" method="POST" class="permission-form">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <input type="hidden" name="perm_type" value="allow_auto_dial">
                                                    <label class="switch">
                                                        <input type="checkbox" name="allow_auto_dial" <?= ($user['allow_auto_dial'] ? 'checked' : '') ?> onchange="this.form.submit()">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </form>
                                            </td>
                                            <td>
                                                <form action="update_permission.php" method="POST" class="permission-form">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <input type="hidden" name="perm_type" value="allow_call">
                                                    <label class="switch">
                                                        <input type="checkbox" name="allow_call" <?= ($user['allow_call'] ? 'checked' : '') ?> onchange="this.form.submit()">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </form>
                                            </td>
                                            <td>
                                                <form action="update_permission.php" method="POST" class="permission-form">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <input type="hidden" name="perm_type" value="allow_message">
                                                    <label class="switch">
                                                        <input type="checkbox" name="allow_message" <?= ($user['allow_message'] ? 'checked' : '') ?> onchange="this.form.submit()">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </form>
                                            </td>
                                            <td><?= htmlspecialchars($user['admin_name'] ?? 'N/A') ?></td>
                                            <td>
                                                <a class='btn btn-secondary btn-sm' href='edit_user.php?id=<?= $user["id"] ?>' style="margin-right: 5px;">Edit</a>
                                                <a class='btn btn-danger btn-sm' href='delete_user.php?id=<?= $user["id"] ?>' onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="10" style="text-align: center;">No users found</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
<?php include 'footer.php'; ?>
</main>
    </div>
    
    <!-- Common JavaScript files -->
    <script src="/js/dashboard.js"></script>
    <script src="/js/super-admin.js"></script>
    <!-- Any other common scripts -->
</body>
</html>