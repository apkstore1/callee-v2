<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/api/telnyx_config.php'; 

// 1. Credential ID (SIP Connection ID provided by user)
$credential_id = "2880157907012290296";

// 2. Telnyx official endpoint for Telephony Credentials Token
$url = "https://api.telnyx.com/v2/telephony_credentials/{$credential_id}/token";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{}"); // Empty JSON object is safer
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . TELNYX_API_KEY,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code === 201 || $http_code === 200) {
    // The response is the raw JWT token string
    $token = trim($response);
    
    echo json_encode([
        "success" => true,
        "token" => $token,
        "sip_username" => "agent_" . ($_SESSION['user_id'] ?? 'default')
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Telnyx rejected token request (HTTP $http_code)",
        "debug" => $response
    ]);
}