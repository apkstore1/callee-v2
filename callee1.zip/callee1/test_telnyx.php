<?php
//$api_key = "KEY019BE7310177A2176B6E0A6C00357FD6_X7xDVsmIrF7ceqLFQ76sgY";
//$app_id = "2878459127405741445"; // Tumhari App ID

$api_key = "KEY019BE7310177A2176B6E0A6C00357FD6_X7xDVsmIrF7ceqLFQ76sgY"; // Apni API Key dalo

$ch = curl_init();
// Yeh endpoint aapke saare 'Connections' (Voice API Apps) ki list nikalega
curl_setopt($ch, CURLOPT_URL, 'https://api.telnyx.com/v2/telephony_credentials'); 
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $api_key,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode == 200) {
    echo "<h3>✓ Sahi IDs Mil Gayin!</h3>";
    $data = json_decode($response, true);
    echo "<pre>";
    print_r($data); 
    echo "</pre>";
} else {
    echo "<h3>✗ Error (HTTP $httpCode)</h3>";
    echo "Response: " . $response;
}
?>
