<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'agent') {
    header('Location: index.php');
    exit;
}
$active_menu = 'history';
include 'header.php';

// Fetch Call History for the logged-in agent
$agent_id = $_SESSION['user_id'];
$history = [];

// Query to fetch calls (Latest first)
$sql = "SELECT * FROM call_logs WHERE user_id = ? ORDER BY start_time DESC LIMIT 100";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $agent_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result) {
    $history = $result->fetch_all(MYSQLI_ASSOC);
}
$stmt->close();
?>

<div class="page-content active" style="display: block;">
    <div class="page-header">
        <h1>Call History</h1>
        <div class="filters-bar">
            <!-- Simple filter example -->
            <select class="filter-select" onchange="filterHistory(this.value)">
                <option value="all">All Calls</option>
                <option value="answered">Answered</option>
                <option value="no_answer">No Answer</option>
                <option value="failed">Failed</option>
            </select>
        </div>
    </div>

    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>Phone Number</th>
                    <th>Direction</th>
                    <th>Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody id="historyTableBody">
                <?php if (!empty($history)): ?>
                    <?php foreach ($history as $call): ?>
                        <tr class="history-row" data-status="<?= htmlspecialchars($call['status']) ?>">
                            <td><?= date('M d, Y h:i A', strtotime($call['start_time'])) ?></td>
                            <td><?= htmlspecialchars($call['phone_number']) ?></td>
                            <td>
                                <span class="role-badge" style="background: <?= $call['direction'] == 'outbound' ? 'rgba(59, 130, 246, 0.1)' : 'rgba(16, 185, 129, 0.1)' ?>; color: <?= $call['direction'] == 'outbound' ? '#60a5fa' : '#34d399' ?>;">
                                    <?= ucfirst($call['direction']) ?>
                                </span>
                            </td>
                            <td><?= gmdate("H:i:s", $call['duration']) ?></td>
                            <td>
                                <?php 
                                    $statusColor = 'gray';
                                    if(in_array($call['status'], ['answered', 'completed'])) $statusColor = 'success';
                                    elseif(in_array($call['status'], ['busy', 'failed'])) $statusColor = 'danger';
                                    elseif(in_array($call['status'], ['no_answer', 'canceled'])) $statusColor = 'warning';
                                    elseif($call['status'] == 'ringing') $statusColor = 'info';
                                ?>
                                <span class="status-badge status-<?= $statusColor ?>"><?= ucfirst(str_replace('_', ' ', $call['status'])) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">No call history found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function filterHistory(status) {
    const rows = document.querySelectorAll('.history-row');
    rows.forEach(row => {
        if (status === 'all' || row.dataset.status === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>

<?php include 'footer.php'; ?>