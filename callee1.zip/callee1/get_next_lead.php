<?php
session_start();
// Disable error display to prevent JSON breakage
ini_set('display_errors', 0);
require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$agent_id = $_SESSION['user_id'];

// 1. Check Auto Dial Permission (From Agent's Admin)
$perm_stmt = $conn->prepare("
    SELECT a.allow_auto_dial 
    FROM users u 
    LEFT JOIN users a ON u.admin_id = a.id 
    WHERE u.id = ?
");
$perm_stmt->bind_param("i", $agent_id);
$perm_stmt->execute();
$perm_res = $perm_stmt->get_result()->fetch_assoc();

if (empty($perm_res['allow_auto_dial']) || $perm_res['allow_auto_dial'] == 0) {
    echo json_encode(['success' => false, 'message' => 'Auto-dialing is disabled. Please use the manual dialer.']);
    exit;
}

// Get Agent's Admin ID
$admin_stmt = $conn->prepare("SELECT admin_id FROM users WHERE id = ?");
$admin_stmt->bind_param("i", $agent_id);
$admin_stmt->execute();
$admin_row = $admin_stmt->get_result()->fetch_assoc();
$admin_id = $admin_row['admin_id'] ?? null;

if ($admin_id) {
    // Find a random lead from active campaigns belonging to this Admin
    // Statuses: pending, callback, no_answer, voicemail, new
    $pool_sql = "
        SELECT l.* 
        FROM leads l
        JOIN campaigns c ON l.campaign_id = c.id
        WHERE c.admin_id = ? 
        AND c.status = 'active'
        AND l.status IN ('new', 'pending', 'no_answer', 'callback', 'voicemail')
        ORDER BY RAND()
        LIMIT 1
    ";
    
    $pool_stmt = $conn->prepare($pool_sql);
    $pool_stmt->bind_param("i", $admin_id);
    $pool_stmt->execute();
    $pool_res = $pool_stmt->get_result();
    
    if ($pool_res->num_rows > 0) {
        echo json_encode(['success' => true, 'data' => $pool_res->fetch_assoc()]);
    } else {
        echo json_encode(['success' => true, 'data' => null, 'message' => 'No leads available in pool']);
    }
} else {
    echo json_encode(['success' => true, 'data' => null, 'message' => 'Agent not linked to Admin']);
}
?>