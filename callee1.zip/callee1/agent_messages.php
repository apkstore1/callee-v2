<?php
$active_menu = 'messages';
include 'header.php';

// Permission Check
if (!$can_message) {
    echo '<div style="display:flex; justify-content:center; align-items:center; height:calc(100vh - 140px); flex-direction:column; color:#9ca3af;">
            <div style="font-size:60px; margin-bottom:20px;">🔒</div>
            <h2 style="color:white;">Messaging Access Restricted</h2>
            <p>You do not have permission to access messaging.</p>
          </div>';
    include 'footer.php';
    exit;
}
?>

<style>
    /* Chat Layout Styles */
    .messaging-container {
        display: flex;
        height: calc(100vh - 140px); /* Adjust based on header/footer */
        background: #1f2937;
        border-radius: 12px;
        overflow: hidden;
        margin: 20px;
        border: 1px solid #374151;
    }

    /* Sidebar (Conversations) */
    .conversations-sidebar {
        width: 320px;
        background: #111827;
        border-right: 1px solid #374151;
        display: flex;
        flex-direction: column;
    }

    .sidebar-header {
        padding: 15px;
        border-bottom: 1px solid #374151;
    }

    .new-msg-btn {
        width: 100%;
        padding: 10px;
        background: #3b82f6;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
    }

    .conversations-list {
        flex: 1;
        overflow-y: auto;
    }

    .conversation-item {
        padding: 15px;
        border-bottom: 1px solid #374151;
        cursor: pointer;
        transition: background 0.2s;
    }

    .conversation-item:hover, .conversation-item.active {
        background: #374151;
    }

    .contact-number {
        font-weight: bold;
        color: #f3f4f6;
        display: block;
    }

    .last-message {
        font-size: 12px;
        color: #9ca3af;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        display: block;
        margin-top: 4px;
    }

    /* Chat Area */
    .chat-area {
        flex: 1;
        display: flex;
        flex-direction: column;
        background: #1f2937;
    }

    .chat-header {
        padding: 15px;
        background: #111827;
        border-bottom: 1px solid #374151;
        display: flex;
        align-items: center;
    }

    .chat-header h3 {
        margin: 0;
        color: white;
    }

    .messages-box {
        flex: 1;
        padding: 20px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .message-bubble {
        max-width: 70%;
        padding: 10px 15px;
        border-radius: 12px;
        position: relative;
        font-size: 14px;
        line-height: 1.4;
    }

    .message-bubble.outbound {
        align-self: flex-end;
        background: #3b82f6;
        color: white;
        border-bottom-right-radius: 2px;
    }

    .message-bubble.inbound {
        align-self: flex-start;
        background: #374151;
        color: #e5e7eb;
        border-bottom-left-radius: 2px;
    }

    .msg-time {
        font-size: 10px;
        opacity: 0.7;
        margin-top: 5px;
        display: block;
        text-align: right;
    }

    /* Input Area */
    .input-area {
        padding: 15px;
        background: #111827;
        border-top: 1px solid #374151;
    }

    .input-wrapper {
        display: flex;
        gap: 10px;
    }

    textarea {
        flex: 1;
        background: #374151;
        border: 1px solid #4b5563;
        color: white;
        border-radius: 8px;
        padding: 10px;
        resize: none;
        height: 50px;
    }

    .send-btn {
        background: #10b981;
        color: white;
        border: none;
        padding: 0 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
    }

    .char-counter {
        font-size: 12px;
        color: #9ca3af;
        margin-top: 5px;
        text-align: right;
    }
    
    .empty-state {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        color: #6b7280;
        font-size: 18px;
    }
</style>

<div class="messaging-container">
    <!-- Sidebar -->
    <div class="conversations-sidebar">
        <div class="sidebar-header">
            <button class="new-msg-btn" onclick="startNewChat()">+ New Message</button>
        </div>
        <div class="conversations-list" id="conversationsList">
            <!-- Conversations will be loaded here -->
            <div style="padding:20px; text-align:center; color:#6b7280;">Loading...</div>
        </div>
    </div>

    <!-- Chat Area -->
    <div class="chat-area">
        <div class="chat-header" id="chatHeader" style="display:none;">
            <div style="background:#3b82f6; width:35px; height:35px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin-right:10px;">👤</div>
            <h3 id="chatContactName">Select a contact</h3>
        </div>

        <div class="messages-box" id="messagesBox">
            <div class="empty-state">Select a conversation to start chatting</div>
        </div>

        <div class="input-area" id="inputArea" style="display:none;">
            <div class="input-wrapper">
                <textarea id="messageInput" placeholder="Type a message..." oninput="updateCharCount()"></textarea>
                <button class="send-btn" onclick="sendMessage()">Send</button>
            </div>
            <div class="char-counter">
                <span id="charCount">0</span>/160 characters (<span id="segmentCount">1</span> SMS) | Cost: $<span id="costPreview">0.00</span>
            </div>
        </div>
    </div>
</div>

<script>
    let currentContact = null;
    const SMS_RATE = <?php echo defined('SMS_RATE_PER_SEGMENT') ? SMS_RATE_PER_SEGMENT : 0.005; ?>;

    document.addEventListener('DOMContentLoaded', () => {
        loadConversations();
    });

    function loadConversations() {
        fetch('api/sms/get_conversations.php')
            .then(res => res.json())
            .then(data => {
                const list = document.getElementById('conversationsList');
                list.innerHTML = '';
                if(data.success && data.data.length > 0) {
                    data.data.forEach(conv => {
                        const div = document.createElement('div');
                        div.className = `conversation-item ${currentContact === conv.contact_number ? 'active' : ''}`;
                        div.onclick = () => openChat(conv.contact_number);
                        div.innerHTML = `
                            <span class="contact-number">${conv.contact_number}</span>
                            <span class="last-message">${conv.last_direction === 'outbound' ? 'You: ' : ''}${conv.last_message}</span>
                        `;
                        list.appendChild(div);
                    });
                } else {
                    list.innerHTML = '<div style="padding:20px; text-align:center; color:#6b7280;">No conversations yet</div>';
                }
            });
    }

    function openChat(number) {
        currentContact = number;
        document.getElementById('chatHeader').style.display = 'flex';
        document.getElementById('inputArea').style.display = 'block';
        document.getElementById('chatContactName').textContent = number;
        
        // Highlight active
        document.querySelectorAll('.conversation-item').forEach(el => el.classList.remove('active'));
        // (Optional: Add active class logic here if re-rendering list)

        fetch(`api/sms/get_messages.php?number=${encodeURIComponent(number)}`)
            .then(res => res.json())
            .then(data => {
                const box = document.getElementById('messagesBox');
                box.innerHTML = '';
                if(data.success) {
                    data.data.forEach(msg => {
                        const bubble = document.createElement('div');
                        bubble.className = `message-bubble ${msg.direction}`;
                        bubble.innerHTML = `
                            ${msg.body}
                            <span class="msg-time">${new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        `;
                        box.appendChild(bubble);
                    });
                    box.scrollTop = box.scrollHeight; // Scroll to bottom
                }
            });
    }

    function startNewChat() {
        const number = prompt("Enter phone number (e.g., +1234567890):");
        if(number) {
            openChat(number);
        }
    }

    function updateCharCount() {
        const text = document.getElementById('messageInput').value;
        const len = text.length;
        const segments = Math.ceil(len / 160) || 1;
        const cost = (segments * SMS_RATE).toFixed(4);

        document.getElementById('charCount').textContent = len;
        document.getElementById('segmentCount').textContent = segments;
        document.getElementById('costPreview').textContent = cost;
    }

    function sendMessage() {
        const text = document.getElementById('messageInput').value;
        if(!text.trim() || !currentContact) return;

        const btn = document.querySelector('.send-btn');
        btn.disabled = true;
        btn.textContent = 'Sending...';

        fetch('api/sms/send_sms.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                to_number: currentContact,
                message: text
            })
        })
        .then(res => res.json())
        .then(data => {
            btn.disabled = false;
            btn.textContent = 'Send';
            
            if(data.success) {
                document.getElementById('messageInput').value = '';
                updateCharCount();
                openChat(currentContact); // Refresh chat
                loadConversations(); // Refresh sidebar
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            btn.disabled = false;
            alert('Failed to send message');
        });
    }
</script>

<?php include 'footer.php'; ?>