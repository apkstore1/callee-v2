<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'agent') {
    header('Location: index.php');
    exit;
}
$active_menu = 'messages';
include 'header.php';
?>

<div class="page-content active" id="messagesPage" style="display: block;">
    <div class="page-header">
        <h1>Messages</h1>
        <?php if (!$can_message): ?>
            <div class="locked-badge" style="background:#ef4444; padding:5px 10px; border-radius:4px; font-size:12px;">Disabled</div>
        <?php else: ?>
        <button class="btn-primary" onclick="openNewMessageModal()">
            <span>+ New Message</span>
        </button>
        <?php endif; ?>
    </div>

    <div class="messages-container" style="position: relative;">
        <?php if (!$can_message): ?>
        <div class="locked-overlay" style="position:absolute; top:0; left:0; width:100%; height:100%; background:rgba(15, 15, 30, 0.9); z-index:10; display:flex; flex-direction:column; justify-content:center; align-items:center;">
            <div style="font-size: 40px;">🔒</div>
            <h3 style="color: #ef4444; margin-top: 10px;">Messaging Locked</h3>
            <p style="color: #9ca3af;">Messaging disabled by administrator.</p>
        </div>
        <?php endif; ?>

        <div class="message-list" id="messageList">
            <!-- Example message thread -->
            <div class="message-thread">
                <div class="message-header">
                    <div class="contact-avatar" style="width: 40px; height: 40px; background: #e0e0e0; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 10px;">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                    <div class="contact-info">
                        <span class="contact-name">John Doe</span>
                        <span class="message-time">Today 10:30 AM</span>
                    </div>
                </div>
                <div class="message-content">
                    <p>Hello, how can I help you today?</p>
                </div>
            </div>
            
            <!-- Add more message threads here -->
            
            <div class="empty-state">No messages</div>
        </div>
    </div>
</div>

<script>
    function openNewMessageModal() {
        alert('New message modal will be implemented');
    }
</script>

<?php include 'footer.php'; ?>