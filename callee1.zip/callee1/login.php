<?php
    include('db_connect.php');
session_start();

    if (isset($_POST['submit'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role = $_POST['role'];

        // Wahi simple query jese aapne dikhayi
        $sql = "select * from users where username = '$username' and password = '$password' and role = '$role'";  
        $result = mysqli_query($conn, $sql);  
        $user = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result); 

        if($count == 1){  
            // Session mein data save karna (Dashboard ke liye)
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_username'] = $user['username'];
            $_SESSION['allow_auto_dial'] = $user['allow_auto_dial']; // Save permission in session

            // Role check karke redirect karna
            if($user['role'] == 'admin'){
                header("Location: admin/admin_dashboard.php");
            } 
            else if($user['role'] == 'agent'){
                header("Location: agent_dashboard.php");
            }
            else if($user['role'] == 'superadmin'){
                header("Location: super_admin/super_admin_dashboard.php");
            }
            exit;
        }  
        else{  
           // JavaScript alert ki jagah PHP redirect error message ke sath
            header("Location: index.php?error=Invalid email or password!");
            exit;
        }     
    }
?>