-- This is a temporary file to show the required database schema changes for the credit management system.
-- You should apply these changes to your 'users' table.

-- Add a 'credits' column to store the credit balance for admin and superadmin users.
ALTER TABLE `users`
ADD COLUMN `credits` DECIMAL(10, 2) NOT NULL DEFAULT 0.00 AFTER `role`;

-- Add an 'admin_id' column to link agents to their respective admin.
-- This will be a foreign key referencing the 'id' of another user (the admin).
ALTER TABLE `users`
ADD COLUMN `admin_id` INT(11) NULL DEFAULT NULL AFTER `credits`,
ADD CONSTRAINT `fk_agent_admin` FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- Note: You might want to add an index on the new admin_id column for better performance.
ALTER TABLE `users` ADD INDEX `idx_admin_id` (`admin_id`);
