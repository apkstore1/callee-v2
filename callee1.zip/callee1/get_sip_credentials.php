<?php
session_start();
require_once 'db_connect.php'; // Database connection add kiya
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Database se Agent ka Extension aur Password uthao
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT sip_extension, sip_password FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (empty($user['sip_extension'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'SIP Extension not assigned to this user. Please contact admin.']);
    exit;
}

$portal_sip_username = $user['sip_extension'];
$portal_sip_password = $user['sip_password'];

echo json_encode([
    'success' => true,
    'username' => $portal_sip_username,
    'password' => $portal_sip_password
]);
?>
