<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$agent_id = $_SESSION['user_id'];
$status = $_GET['status'] ?? '';

$sql = "SELECT * FROM leads WHERE assigned_to = ? " . ($status ? "AND status = ?" : "") . " ORDER BY created_at DESC LIMIT 50";
$stmt = $conn->prepare($sql);
if ($status) $stmt->bind_param("is", $agent_id, $status);
else $stmt->bind_param("i", $agent_id);
$stmt->execute();
echo json_encode(['success' => true, 'data' => $stmt->get_result()->fetch_all(MYSQLI_ASSOC)]);
?>