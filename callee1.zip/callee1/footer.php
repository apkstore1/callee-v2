        </main>
    </div>

<?php
// Calculate Base URL dynamically
$projectDir = str_replace('\\', '/', __DIR__);
$docRoot = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$baseUrl = str_replace($docRoot, '', $projectDir);
?>
    <!-- Hidden Audio Element for WebRTC (Crucial for Audio Playback) -->
    <audio id="remoteAudio" autoplay style="position:fixed; top:-100px; opacity:0;"></audio>

    <script>window.APP_BASE_URL = "<?php echo $baseUrl; ?>";</script>

    <!-- SIP.js Library for Direct SIP Trunking -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sip.js/0.20.0/sip.min.js"></script>
    <script src="<?php echo $baseUrl; ?>/assets/js/webrtc-client.js"></script>
    <script src="<?php echo $baseUrl; ?>/assets/js/dialer.js"></script>
    <!-- Agent specific scripts -->
    <script src="<?php echo $baseUrl; ?>/assets/js/agent.js"></script>
</body>
</html>