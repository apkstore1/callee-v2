        </main>
    </div>
    
    <!-- SIP.js Library for Direct SIP Trunking -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sip.js/0.20.0/sip.min.js"></script>
    <script src="/callee1/assets/js/webrtc-client.js"></script>
    <script src="/callee1/assets/js/dialer.js"></script>
    <!-- Agent specific scripts -->
    <script src="/callee1/assets/js/agent.js"></script>
</body>
</html>