<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'agent') {
    header('Location: index.php');
    exit;
}
$active_menu = 'leads';
include 'header.php';

// Fetch leads directly from database
$query = "SELECT l.id, l.campaign_id, l.phone_number, l.status, l.created_at, c.name as campaign_name 
          FROM leads l 
          LEFT JOIN campaigns c ON l.campaign_id = c.id 
          ORDER BY l.created_at DESC LIMIT 100";
$result = $conn->query($query);
?>

<div class="page-content active" style="display: block;">
    <div class="page-header">
        <h1>My Leads</h1>
        <div class="filters-bar">
            <select class="filter-select" id="leadStatusFilter" onchange="filterMyLeads()">
                <option value="">All Status</option>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="converted">Converted</option>
            </select>
        </div>
    </div>
    
    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Campaign</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="myLeadsTableBody">
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['phone_number']); ?></td>
                            <td><span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['campaign_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                            <td>
                                <button class="action-btn" onclick="loadLeadToDialer(<?php echo $row['id']; ?>)">Call</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No leads found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
</script>

<?php include 'footer.php'; ?>