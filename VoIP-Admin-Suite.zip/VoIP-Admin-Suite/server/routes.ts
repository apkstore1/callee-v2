import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.config.get.path, async (req, res) => {
    try {
      const config = await storage.getConfig();
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to load config" });
    }
  });

  app.put(api.config.update.path, async (req, res) => {
    try {
      const input = api.config.update.input.parse(req.body);
      const updatedConfig = await storage.updateConfig(input);
      res.json(updatedConfig);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to update config" });
    }
  });

  app.post(api.registration.submit.path, async (req, res) => {
    try {
      const input = api.registration.submit.input.parse(req.body);
      const config = await storage.getConfig();
      
      const recipientEmail = config.emailSettings.recipientEmail;
      
      // In a real application, you would use a service like SendGrid, Mailgun, or Nodemailer here.
      // Since we don't have an SMTP server configured, we will log the email that would be sent.
      console.log(`[EMAIL MOCK] Sending lead info to ${recipientEmail}`);
      console.log(`[EMAIL MOCK] Subject: New Lead from ${input.name}`);
      console.log(`[EMAIL MOCK] Body: 
        Name: ${input.name}
        Email: ${input.email}
        Phone: ${input.phone}
        Company: ${input.company || 'N/A'}
        Message: ${input.message || 'N/A'}
      `);

      res.status(200).json({ success: true, message: "Registration successful. We will contact you soon." });
    } catch (error) {
       if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to submit registration" });
    }
  });

  return httpServer;
}
