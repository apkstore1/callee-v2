import { promises as fs } from "fs";
import path from "path";
import { type SiteConfig } from "@shared/schema";

export interface IStorage {
  getConfig(): Promise<SiteConfig>;
  updateConfig(config: SiteConfig): Promise<SiteConfig>;
}

const CONFIG_PATH = path.join(process.cwd(), "config.json");

const DEFAULT_CONFIG: SiteConfig = {
  theme: {
    primaryColor: "#FF8C00",
    secondaryColor: "#000080",
  },
  hero: {
    title: "Calleey VoIP Dialer",
    subtitle: "High-Performance Communications for Modern Teams",
    ctaText: "Get Started",
    portalUrl: "https://portal.calleey.com",
  },
  navbar: {
    logoText: "Calleey",
    links: [
      { label: "Features", href: "#features" },
      { label: "Pricing", href: "#pricing" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  footer: {
    copyrightText: "Calleey VoIP Dialer. All rights reserved.",
    links: [
      { label: "Features", href: "#features" },
      { label: "Pricing", href: "#pricing" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  features: [
    {
      id: "1",
      title: "Crystal Clear Voice",
      description: "Experience HD audio quality on every call.",
      icon: "Phone"
    },
    {
      id: "2",
      title: "Global Coverage",
      description: "Connect with anyone, anywhere in the world seamlessly.",
      icon: "Globe"
    }
  ],
  pricing: [
    {
      id: "basic",
      name: "Basic Plan",
      price: "$9.99/mo",
      features: ["Up to 1000 minutes", "Basic Support", "1 User"]
    },
    {
      id: "pro",
      name: "Pro Plan",
      price: "$29.99/mo",
      features: ["Unlimited minutes", "Priority Support", "5 Users"]
    }
  ],
  faq: [
    {
      question: "How do I get started?",
      answer: "Simply choose a plan and register to access your portal."
    }
  ],
  customPages: [],
  emailSettings: {
    recipientEmail: "Muhammad.mushariq.waada@gmail.com",
  },
  whatsappNumber: "923328248163"
};

export class JsonStorage implements IStorage {
  private async ensureConfigExists() {
    try {
      await fs.access(CONFIG_PATH);
    } catch {
      await fs.writeFile(CONFIG_PATH, JSON.stringify(DEFAULT_CONFIG, null, 2));
    }
  }

  async getConfig(): Promise<SiteConfig> {
    await this.ensureConfigExists();
    const data = await fs.readFile(CONFIG_PATH, "utf-8");
    const config = JSON.parse(data);
    
    // Deep merge with defaults to ensure all required fields exist
    return {
      ...DEFAULT_CONFIG,
      ...config,
      theme: { ...DEFAULT_CONFIG.theme, ...config.theme },
      hero: { ...DEFAULT_CONFIG.hero, ...config.hero },
      navbar: { ...DEFAULT_CONFIG.navbar, ...config.navbar },
      footer: { ...DEFAULT_CONFIG.footer, ...config.footer },
      emailSettings: { ...DEFAULT_CONFIG.emailSettings, ...config.emailSettings },
      customPages: config.customPages || DEFAULT_CONFIG.customPages,
      features: config.features || DEFAULT_CONFIG.features,
      pricing: config.pricing || DEFAULT_CONFIG.pricing,
      faq: config.faq || DEFAULT_CONFIG.faq,
    };
  }

  async updateConfig(config: SiteConfig): Promise<SiteConfig> {
    await fs.writeFile(CONFIG_PATH, JSON.stringify(config, null, 2));
    return config;
  }
}

export const storage = new JsonStorage();
