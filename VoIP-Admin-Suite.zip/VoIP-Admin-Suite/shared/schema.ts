import { z } from "zod";

export const featureSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  icon: z.string().optional(),
});

export const pricingPackageSchema = z.object({
  id: z.string(),
  name: z.string(),
  price: z.string(),
  features: z.array(z.string()),
});

export const faqSchema = z.object({
  question: z.string(),
  answer: z.string(),
});

export const customPageSchema = z.object({
  id: z.string(),
  slug: z.string().min(1, "Slug is required"),
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
});

export const navLinkSchema = z.object({
  label: z.string(),
  href: z.string(),
});

export const siteConfigSchema = z.object({
  theme: z.object({
    primaryColor: z.string(),
    secondaryColor: z.string(),
  }),
  hero: z.object({
    title: z.string(),
    subtitle: z.string(),
    ctaText: z.string(),
    portalUrl: z.string(),
  }),
  navbar: z.object({
    logoText: z.string(),
    links: z.array(navLinkSchema),
  }),
  footer: z.object({
    copyrightText: z.string(),
    links: z.array(navLinkSchema),
  }),
  features: z.array(featureSchema),
  pricing: z.array(pricingPackageSchema),
  faq: z.array(faqSchema),
  customPages: z.array(customPageSchema),
  emailSettings: z.object({
    recipientEmail: z.string(),
  }),
  whatsappNumber: z.string(),
});

export type Feature = z.infer<typeof featureSchema>;
export type PricingPackage = z.infer<typeof pricingPackageSchema>;
export type Faq = z.infer<typeof faqSchema>;
export type CustomPage = z.infer<typeof customPageSchema>;
export type NavLink = z.infer<typeof navLinkSchema>;
export type SiteConfig = z.infer<typeof siteConfigSchema>;

export const registrationFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email"),
  phone: z.string().min(1, "Phone is required"),
  company: z.string().optional(),
  message: z.string().optional(),
});

export type RegistrationForm = z.infer<typeof registrationFormSchema>;
