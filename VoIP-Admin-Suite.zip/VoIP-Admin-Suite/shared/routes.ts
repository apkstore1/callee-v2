import { z } from 'zod';
import { siteConfigSchema, registrationFormSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  config: {
    get: {
      method: 'GET' as const,
      path: '/api/config' as const,
      responses: {
        200: siteConfigSchema,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/config' as const,
      input: siteConfigSchema,
      responses: {
        200: siteConfigSchema,
        400: errorSchemas.validation,
      },
    },
  },
  registration: {
    submit: {
      method: 'POST' as const,
      path: '/api/register' as const,
      input: registrationFormSchema,
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
        400: errorSchemas.validation,
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type RegistrationInput = z.infer<typeof api.registration.submit.input>;
export type ConfigInput = z.infer<typeof api.config.update.input>;
