## Project Progress

- [x] Initial setup with React, Node, and Express.
- [x] No-database architecture using `config.json`.
- [x] Admin Dashboard for real-time site updates.
- [x] High-tech SaaS Landing Page with Framer Motion.
- [x] Admin Authentication (`admin` / `1997mushariq`).
- [x] Custom Page Creation & Dynamic Routing.
- [x] Customizable Navbar, Footer, and Copyright settings.

## Features
- **Dynamic Theming**: Primary and secondary colors editable via color picker.
- **Content Management**: All text, features, pricing, and FAQs are editable.
- **Lead Generation**: Registration form that logs submissions (mocked email).
- **WhatsApp Integration**: Dynamic links based on package selection.
- **Admin Panel**: Protected dashboard for site management.
- **Custom Pages**: Create unlimited static pages with custom slugs.
