import { useEffect, useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link } from "wouter";
import { siteConfigSchema, type SiteConfig } from "@shared/schema";
import { useConfig, useUpdateConfig } from "@/hooks/use-config";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Save, Plus, Trash2, Loader2, Settings, Lock, Layout, List, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const { data: config, isLoading } = useConfig();
  const { mutate: updateConfig, isPending } = useUpdateConfig();
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const form = useForm<SiteConfig>({
    resolver: zodResolver(siteConfigSchema),
    defaultValues: config || undefined,
  });

  useEffect(() => {
    if (config) {
      form.reset(config);
    }
  }, [config, form]);

  const { fields: featureFields, append: appendFeature, remove: removeFeature } = useFieldArray({
    control: form.control,
    name: "features",
  });

  const { fields: pricingFields, append: appendPricing, remove: removePricing } = useFieldArray({
    control: form.control,
    name: "pricing",
  });

  const { fields: faqFields, append: appendFaq, remove: removeFaq } = useFieldArray({
    control: form.control,
    name: "faq",
  });

  const { fields: customPageFields, append: appendCustomPage, remove: removeCustomPage } = useFieldArray({
    control: form.control,
    name: "customPages",
  });

  const { fields: navLinkFields, append: appendNavLink, remove: removeNavLink } = useFieldArray({
    control: form.control,
    name: "navbar.links",
  });

  const { fields: footerLinkFields, append: appendFooterLink, remove: removeFooterLink } = useFieldArray({
    control: form.control,
    name: "footer.links",
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === "admin" && password === "1997mushariq") {
      setIsAuthenticated(true);
      toast({ title: "Welcome admin!", description: "Successfully logged into dashboard." });
    } else {
      toast({ title: "Authentication failed", description: "Invalid username or password.", variant: "destructive" });
    }
  };

  const onSubmit = (data: SiteConfig) => {
    updateConfig(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-card border-white/10">
          <CardHeader className="text-center">
            <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Lock className="w-6 h-6 text-primary" />
            </div>
            <CardTitle className="text-2xl font-display font-bold text-white">Admin Login</CardTitle>
            <CardDescription>Enter your credentials to access the dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input 
                  id="username" 
                  value={username} 
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-background/50 border-white/10"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-background/50 border-white/10"
                />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                Login
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-muted-foreground hover:text-white transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                <Settings className="w-4 h-4 text-primary" />
              </div>
              <h1 className="text-xl font-display font-bold text-white">Admin Dashboard</h1>
            </div>
          </div>
          <Button 
            onClick={form.handleSubmit(onSubmit)} 
            disabled={isPending}
            className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20"
          >
            {isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Save Changes
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mt-4">
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 bg-card/50 border border-white/5 p-1 rounded-xl mb-8">
              <TabsTrigger value="general" className="rounded-lg data-[state=active]:bg-primary">General</TabsTrigger>
              <TabsTrigger value="navbar" className="rounded-lg data-[state=active]:bg-primary">Navbar</TabsTrigger>
              <TabsTrigger value="hero" className="rounded-lg data-[state=active]:bg-primary">Hero</TabsTrigger>
              <TabsTrigger value="features" className="rounded-lg data-[state=active]:bg-primary">Features</TabsTrigger>
              <TabsTrigger value="pricing" className="rounded-lg data-[state=active]:bg-primary">Pricing</TabsTrigger>
              <TabsTrigger value="faq" className="rounded-lg data-[state=active]:bg-primary">FAQ</TabsTrigger>
              <TabsTrigger value="footer" className="rounded-lg data-[state=active]:bg-primary">Footer</TabsTrigger>
              <TabsTrigger value="pages" className="rounded-lg data-[state=active]:bg-primary">Pages</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-6">
              <Card className="bg-card border-white/10">
                <CardHeader>
                  <CardTitle>Theme Colors</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Primary Color (Hex)</Label>
                    <div className="flex gap-4">
                      <Input type="color" className="w-16 p-1 h-10 cursor-pointer" {...form.register("theme.primaryColor")} />
                      <Input className="font-mono flex-1 bg-background/50 border-white/10" {...form.register("theme.primaryColor")} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Secondary Color (Hex)</Label>
                    <div className="flex gap-4">
                      <Input type="color" className="w-16 p-1 h-10 cursor-pointer" {...form.register("theme.secondaryColor")} />
                      <Input className="font-mono flex-1 bg-background/50 border-white/10" {...form.register("theme.secondaryColor")} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card border-white/10">
                <CardHeader>
                  <CardTitle>Contact Settings</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Recipient Email</Label>
                    <Input className="bg-background/50 border-white/10" {...form.register("emailSettings.recipientEmail")} />
                  </div>
                  <div className="space-y-2">
                    <Label>WhatsApp Number</Label>
                    <Input className="bg-background/50 border-white/10" {...form.register("whatsappNumber")} />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="navbar" className="space-y-6">
              <Card className="bg-card border-white/10">
                <CardHeader>
                  <CardTitle>Navbar Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Logo Text</Label>
                    <Input className="bg-background/50 border-white/10" {...form.register("navbar.logoText")} />
                  </div>
                  <Separator className="bg-white/5" />
                  <div className="flex items-center justify-between">
                    <Label>Navigation Links</Label>
                    <Button type="button" variant="outline" size="sm" onClick={() => appendNavLink({ label: "", href: "" })}>
                      <Plus className="w-4 h-4 mr-2" /> Add Link
                    </Button>
                  </div>
                  <div className="space-y-4">
                    {navLinkFields.map((field, index) => (
                      <div key={field.id} className="flex gap-4 items-end">
                        <div className="flex-1 space-y-2">
                          <Label>Label</Label>
                          <Input className="bg-background/50 border-white/10" {...form.register(`navbar.links.${index}.label`)} />
                        </div>
                        <div className="flex-1 space-y-2">
                          <Label>Href</Label>
                          <Input className="bg-background/50 border-white/10" {...form.register(`navbar.links.${index}.href`)} />
                        </div>
                        <Button type="button" variant="destructive" size="icon" onClick={() => removeNavLink(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="footer" className="space-y-6">
              <Card className="bg-card border-white/10">
                <CardHeader>
                  <CardTitle>Footer Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Copyright Text</Label>
                    <Input className="bg-background/50 border-white/10" {...form.register("footer.copyrightText")} />
                  </div>
                  <Separator className="bg-white/5" />
                  <div className="flex items-center justify-between">
                    <Label>Footer Links</Label>
                    <Button type="button" variant="outline" size="sm" onClick={() => appendFooterLink({ label: "", href: "" })}>
                      <Plus className="w-4 h-4 mr-2" /> Add Link
                    </Button>
                  </div>
                  <div className="space-y-4">
                    {footerLinkFields.map((field, index) => (
                      <div key={field.id} className="flex gap-4 items-end">
                        <div className="flex-1 space-y-2">
                          <Label>Label</Label>
                          <Input className="bg-background/50 border-white/10" {...form.register(`footer.links.${index}.label`)} />
                        </div>
                        <div className="flex-1 space-y-2">
                          <Label>Href</Label>
                          <Input className="bg-background/50 border-white/10" {...form.register(`footer.links.${index}.href`)} />
                        </div>
                        <Button type="button" variant="destructive" size="icon" onClick={() => removeFooterLink(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pages" className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-white">Custom Pages</h3>
                  <p className="text-muted-foreground text-sm">Create additional static pages for your site.</p>
                </div>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => appendCustomPage({ id: crypto.randomUUID(), title: "", slug: "", content: "" })}
                  className="border-white/10 hover:bg-white/5"
                >
                  <Plus className="w-4 h-4 mr-2" /> Create Page
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {customPageFields.map((field, index) => (
                  <Card key={field.id} className="bg-card border-white/10 relative group">
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-4 right-4 w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => removeCustomPage(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <CardContent className="pt-6 grid gap-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label>Page Title</Label>
                          <Input className="bg-background/50 border-white/10" {...form.register(`customPages.${index}.title`)} />
                        </div>
                        <div className="space-y-2">
                          <Label>Slug (URL path)</Label>
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground">/</span>
                            <Input className="bg-background/50 border-white/10" {...form.register(`customPages.${index}.slug`)} />
                          </div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Content (Markdown or HTML supported)</Label>
                        <Textarea className="min-h-[200px] bg-background/50 border-white/10" {...form.register(`customPages.${index}.content`)} />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="hero" className="space-y-6">
              <Card className="bg-card border-white/10">
                <CardHeader>
                  <CardTitle>Hero Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Main Headline</Label>
                    <Input className="text-xl h-14 bg-background/50 border-white/10" {...form.register("hero.title")} />
                  </div>
                  <div className="space-y-2">
                    <Label>Subtitle</Label>
                    <Textarea className="min-h-[100px] bg-background/50 border-white/10 text-base" {...form.register("hero.subtitle")} />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>CTA Button Text</Label>
                      <Input className="bg-background/50 border-white/10" {...form.register("hero.ctaText")} />
                    </div>
                    <div className="space-y-2">
                      <Label>Portal URL</Label>
                      <Input className="bg-background/50 border-white/10" {...form.register("hero.portalUrl")} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="features" className="space-y-6">
              <div className="flex items-center justify-between">
                <Label className="text-lg">Features List</Label>
                <Button type="button" variant="outline" size="sm" onClick={() => appendFeature({ id: crypto.randomUUID(), title: "", description: "", icon: "Zap" })}>
                  <Plus className="w-4 h-4 mr-2" /> Add Feature
                </Button>
              </div>
              <div className="grid grid-cols-1 gap-6">
                {featureFields.map((field, index) => (
                  <Card key={field.id} className="bg-card border-white/10 relative group">
                    <Button type="button" variant="destructive" size="icon" className="absolute top-4 right-4 opacity-0 group-hover:opacity-100" onClick={() => removeFeature(index)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-12 gap-6">
                      <div className="md:col-span-3 space-y-2">
                        <Label>Icon</Label>
                        <Input className="bg-background/50 border-white/10" {...form.register(`features.${index}.icon`)} />
                      </div>
                      <div className="md:col-span-9 space-y-4">
                        <Input className="bg-background/50 border-white/10" placeholder="Title" {...form.register(`features.${index}.title`)} />
                        <Textarea className="bg-background/50 border-white/10" placeholder="Description" {...form.register(`features.${index}.description`)} />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="pricing" className="space-y-6">
              <div className="flex items-center justify-between">
                <Label className="text-lg">Pricing Packages</Label>
                <Button type="button" variant="outline" size="sm" onClick={() => appendPricing({ id: crypto.randomUUID(), name: "", price: "", features: ["New feature"] })}>
                  <Plus className="w-4 h-4 mr-2" /> Add Package
                </Button>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {pricingFields.map((field, index) => (
                  <Card key={field.id} className="bg-card border-white/10 relative group">
                    <Button type="button" variant="destructive" size="icon" className="absolute top-4 right-4 opacity-0 group-hover:opacity-100" onClick={() => removePricing(index)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <CardHeader>
                      <Input className="font-bold bg-background/50 border-white/10" placeholder="Name" {...form.register(`pricing.${index}.name`)} />
                      <Input className="font-mono bg-background/50 border-white/10 mt-2" placeholder="Price" {...form.register(`pricing.${index}.price`)} />
                    </CardHeader>
                    <CardContent>
                      <Label>Features (One per line)</Label>
                      <Textarea 
                        className="h-32 bg-background/50 border-white/10 mt-2" 
                        defaultValue={field.features.join('\n')}
                        onChange={(e) => {
                          const arr = e.target.value.split('\n').filter(s => s.trim() !== '');
                          form.setValue(`pricing.${index}.features`, arr, { shouldDirty: true });
                        }}
                      />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="faq" className="space-y-6">
              <div className="flex items-center justify-between">
                <Label className="text-lg">FAQ List</Label>
                <Button type="button" variant="outline" size="sm" onClick={() => appendFaq({ question: "", answer: "" })}>
                  <Plus className="w-4 h-4 mr-2" /> Add FAQ
                </Button>
              </div>
              <div className="space-y-4">
                {faqFields.map((field, index) => (
                  <Card key={field.id} className="bg-card border-white/10 relative group">
                    <Button type="button" variant="destructive" size="icon" className="absolute top-4 right-4 opacity-0 group-hover:opacity-100" onClick={() => removeFaq(index)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <CardContent className="pt-6 grid gap-4">
                      <Input className="bg-background/50 border-white/10 font-semibold" placeholder="Question" {...form.register(`faq.${index}.question`)} />
                      <Textarea className="bg-background/50 border-white/10" placeholder="Answer" {...form.register(`faq.${index}.answer`)} />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </form>
      </main>
    </div>
  );
}
