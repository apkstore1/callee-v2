import { motion } from "framer-motion";
import { useConfig } from "@/hooks/use-config";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useParams } from "wouter";
import { PageReveal } from "@/components/PageReveal";

export default function CustomPage() {
  const { slug } = useParams();
  const { data: config, isLoading } = useConfig();

  if (isLoading) return null;
  if (!config) return null;

  const page = config.customPages.find(p => p.slug === slug);

  if (!page) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <h1 className="text-4xl font-display font-bold text-white mb-4">404</h1>
        <p className="text-muted-foreground">Page not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      
      <main className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          <PageReveal>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-8 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/50">
              {page.title}
            </h1>
            
            <div 
              className="prose prose-invert max-w-none prose-headings:text-white prose-p:text-muted-foreground prose-strong:text-white prose-a:text-primary"
              dangerouslySetInnerHTML={{ __html: page.content }}
            />
          </PageReveal>
        </div>
      </main>

      <Footer />
    </div>
  );
}
