import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { DynamicTheme } from "@/components/DynamicTheme";
import LandingPage from "@/pages/LandingPage";
import AdminDashboard from "@/pages/AdminDashboard";
import CustomPage from "@/pages/CustomPage";
import { useConfig } from "@/hooks/use-config";

function Router() {
  const { data: config } = useConfig();
  
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/admin" component={AdminDashboard} />
      
      {/* Dynamic Custom Pages */}
      {config?.customPages.map((page) => (
        <Route key={page.id} path={`/${page.slug}`}>
          <CustomPage />
        </Route>
      ))}

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <DynamicTheme />
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
