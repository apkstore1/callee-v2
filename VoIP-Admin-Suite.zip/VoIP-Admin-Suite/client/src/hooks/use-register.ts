import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type RegistrationForm } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useRegister() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: RegistrationForm) => {
      const validated = api.registration.submit.input.parse(data);
      const res = await fetch(api.registration.submit.path, {
        method: api.registration.submit.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.registration.submit.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to submit registration");
      }
      return api.registration.submit.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({
        title: "Registration Successful",
        description: data.message || "We will contact you shortly.",
      });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
