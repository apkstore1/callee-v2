import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useConfig } from "@/hooks/use-config";
import { ArrowRight, Activity, Shield, Zap } from "lucide-react";

export function Hero() {
  const { data: config } = useConfig();
  if (!config) return null;

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 mesh-bg" />
      <div className="absolute inset-0 grid-bg opacity-30" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm"
          >
            <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium text-muted-foreground">Next-Gen VoIP Solution</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-display font-extrabold tracking-tight mb-8"
          >
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-white/70">
              {config.hero.title.split(' ').slice(0, -1).join(' ')}{' '}
            </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary text-glow">
              {config.hero.title.split(' ').slice(-1)}
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed"
          >
            {config.hero.subtitle}
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button 
              size="lg" 
              className="w-full sm:w-auto h-14 px-8 bg-gradient-to-r from-primary to-primary/80 hover:to-primary text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300 text-lg rounded-xl font-semibold"
              onClick={() => window.location.href = config.hero.portalUrl}
            >
              {config.hero.ctaText}
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="w-full sm:w-auto h-14 px-8 border-white/10 hover:bg-white/5 hover:border-white/20 transition-all duration-300 text-lg rounded-xl"
              onClick={() => {
                document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              View Pricing
            </Button>
          </motion.div>
        </div>

        {/* Floating Stats/Badges for visual depth */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-3 gap-6 max-w-3xl mx-auto"
        >
          {[
            { icon: Activity, label: "99.9% Uptime", desc: "Enterprise Grade" },
            { icon: Shield, label: "End-to-End", desc: "Secure Encryption" },
            { icon: Zap, label: "Ultra Low", desc: "Latency Global Network" }
          ].map((stat, i) => (
            <div key={i} className="glass-card p-6 rounded-2xl flex flex-col items-center text-center">
              <stat.icon className="w-8 h-8 text-primary mb-3" />
              <div className="font-semibold text-white">{stat.label}</div>
              <div className="text-sm text-muted-foreground">{stat.desc}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
