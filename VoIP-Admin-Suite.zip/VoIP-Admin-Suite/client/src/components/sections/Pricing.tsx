import { motion } from "framer-motion";
import { useConfig } from "@/hooks/use-config";
import { Check, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Pricing() {
  const { data: config } = useConfig();
  if (!config) return null;

  const handleWhatsApp = (pkgName: string) => {
    const text = encodeURIComponent(`Hi, I am interested in the ${pkgName} package for Calleey VoIP Dialer.`);
    window.open(`https://wa.me/${config.whatsappNumber}?text=${text}`, '_blank');
  };

  return (
    <section id="pricing" className="py-24 relative z-10 bg-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-20"
        >
          <h2 className="text-primary font-semibold tracking-wider uppercase mb-4 text-sm">Flexible Pricing</h2>
          <h3 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
            Choose Your Plan
          </h3>
          <p className="text-xl text-muted-foreground">
            Simple, transparent pricing that grows with your business. No hidden fees.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {config.pricing.map((pkg, index) => {
            const isPopular = index === 1; // Highlight middle package
            
            return (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative rounded-3xl p-8 ${
                  isPopular 
                    ? 'bg-gradient-to-b from-primary/20 to-card border border-primary/50 shadow-2xl shadow-primary/20 transform md:-translate-y-4' 
                    : 'glass-card'
                }`}
              >
                {isPopular && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <span className="bg-primary text-primary-foreground text-xs font-bold uppercase tracking-wider py-1 px-4 rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <h4 className="text-2xl font-display font-bold text-white mb-2">{pkg.name}</h4>
                <div className="mb-8">
                  <span className="text-4xl font-extrabold text-white">{pkg.price}</span>
                </div>

                <div className="space-y-4 mb-8">
                  {pkg.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center mt-0.5">
                        <Check className="w-3.5 h-3.5 text-primary" />
                      </div>
                      <span className="text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                <Button 
                  onClick={() => handleWhatsApp(pkg.name)}
                  className={`w-full h-12 rounded-xl text-base font-semibold ${
                    isPopular 
                      ? 'bg-primary hover:bg-primary/90 text-white shadow-lg' 
                      : 'bg-white/10 hover:bg-white/20 text-white border-0'
                  }`}
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Inquire on WhatsApp
                </Button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
