import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { registrationFormSchema, type RegistrationForm } from "@shared/schema";
import { useRegister } from "@/hooks/use-register";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send } from "lucide-react";

export function LeadForm() {
  const { mutate: submitRegistration, isPending } = useRegister();
  
  const form = useForm<RegistrationForm>({
    resolver: zodResolver(registrationFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      company: "",
      message: "",
    }
  });

  const onSubmit = (data: RegistrationForm) => {
    submitRegistration(data, {
      onSuccess: () => form.reset()
    });
  };

  return (
    <section className="py-24 relative z-10 bg-card/50 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
              Ready to Upgrade Your Communications?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Fill out the form and our team will get back to you with a tailored solution for your business.
            </p>
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <Send className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-white">Fast Response</div>
                <div className="text-sm">We typically reply within 2 hours.</div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-panel p-8 md:p-10 rounded-3xl relative"
          >
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white/80">Full Name</Label>
                  <Input 
                    id="name" 
                    placeholder="John Doe" 
                    className="bg-background/50 border-white/10 text-white h-12 rounded-xl focus-visible:ring-primary focus-visible:border-primary"
                    {...form.register("name")} 
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white/80">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="john@company.com" 
                    className="bg-background/50 border-white/10 text-white h-12 rounded-xl focus-visible:ring-primary focus-visible:border-primary"
                    {...form.register("email")} 
                  />
                  {form.formState.errors.email && (
                    <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-white/80">Phone Number</Label>
                  <Input 
                    id="phone" 
                    placeholder="+1 (555) 000-0000" 
                    className="bg-background/50 border-white/10 text-white h-12 rounded-xl focus-visible:ring-primary focus-visible:border-primary"
                    {...form.register("phone")} 
                  />
                  {form.formState.errors.phone && (
                    <p className="text-sm text-destructive">{form.formState.errors.phone.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company" className="text-white/80">Company (Optional)</Label>
                  <Input 
                    id="company" 
                    placeholder="Acme Corp" 
                    className="bg-background/50 border-white/10 text-white h-12 rounded-xl focus-visible:ring-primary focus-visible:border-primary"
                    {...form.register("company")} 
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-white/80">Message</Label>
                <Textarea 
                  id="message" 
                  placeholder="Tell us about your needs..." 
                  className="bg-background/50 border-white/10 text-white min-h-[120px] rounded-xl resize-none focus-visible:ring-primary focus-visible:border-primary"
                  {...form.register("message")} 
                />
              </div>

              <Button 
                type="submit" 
                disabled={isPending}
                className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-white rounded-xl shadow-lg shadow-primary/20"
              >
                {isPending ? "Sending..." : "Request Access"}
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
