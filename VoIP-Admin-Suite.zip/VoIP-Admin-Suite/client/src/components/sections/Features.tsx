import { motion } from "framer-motion";
import { useConfig } from "@/hooks/use-config";
import { Server, Zap, Globe, Shield, Phone, Headphones, LucideIcon } from "lucide-react";

// Helper to map string icon names from config to actual Lucide components
const iconMap: Record<string, LucideIcon> = {
  Server, Zap, Globe, Shield, Phone, Headphones
};

export function Features() {
  const { data: config } = useConfig();
  if (!config) return null;

  return (
    <section id="features" className="py-24 relative z-10 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-20"
        >
          <h2 className="text-primary font-semibold tracking-wider uppercase mb-4 text-sm">Capabilities</h2>
          <h3 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">
            Powerful Features for Modern Teams
          </h3>
          <p className="text-xl text-muted-foreground">
            Everything you need to manage your communications efficiently and scale your operations globally.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {config.features.map((feature, index) => {
            const IconComponent = feature.icon ? (iconMap[feature.icon] || Zap) : Zap;
            
            return (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative glass-card p-8 rounded-3xl overflow-hidden box-glow-hover"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative z-10">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 group-hover:border-primary/30 transition-colors duration-300">
                    <IconComponent className="w-7 h-7 text-primary" />
                  </div>
                  <h4 className="text-2xl font-bold text-white mb-4 font-display">{feature.title}</h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
