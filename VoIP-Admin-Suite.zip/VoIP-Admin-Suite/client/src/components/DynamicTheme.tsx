import { useConfig } from "@/hooks/use-config";
import { hexToHsl } from "@/lib/theme-utils";

export function DynamicTheme() {
  const { data: config } = useConfig();

  if (!config) return null;

  const primaryHsl = hexToHsl(config.theme.primaryColor);
  const secondaryHsl = hexToHsl(config.theme.secondaryColor);

  return (
    <style dangerouslySetInnerHTML={{
      __html: `
        :root {
          --primary: ${primaryHsl};
          --secondary: ${secondaryHsl};
        }
      `
    }} />
  );
}
