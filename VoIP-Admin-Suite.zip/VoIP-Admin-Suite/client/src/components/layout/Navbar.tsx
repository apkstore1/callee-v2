import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useConfig } from "@/hooks/use-config";
import { PhoneCall, Menu } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

export function Navbar() {
  const { data: config } = useConfig();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!config) return null;

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 glass-panel border-b-0 border-white/5"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          <div className="flex-shrink-0 flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center box-glow">
              <PhoneCall className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-display font-bold text-white tracking-wide">
              {config.navbar?.logoText || "Calleey"}
            </span>
          </div>

          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {(config.navbar?.links || []).map((link) => (
                <a 
                  key={link.label} 
                  href={link.href} 
                  className="text-muted-foreground hover:text-white transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Button variant="ghost" className="text-muted-foreground hover:text-white hover:bg-white/5" onClick={() => window.location.href = config.hero.portalUrl}>
              Login
            </Button>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25" onClick={() => window.location.href = config.hero.portalUrl}>
              Portal Access
            </Button>
          </div>

          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              <Menu className="w-6 h-6" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="md:hidden glass-panel border-t border-white/5"
        >
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#features" className="text-muted-foreground hover:text-white block px-3 py-2 rounded-md text-base font-medium">Features</a>
            <a href="#pricing" className="text-muted-foreground hover:text-white block px-3 py-2 rounded-md text-base font-medium">Pricing</a>
            <a href="#faq" className="text-muted-foreground hover:text-white block px-3 py-2 rounded-md text-base font-medium">FAQ</a>
            <div className="mt-4 flex flex-col gap-2 p-3">
              <Button variant="outline" className="w-full justify-center border-white/10" onClick={() => window.location.href = config.hero.portalUrl}>
                Login
              </Button>
              <Button className="w-full justify-center bg-primary" onClick={() => window.location.href = config.hero.portalUrl}>
                Portal Access
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}
