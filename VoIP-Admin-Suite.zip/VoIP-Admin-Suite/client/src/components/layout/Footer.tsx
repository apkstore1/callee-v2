import { Link } from "wouter";
import { PhoneCall } from "lucide-react";
import { useConfig } from "@/hooks/use-config";

export function Footer() {
  const { data: config } = useConfig();

  if (!config) return null;

  return (
    <footer className="border-t border-white/5 bg-background relative overflow-hidden">
      <div className="absolute inset-0 mesh-bg opacity-30 pointer-events-none" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <PhoneCall className="w-4 h-4 text-primary" />
            </div>
            <span className="text-lg font-display font-bold text-white">{config.navbar?.logoText || "Calleey"}</span>
          </div>
          <div className="flex gap-6 text-sm text-muted-foreground">
            {(config.footer?.links || []).map((link) => (
              <a 
                key={link.label} 
                href={link.href} 
                className="hover:text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
            <Link href="/admin" className="hover:text-primary transition-colors">Admin</Link>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} {config.footer?.copyrightText || "Calleey VoIP Dialer. All rights reserved."}
          </p>
        </div>
      </div>
    </footer>
  );
}
