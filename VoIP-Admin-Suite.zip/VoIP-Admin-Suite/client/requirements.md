## Packages
framer-motion | Essential for the requested premium, high-tech SaaS animations and scroll reveals.
react-hook-form | Required for managing the complex no-database Admin Panel forms and Lead Generation.
@hookform/resolvers | Required for validating forms using Zod schemas.

## Notes
The application expects dynamic CSS variable injection based on `/api/config` theme settings.
Images are primarily structural (glows, gradients) so no static stock photography is strictly required. Icons are mapped dynamically via Lucide React.
